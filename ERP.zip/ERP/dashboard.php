<?php
/**
 * Main Dashboard (Cockpit)
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';
$user = requireUser();

$pageTitle = 'Dashboard Overview';

// Global KPIs
$totalWos  = dbOne("SELECT COUNT(*) AS c FROM work_orders")['c'] ?? 0;
$inProgWos = dbOne("SELECT COUNT(*) AS c FROM work_orders WHERE status IN ('IN_PROGRESS','PARTIALLY_COMPLETED')")['c'] ?? 0;
$closedWos = dbOne("SELECT COUNT(*) AS c FROM work_orders WHERE status='CLOSED'")['c'] ?? 0;

$lowStock = dbOne("SELECT COUNT(*) AS c FROM parts WHERE (stock_qty - reserved_qty) <= reorder_level")['c'] ?? 0;
$pendingRevs = dbOne("SELECT COUNT(*) AS c FROM work_orders WHERE status='REVISION_IN_PROGRESS'")['c'] ?? 0;
$svcQueue = dbOne("SELECT COUNT(*) AS c FROM work_orders WHERE status='HANDED_TO_SERVICE'")['c'] ?? 0;

// Finance KPIs (Admin Only)
$approvedRevenue = 0;
$pendingRevenue = 0;
if ($user['role'] === 'ADMIN') {
    $approvedRevenue = dbOne("SELECT SUM(total) AS s FROM quotations WHERE status='APPROVED'")['s'] ?? 0;
    $pendingRevenue = dbOne("SELECT SUM(total) AS s FROM quotations WHERE status IN ('DRAFT', 'SENT')")['s'] ?? 0;
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Welcome, <?= e(explode(' ', $user['name'])[0]) ?></h1>
    <p>Here's what's happening across Nayendra today.</p>
  </div>
</div>

<?php if($lowStock > 0 && in_array($user['role'], ['ADMIN', 'LOGISTICS'])): ?>
<div class="alert alert-low-stock" style="display:flex; justify-content:space-between; align-items:center;">
  <div>
    <strong class="text-rose">⚠ Low Stock Alert:</strong> <?= $lowStock ?> parts have fallen below their reorder level.
  </div>
  <a href="inventory/low_stock.php" class="btn btn-sm btn-danger">View Parts</a>
</div>
<?php endif; ?>

<!-- KPI Grid -->
<div class="kpi-grid">
  <div class="kpi-card green" onclick="window.location.href='sales/leads.php'" style="cursor: pointer; transition: transform 0.2s;">
    <div class="kpi-label">Active Work Orders</div>
    <div class="kpi-value green"><?= $totalWos - $closedWos ?></div>
    <div class="kpi-sub">Currently in pipeline</div>
  </div>
  <div class="kpi-card violet" onclick="window.location.href='service/workorders.php'" style="cursor: pointer; transition: transform 0.2s;">
    <div class="kpi-label">Work In Progress</div>
    <div class="kpi-value violet"><?= $inProgWos ?></div>
    <div class="kpi-sub">Onsite execution</div>
  </div>
  <div class="kpi-card amber" onclick="window.location.href='service/queue.php'" style="cursor: pointer; transition: transform 0.2s;">
    <div class="kpi-label">Service Queue</div>
    <div class="kpi-value amber"><?= $svcQueue ?></div>
    <div class="kpi-sub">Pending Controller Acceptance</div>
  </div>
  <div class="kpi-card red" onclick="window.location.href='sales/revisions.php'" style="cursor: pointer; transition: transform 0.2s;">
    <div class="kpi-label">Revision Requests</div>
    <div class="kpi-value red"><?= $pendingRevs ?></div>
    <div class="kpi-sub">Awaiting Sales Action</div>
  </div>
  <div class="kpi-card" onclick="window.location.href='sales/leads.php'" style="cursor: pointer; transition: transform 0.2s;">
    <div class="kpi-label">Closed Work Orders</div>
    <div class="kpi-value"><?= $closedWos ?></div>
    <div class="kpi-sub">Successfully completed</div>
  </div>
</div>

<?php if ($user['role'] === 'ADMIN'): ?>
<h2 style="font-size: 16px; font-weight: 600; color: var(--slate6); margin: 24px 0 12px 0;">Financial Overview</h2>
<div class="kpi-grid">
  <div class="kpi-card blue" style="cursor: default;">
    <div class="kpi-label">Confirmed Revenue (Approved)</div>
    <div class="kpi-value blue"><?= money($approvedRevenue) ?></div>
    <div class="kpi-sub">Total inflow from approved quotes</div>
  </div>
  <div class="kpi-card amber" style="cursor: default;">
    <div class="kpi-label">Pipeline Revenue (Pending)</div>
    <div class="kpi-value amber"><?= money($pendingRevenue) ?></div>
    <div class="kpi-sub">Total from Draft/Sent quotes</div>
  </div>
</div>
<?php endif; ?>

<div class="detail-grid">
  <!-- Recent Pipeline -->
  <div class="card">
    <div class="card-header"><div class="card-title">Recent Activity Pipeline</div></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Work Order</th><th>Status</th><th>Last Updated</th></tr></thead>
        <tbody>
          <?php 
          $recent = dbAll("SELECT id, work_order_no, status, updated_at FROM work_orders ORDER BY updated_at DESC LIMIT 6");
          foreach($recent as $r): ?>
          <tr>
            <td><a href="sales/leads_view.php?id=<?= $r['id'] ?>" class="font-mono"><strong><?= e($r['work_order_no']) ?></strong></a></td>
            <td><span class="<?= badgeClass($r['status']) ?>"><?= e(woStatusLabel($r['status'])) ?></span></td>
            <td class="text-muted text-sm"><?= dt($r['updated_at']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Role-specific quick actions -->
  <div class="card">
    <div class="card-header"><div class="card-title">Quick Actions</div></div>
    <div class="card-body space-y">
      <?php if(in_array($user['role'], ['ADMIN', 'SALES'])): ?>
        <a href="sales/leads_new.php" class="btn btn-outline-sky" style="width:100%; justify-content:flex-start;">➕ Create New Lead / Work Order</a>
        <a href="sales/revisions.php" class="btn btn-outline-sky" style="width:100%; justify-content:flex-start;">🔄 Handle Pending Revisions</a>
      <?php endif; ?>
      <?php if(in_array($user['role'], ['ADMIN', 'SERVICE_CONTROLLER'])): ?>
        <a href="service/queue.php" class="btn btn-outline-sky" style="width:100%; justify-content:flex-start;">📋 View Service Queue</a>
        <a href="service/pending_revision.php" class="btn btn-outline-sky" style="width:100%; justify-content:flex-start;">📩 Check Approved Revisions</a>
      <?php endif; ?>
      <?php if(in_array($user['role'], ['ADMIN', 'LOGISTICS'])): ?>
        <a href="logistics/requirements.php" class="btn btn-outline-sky" style="width:100%; justify-content:flex-start;">📦 Process Part Requirements</a>
        <a href="logistics/receipt.php" class="btn btn-outline-sky" style="width:100%; justify-content:flex-start;">📥 Receive Goods</a>
      <?php endif; ?>
      <?php if(in_array($user['role'], ['ADMIN', 'TECHNICIAN'])): ?>
        <a href="technician/jobs.php" class="btn btn-outline-sky" style="width:100%; justify-content:flex-start;">👷 View My Assigned Jobs</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
