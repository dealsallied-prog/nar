<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser();

// Base validation
if (!isset($_GET['report_type'])) {
    die("Report type not specified.");
}

$reportType = $_GET['report_type'];
$dateRange = $_GET['date_range'] ?? 'all_time';
$startDate = $_GET['start_date'] ?? null;
$endDate = $_GET['end_date'] ?? null;

// Date filtering logic
$whereDate = "1=1";
$params = [];
$dateCol = "created_at"; // Default date column for filtering

if ($reportType === 'tech_performance') $dateCol = "assigned_at";
if ($reportType === 'po_tracking') $dateCol = "ordered_at";

if ($dateRange === 'today') {
    $whereDate = "DATE($dateCol) = CURDATE()";
} elseif ($dateRange === 'this_week') {
    $whereDate = "YEARWEEK($dateCol, 1) = YEARWEEK(CURDATE(), 1)";
} elseif ($dateRange === 'this_month') {
    $whereDate = "YEAR($dateCol) = YEAR(CURDATE()) AND MONTH($dateCol) = MONTH(CURDATE())";
} elseif ($dateRange === 'last_month') {
    $whereDate = "YEAR($dateCol) = YEAR(CURDATE() - INTERVAL 1 MONTH) AND MONTH($dateCol) = MONTH(CURDATE() - INTERVAL 1 MONTH)";
} elseif ($dateRange === 'custom' && $startDate && $endDate) {
    $whereDate = "DATE($dateCol) BETWEEN ? AND ?";
    $params[] = $startDate;
    $params[] = $endDate;
}

// Prepare CSV headers and output stream
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="Report_' . $reportType . '_' . date('Ymd_His') . '.csv"');
$output = fopen('php://output', 'w');

// Add BOM for Excel UTF-8 compatibility
fputs($output, "\xEF\xBB\xBF");

// Define query and headers based on report type
switch ($reportType) {
    
    // ---------------------------------------------------------
    // ADMIN REPORTS
    // ---------------------------------------------------------
    case 'ops_funnel':
        if ($user['role'] !== 'ADMIN') die("Access denied");
        fputcsv($output, ['Status', 'Total Work Orders', 'Sales Count', 'Service Count']);
        $sql = "SELECT status, COUNT(*) as total, 
                SUM(CASE WHEN sales_owner_id IS NOT NULL THEN 1 ELSE 0 END) as sales_count,
                SUM(CASE WHEN service_owner_id IS NOT NULL THEN 1 ELSE 0 END) as service_count
                FROM work_orders 
                WHERE $whereDate 
                GROUP BY status ORDER BY total DESC";
        $stmt = pdo()->prepare($sql);
        $stmt->execute($params);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [$row['status'], $row['total'], $row['sales_count'], $row['service_count']]);
        }
        break;

    case 'tech_performance':
        if ($user['role'] !== 'ADMIN') die("Access denied");
        fputcsv($output, ['Technician Name', 'Total Assigned', 'In Progress', 'Completed', 'Total Site Visits']);
        $sql = "SELECT u.name, 
                COUNT(wa.id) as total_assigned,
                SUM(CASE WHEN wa.work_status = 'IN_PROGRESS' THEN 1 ELSE 0 END) as in_progress,
                SUM(CASE WHEN wa.work_status = 'COMPLETED' THEN 1 ELSE 0 END) as completed,
                (SELECT COUNT(*) FROM site_visit_updates sv WHERE sv.technician_id = u.id) as site_visits
                FROM users u
                LEFT JOIN work_order_assignments wa ON wa.technician_id = u.id AND " . str_replace("assigned_at", "wa.assigned_at", $whereDate) . "
                WHERE u.role = 'TECHNICIAN'
                GROUP BY u.id
                ORDER BY completed DESC";
        $stmt = pdo()->prepare($sql);
        $stmt->execute($params);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [$row['name'], $row['total_assigned'], $row['in_progress'], $row['completed'], $row['site_visits']]);
        }
        break;

    case 'revenue':
        if ($user['role'] !== 'ADMIN') die("Access denied");
        fputcsv($output, ['Sales Owner', 'Quotation Status', 'Total Revenue', 'Quote Count']);
        $sql = "SELECT COALESCE(u.name, 'Unassigned') as sales_owner, q.status, SUM(q.total) as total_revenue, COUNT(q.id) as quote_count
                FROM quotations q
                LEFT JOIN users u ON q.created_by_id = u.id
                WHERE " . str_replace("created_at", "q.created_at", $whereDate) . "
                GROUP BY u.id, q.status
                ORDER BY sales_owner, q.status";
        $stmt = pdo()->prepare($sql);
        $stmt->execute($params);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [$row['sales_owner'], $row['status'], number_format($row['total_revenue'], 2), $row['quote_count']]);
        }
        break;

    // ---------------------------------------------------------
    // SALES REPORTS
    // ---------------------------------------------------------
    case 'sales_pipeline':
        if (!in_array($user['role'], ['ADMIN', 'SALES'])) die("Access denied");
        fputcsv($output, ['Work Order No', 'Customer', 'Status', 'Sales Owner', 'Created Date']);
        $sql = "SELECT w.work_order_no, c.name as customer, w.status, u.name as sales_owner, w.created_at
                FROM work_orders w
                JOIN customers c ON w.customer_id = c.id
                LEFT JOIN users u ON w.sales_owner_id = u.id
                WHERE w.status IN ('NEW', 'PRE_SALE_VISIT_SCHEDULED', 'QUOTATION_CREATED', 'REVISION_IN_PROGRESS')
                AND " . str_replace("created_at", "w.created_at", $whereDate) . "
                ORDER BY w.created_at DESC";
        $stmt = pdo()->prepare($sql);
        $stmt->execute($params);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [$row['work_order_no'], $row['customer'], $row['status'], $row['sales_owner'], $row['created_at']]);
        }
        break;

    case 'quotation_history':
        if (!in_array($user['role'], ['ADMIN', 'SALES'])) die("Access denied");
        fputcsv($output, ['Quote No', 'Work Order No', 'Version', 'Status', 'Subtotal', 'Total', 'Created By', 'Created At']);
        $sql = "SELECT q.quotation_no, w.work_order_no, q.version, q.status, q.subtotal, q.total, u.name as created_by, q.created_at
                FROM quotations q
                JOIN work_orders w ON q.work_order_id = w.id
                LEFT JOIN users u ON q.created_by_id = u.id
                WHERE " . str_replace("created_at", "q.created_at", $whereDate) . "
                ORDER BY q.created_at DESC";
        $stmt = pdo()->prepare($sql);
        $stmt->execute($params);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [$row['quotation_no'], $row['work_order_no'], $row['version'], $row['status'], $row['subtotal'], $row['total'], $row['created_by'], $row['created_at']]);
        }
        break;

    // ---------------------------------------------------------
    // SERVICE REPORTS
    // ---------------------------------------------------------
    case 'service_pipeline':
        if (!in_array($user['role'], ['ADMIN', 'SERVICE_CONTROLLER'])) die("Access denied");
        fputcsv($output, ['Work Order No', 'Status', 'Service Owner', 'Technicians Assigned']);
        $sql = "SELECT w.work_order_no, w.status, u.name as service_owner, 
                GROUP_CONCAT(tu.name SEPARATOR ', ') as techs
                FROM work_orders w
                LEFT JOIN users u ON w.service_owner_id = u.id
                LEFT JOIN work_order_assignments wa ON w.id = wa.work_order_id
                LEFT JOIN users tu ON wa.technician_id = tu.id
                WHERE w.status IN ('HANDED_TO_SERVICE', 'SERVICE_IN_PROGRESS')
                AND " . str_replace("created_at", "w.created_at", $whereDate) . "
                GROUP BY w.id
                ORDER BY w.created_at DESC";
        $stmt = pdo()->prepare($sql);
        $stmt->execute($params);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [$row['work_order_no'], $row['status'], $row['service_owner'], $row['techs']]);
        }
        break;

    // ---------------------------------------------------------
    // LOGISTICS REPORTS
    // ---------------------------------------------------------
    case 'part_allocations':
        if (!in_array($user['role'], ['ADMIN', 'LOGISTICS'])) die("Access denied");
        fputcsv($output, ['Work Order No', 'Technician', 'Part SKU', 'Part Name', 'Qty Requested', 'Status', 'Requested At']);
        $sql = "SELECT w.work_order_no, u.name as tech, p.sku, p.name as part_name, a.quantity, a.status, a.requested_at
                FROM part_allocations a
                JOIN work_orders w ON a.work_order_id = w.id
                JOIN users u ON a.technician_id = u.id
                JOIN parts p ON a.part_id = p.id
                WHERE " . str_replace("created_at", "a.requested_at", $whereDate) . "
                ORDER BY a.requested_at DESC";
        $stmt = pdo()->prepare($sql);
        $stmt->execute($params);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [$row['work_order_no'], $row['tech'], $row['sku'], $row['part_name'], $row['quantity'], $row['status'], $row['requested_at']]);
        }
        break;

    case 'po_tracking':
        if (!in_array($user['role'], ['ADMIN', 'LOGISTICS'])) die("Access denied");
        fputcsv($output, ['Work Order No', 'Part SKU', 'Qty Ordered', 'Status', 'Order Ref', 'Ordered At', 'Received At']);
        $sql = "SELECT w.work_order_no, p.sku, o.quantity, o.status, o.order_reference, o.ordered_at, o.received_at
                FROM part_orders o
                JOIN work_orders w ON o.work_order_id = w.id
                JOIN parts p ON o.part_id = p.id
                WHERE " . str_replace("ordered_at", "o.ordered_at", $whereDate) . "
                ORDER BY o.created_at DESC";
        $stmt = pdo()->prepare($sql);
        $stmt->execute($params);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [$row['work_order_no'], $row['sku'], $row['quantity'], $row['status'], $row['order_reference'], $row['ordered_at'], $row['received_at']]);
        }
        break;

    // ---------------------------------------------------------
    // INVENTORY REPORTS
    // ---------------------------------------------------------
    case 'stock_valuation':
        if (!in_array($user['role'], ['ADMIN', 'LOGISTICS', 'SERVICE_CONTROLLER'])) die("Access denied");
        fputcsv($output, ['SKU', 'Part Name', 'Unit Price', 'Stock Qty', 'Reserved Qty', 'Available Qty', 'Total Value']);
        $sql = "SELECT sku, name, unit_price, stock_qty, reserved_qty, (stock_qty - reserved_qty) as available, (stock_qty * unit_price) as value
                FROM parts ORDER BY sku";
        $stmt = pdo()->query($sql);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [$row['sku'], $row['name'], $row['unit_price'], $row['stock_qty'], $row['reserved_qty'], $row['available'], $row['value']]);
        }
        break;

    case 'low_stock':
        if (!in_array($user['role'], ['ADMIN', 'LOGISTICS'])) die("Access denied");
        fputcsv($output, ['SKU', 'Part Name', 'Stock Qty', 'Reorder Level', 'Deficit']);
        $sql = "SELECT sku, name, stock_qty, reorder_level, (reorder_level - stock_qty) as deficit
                FROM parts WHERE stock_qty <= reorder_level AND reorder_level > 0 ORDER BY deficit DESC";
        $stmt = pdo()->query($sql);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [$row['sku'], $row['name'], $row['stock_qty'], $row['reorder_level'], $row['deficit']]);
        }
        break;

    case 'stock_ledger':
        if (!in_array($user['role'], ['ADMIN', 'LOGISTICS'])) die("Access denied");
        fputcsv($output, ['Date', 'Part SKU', 'Change Type', 'Quantity', 'Balance After', 'Work Order No', 'Note']);
        $sql = "SELECT l.created_at, p.sku, l.change_type, l.quantity, l.balance_after, w.work_order_no, l.note
                FROM stock_ledger l
                JOIN parts p ON l.part_id = p.id
                LEFT JOIN work_orders w ON l.work_order_id = w.id
                WHERE " . str_replace("created_at", "l.created_at", $whereDate) . "
                ORDER BY l.created_at DESC";
        $stmt = pdo()->prepare($sql);
        $stmt->execute($params);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($output, [$row['created_at'], $row['sku'], $row['change_type'], $row['quantity'], $row['balance_after'], $row['work_order_no'], $row['note']]);
        }
        break;

    default:
        fputcsv($output, ['Error: Invalid report type']);
        break;
}

fclose($output);
exit;
