<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser();

if (!in_array($user['role'], ['ADMIN'])) {
    die("Access denied. Administrator privileges required.");
}

$pageTitle = 'Reports & Analytics';
include __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-title-group">
    <h1 class="page-title">Reports & Analytics</h1>
    <p class="page-desc">Generate and download operational reports in Excel format.</p>
  </div>
</div>

<style>
.report-section-title { font-size: 13px; font-weight: 700; color: var(--slate5); margin: 24px 0 12px; text-transform: uppercase; letter-spacing: 0.05em; display: flex; align-items: center; gap: 8px; }
.report-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; margin-bottom: 32px; }
.report-card { background: #fff; border: 1px solid var(--slate2); border-radius: 12px; padding: 18px; transition: all 0.2s; display: flex; flex-direction: column; box-shadow: 0 2px 5px rgba(0,0,0,0.02); }
.report-card:hover { border-color: rgba(245,184,0,0.4); box-shadow: 0 6px 20px rgba(0,0,0,0.06); transform: translateY(-3px); }
.report-card-title { font-size: 15px; font-weight: 700; color: var(--brand-black); margin-bottom: 6px; }
.report-card-desc { font-size: 12.5px; color: var(--slate5); flex: 1; margin-bottom: 16px; line-height: 1.45; }
.report-card-footer { display: flex; align-items: center; justify-content: space-between; border-top: 1px solid var(--slate1); padding-top: 12px; margin-top: auto; }
</style>

<!-- Admin Reports -->
<div class="report-section-title"><span class="badge badge-purple">Admin</span> Management & Operations</div>
<div class="report-grid">
  <div class="report-card">
    <div class="report-card-title">Overall Operations Funnel</div>
    <div class="report-card-desc">Work orders by status over time. Identifies bottlenecks in the pipeline.</div>
    <div class="report-card-footer">
      <span style="font-size: 11px; color: var(--slate4); font-weight: 600;">System Health</span>
      <button class="btn btn-sm btn-brand" onclick="openExportModal('ops_funnel')">Export</button>
    </div>
  </div>
  <div class="report-card">
    <div class="report-card-title">Technician Performance</div>
    <div class="report-card-desc">Completed jobs, site visits, and average time by technician.</div>
    <div class="report-card-footer">
      <span style="font-size: 11px; color: var(--slate4); font-weight: 600;">HR / Evaluation</span>
      <button class="btn btn-sm btn-brand" onclick="openExportModal('tech_performance')">Export</button>
    </div>
  </div>
  <div class="report-card">
    <div class="report-card-title">Revenue Analytics</div>
    <div class="report-card-desc">Total quotation values approved vs rejected by sales owner.</div>
    <div class="report-card-footer">
      <span style="font-size: 11px; color: var(--slate4); font-weight: 600;">Finance</span>
      <button class="btn btn-sm btn-brand" onclick="openExportModal('revenue')">Export</button>
    </div>
  </div>
</div>

<!-- Sales Reports -->
<div class="report-section-title"><span class="badge badge-blue">Sales</span> Sales Operations</div>
<div class="report-grid">
  <div class="report-card">
    <div class="report-card-title">Sales Lead Pipeline</div>
    <div class="report-card-desc">Active leads, current stages, and assigned owners.</div>
    <div class="report-card-footer">
      <span style="font-size: 11px; color: var(--slate4); font-weight: 600;">Lead Tracking</span>
      <button class="btn btn-sm btn-brand" onclick="openExportModal('sales_pipeline')">Export</button>
    </div>
  </div>
  <div class="report-card">
    <div class="report-card-title">Quotation History</div>
    <div class="report-card-desc">All quotations, statuses, versions and subtotals.</div>
    <div class="report-card-footer">
      <span style="font-size: 11px; color: var(--slate4); font-weight: 600;">Quote Tracking</span>
      <button class="btn btn-sm btn-brand" onclick="openExportModal('quotation_history')">Export</button>
    </div>
  </div>
</div>

<!-- Service Reports -->
<div class="report-section-title"><span class="badge badge-green">Service</span> Field Service & Execution</div>
<div class="report-grid">
  <div class="report-card">
    <div class="report-card-title">Service Execution Pipeline</div>
    <div class="report-card-desc">Active service work orders, assigned techs, and current statuses.</div>
    <div class="report-card-footer">
      <span style="font-size: 11px; color: var(--slate4); font-weight: 600;">Service Tracking</span>
      <button class="btn btn-sm btn-brand" onclick="openExportModal('service_pipeline')">Export</button>
    </div>
  </div>
</div>

<!-- Logistics Reports -->
<div class="report-section-title"><span class="badge badge-orange">Logistics</span> Supply Chain</div>
<div class="report-grid">
  <div class="report-card">
    <div class="report-card-title">Part Allocation Status</div>
    <div class="report-card-desc">Parts requested, allocated, consumed, and pending return from field.</div>
    <div class="report-card-footer">
      <span style="font-size: 11px; color: var(--slate4); font-weight: 600;">Consumption</span>
      <button class="btn btn-sm btn-brand" onclick="openExportModal('part_allocations')">Export</button>
    </div>
  </div>
  <div class="report-card">
    <div class="report-card-title">Purchase Order Tracking</div>
    <div class="report-card-desc">Part orders pending and received to track vendor delays.</div>
    <div class="report-card-footer">
      <span style="font-size: 11px; color: var(--slate4); font-weight: 600;">Procurement</span>
      <button class="btn btn-sm btn-brand" onclick="openExportModal('po_tracking')">Export</button>
    </div>
  </div>
</div>

<!-- Inventory Reports -->
<div class="report-section-title"><span class="badge badge-teal">Inventory</span> Warehousing</div>
<div class="report-grid">
  <div class="report-card">
    <div class="report-card-title">Stock Valuation</div>
    <div class="report-card-desc">Current stock levels, reserved quantities, and total financial valuation.</div>
    <div class="report-card-footer">
      <span style="font-size: 11px; color: var(--slate4); font-weight: 600;">Finance</span>
      <button class="btn btn-sm btn-brand" onclick="openExportModal('stock_valuation')">Export</button>
    </div>
  </div>
  <div class="report-card">
    <div class="report-card-title">Low Stock & Reorder</div>
    <div class="report-card-desc">List of parts where current stock has fallen below the reorder level.</div>
    <div class="report-card-footer">
      <span style="font-size: 11px; color: var(--slate4); font-weight: 600;">Alerts</span>
      <button class="btn btn-sm btn-brand" onclick="openExportModal('low_stock')">Export</button>
    </div>
  </div>
  <div class="report-card">
    <div class="report-card-title">Stock Movement Ledger</div>
    <div class="report-card-desc">Complete audit trail of stock IN/OUT/RESERVE actions.</div>
    <div class="report-card-footer">
      <span style="font-size: 11px; color: var(--slate4); font-weight: 600;">Audit</span>
      <button class="btn btn-sm btn-brand" onclick="openExportModal('stock_ledger')">Export</button>
    </div>
  </div>
</div>

<!-- Export Modal -->
<div class="modal-overlay" id="exportModal">
  <div class="modal">
    <div class="modal-header">
      <h3 class="modal-title">Export Report</h3>
      <button class="modal-close" onclick="closeModal('exportModal')">✕</button>
    </div>
    <div class="modal-body">
      <form id="exportForm" action="<?= BASE_URL ?>/reports/export.php" method="GET" target="_blank">
        <input type="hidden" name="report_type" id="exportReportType" value="">
        
        <div class="form-group">
          <label class="form-label">Date Range</label>
          <select class="form-control" name="date_range" id="exportDateRange" onchange="toggleCustomDates()">
            <option value="all_time">All Time</option>
            <option value="today">Today</option>
            <option value="this_week">This Week</option>
            <option value="this_month" selected>This Month</option>
            <option value="last_month">Last Month</option>
            <option value="custom">Custom Date Range...</option>
          </select>
        </div>

        <div id="customDateFields" style="display: none; gap: 10px; margin-top: 10px;">
          <div class="form-group" style="flex:1;">
            <label class="form-label">Start Date</label>
            <input type="date" class="form-control" name="start_date" id="exportStartDate">
          </div>
          <div class="form-group" style="flex:1;">
            <label class="form-label">End Date</label>
            <input type="date" class="form-control" name="end_date" id="exportEndDate">
          </div>
        </div>

        <div class="form-group mt-3">
          <label class="form-label">Format</label>
          <div class="radio-group">
            <label style="display: flex; align-items: center; gap: 6px;">
              <input type="radio" name="format" value="excel" checked> Excel (.csv)
            </label>
          </div>
          <p class="text-muted" style="font-size: 11px; margin-top: 4px;">Generates a CSV file optimized for Microsoft Excel.</p>
        </div>

        <div class="form-actions mt-4" style="display: flex; justify-content: flex-end; gap: 10px;">
          <button type="button" class="btn btn-outline" onclick="closeModal('exportModal')">Cancel</button>
          <button type="submit" class="btn btn-brand" onclick="setTimeout(()=>closeModal('exportModal'), 500)">Download Report</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
function openExportModal(reportType) {
  document.getElementById('exportReportType').value = reportType;
  openModal('exportModal');
}

function toggleCustomDates() {
  const range = document.getElementById('exportDateRange').value;
  const customFields = document.getElementById('customDateFields');
  if (range === 'custom') {
    customFields.style.display = 'flex';
  } else {
    customFields.style.display = 'none';
  }
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
