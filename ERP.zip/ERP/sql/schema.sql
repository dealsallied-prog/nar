-- Smart Home Automation ERP — MySQL Schema
-- Created from Next.js/Drizzle/PostgreSQL original

CREATE DATABASE IF NOT EXISTS smart_home_erp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_home_erp;

-- ---------------------------------------------------------------------------
-- System & Company Settings
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS company_settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  company_name VARCHAR(255) NOT NULL,
  address TEXT,
  phone VARCHAR(50),
  email VARCHAR(100),
  gst_number VARCHAR(50),
  website VARCHAR(100),
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Users & Auth
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name TEXT NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role VARCHAR(30) NOT NULL COMMENT 'ADMIN, SALES, SERVICE_CONTROLLER, TECHNICIAN, LOGISTICS',
  phone VARCHAR(30),
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Customers
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS customers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name TEXT NOT NULL,
  company_name VARCHAR(255) NULL,
  gst_number VARCHAR(50) NULL,
  phone VARCHAR(30),
  email VARCHAR(255),
  address TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Work Orders
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS work_orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_no VARCHAR(40) NOT NULL UNIQUE,
  customer_id INT NOT NULL,
  source VARCHAR(60),
  requirement_description TEXT,
  status VARCHAR(40) NOT NULL DEFAULT 'NEW',
  sales_owner_id INT,
  service_owner_id INT,
  current_owner_id INT,
  created_by_id INT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (sales_owner_id) REFERENCES users(id),
  FOREIGN KEY (service_owner_id) REFERENCES users(id),
  FOREIGN KEY (current_owner_id) REFERENCES users(id),
  FOREIGN KEY (created_by_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Pre-Sale Site Visits
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pre_sale_visits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT NOT NULL,
  assigned_to_id INT,
  scheduled_date DATETIME,
  status VARCHAR(30) NOT NULL DEFAULT 'SCHEDULED' COMMENT 'SCHEDULED, COMPLETED',
  notes TEXT,
  created_by_id INT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME,
  FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
  FOREIGN KEY (assigned_to_id) REFERENCES users(id),
  FOREIGN KEY (created_by_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Quotations
-- ---------------------------------------------------------------------------
-- ---------------------------------------------------------------------------
-- Parts Master (defined early — quotation_items references it)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS parts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sku VARCHAR(60) NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  unit VARCHAR(20) NOT NULL DEFAULT 'pcs',
  unit_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  stock_qty DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  reserved_qty DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  reorder_level DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS quotations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT NOT NULL,
  version INT NOT NULL,
  quotation_no VARCHAR(60) NOT NULL,
  title TEXT,
  notes TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'DRAFT' COMMENT 'DRAFT, SENT, APPROVED, REJECTED, SUPERSEDED',
  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  created_by_id INT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sent_at DATETIME,
  approved_at DATETIME,
  rejected_at DATETIME,
  FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
  FOREIGN KEY (created_by_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS quotation_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  quotation_id INT NOT NULL,
  part_id INT,
  description TEXT NOT NULL,
  quantity DECIMAL(12,2) NOT NULL DEFAULT 1.00,
  unit_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  FOREIGN KEY (quotation_id) REFERENCES quotations(id),
  FOREIGN KEY (part_id) REFERENCES parts(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Technician Groups
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS technician_groups (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS technician_group_members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  group_id INT NOT NULL,
  user_id INT NOT NULL,
  FOREIGN KEY (group_id) REFERENCES technician_groups(id),
  FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Work Order Technician Assignments
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS work_order_assignments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT NOT NULL,
  technician_id INT NOT NULL,
  assigned_by_id INT,
  assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  work_status VARCHAR(20) NOT NULL DEFAULT 'ASSIGNED' COMMENT 'ASSIGNED, IN_PROGRESS, COMPLETED',
  completed_at DATETIME,
  FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
  FOREIGN KEY (technician_id) REFERENCES users(id),
  FOREIGN KEY (assigned_by_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Site Visit Updates
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS site_visit_updates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT NOT NULL,
  technician_id INT,
  remarks TEXT NOT NULL,
  additional_parts_required TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
  FOREIGN KEY (technician_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Parts Master
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS parts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sku VARCHAR(60) NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT,
  unit VARCHAR(20) NOT NULL DEFAULT 'pcs',
  unit_price DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  stock_qty DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  reserved_qty DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  reorder_level DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Work Order Part Requirements
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS work_order_part_requirements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT NOT NULL,
  part_id INT NOT NULL,
  quotation_item_id INT,
  quantity_required DECIMAL(12,2) NOT NULL,
  quantity_reserved DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  quantity_ordered DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  quantity_received DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  status VARCHAR(30) NOT NULL DEFAULT 'PENDING' COMMENT 'PENDING, RESERVED, ORDERED, RECEIVED',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
  FOREIGN KEY (part_id) REFERENCES parts(id),
  FOREIGN KEY (quotation_item_id) REFERENCES quotation_items(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Part Purchase Orders
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS part_orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT NOT NULL,
  part_id INT NOT NULL,
  requirement_id INT,
  quantity DECIMAL(12,2) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'PENDING' COMMENT 'PENDING, ORDERED, RECEIVED, CANCELLED',
  order_reference TEXT,
  created_by_id INT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ordered_at DATETIME,
  received_at DATETIME,
  FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
  FOREIGN KEY (part_id) REFERENCES parts(id),
  FOREIGN KEY (requirement_id) REFERENCES work_order_part_requirements(id),
  FOREIGN KEY (created_by_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Part Allocations
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS part_allocations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT NOT NULL,
  technician_id INT NOT NULL,
  part_id INT NOT NULL,
  requirement_id INT,
  quantity DECIMAL(12,2) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'REQUESTED' COMMENT 'REQUESTED, ALLOCATED, CONSUMED, RETURN_PENDING, RETURNED',
  requested_by_id INT,
  requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  allocated_at DATETIME,
  consumed_at DATETIME,
  returned_at DATETIME,
  notes TEXT,
  FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
  FOREIGN KEY (technician_id) REFERENCES users(id),
  FOREIGN KEY (part_id) REFERENCES parts(id),
  FOREIGN KEY (requirement_id) REFERENCES work_order_part_requirements(id),
  FOREIGN KEY (requested_by_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Stock Ledger
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS stock_ledger (
  id INT AUTO_INCREMENT PRIMARY KEY,
  part_id INT NOT NULL,
  change_type VARCHAR(20) NOT NULL COMMENT 'STOCK_IN, RESERVE, RELEASE, ISSUE, CONSUME, RETURN_IN, ADJUST',
  quantity DECIMAL(12,2) NOT NULL,
  balance_after DECIMAL(12,2) NOT NULL,
  work_order_id INT,
  note TEXT,
  created_by_id INT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (part_id) REFERENCES parts(id),
  FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
  FOREIGN KEY (created_by_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Notifications
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  target_role VARCHAR(30),
  target_user_id INT,
  work_order_id INT,
  message TEXT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (target_user_id) REFERENCES users(id),
  FOREIGN KEY (work_order_id) REFERENCES work_orders(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- Work Order Logs (Audit Trail)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS work_order_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT NOT NULL,
  actor_id INT,
  action TEXT NOT NULL,
  from_status VARCHAR(40),
  to_status VARCHAR(40),
  remarks TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
  FOREIGN KEY (actor_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
