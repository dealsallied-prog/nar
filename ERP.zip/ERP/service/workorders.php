<?php
/**
 * My Active Work Orders (Service Controller)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SERVICE_CONTROLLER']);

$pageTitle = 'My Active Work Orders';
$statusFilter = $_GET['status'] ?? 'ALL';

$sql = "SELECT w.*, c.name AS customer_name 
        FROM work_orders w 
        JOIN customers c ON w.customer_id = c.id 
        WHERE w.service_owner_id = ?";
$params = [$user['id']];

if ($statusFilter !== 'ALL') {
    $sql .= " AND w.status = ?";
    $params[] = $statusFilter;
} else {
    // Hide CLOSED by default if ALL
    $sql .= " AND w.status != 'CLOSED'";
}
$sql .= " ORDER BY w.updated_at DESC";
$wos = dbAll($sql, $params);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>My Active Work Orders</h1>
    <p>Work orders you are currently managing.</p>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title">My Work Orders</div>
    <form method="GET">
      <select name="status" onchange="this.form.submit()" class="form-control" style="width: 200px; padding: 6px; border-radius: 4px;">
        <option value="ALL" <?= $statusFilter === 'ALL' ? 'selected' : '' ?>>All Active</option>
        <?php foreach(WO_STATUS_LABEL as $val => $label): ?>
          <option value="<?= $val ?>" <?= $statusFilter === $val ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Work Order #</th>
          <th>Customer</th>
          <th>Status</th>
          <th>Last Updated</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$wos): ?>
          <tr><td colspan="5" class="empty-state">No active work orders.</td></tr>
        <?php else: foreach ($wos as $w): ?>
          <tr>
            <td class="font-mono"><a href="workorder_view.php?id=<?= $w['id'] ?>"><strong><?= e($w['work_order_no']) ?></strong></a></td>
            <td style="font-weight:600"><?= e($w['customer_name']) ?></td>
            <td><span class="<?= badgeClass($w['status']) ?>"><?= e(woStatusLabel($w['status'])) ?></span></td>
            <td><?= dtShort($w['updated_at']) ?></td>
            <td><a href="workorder_view.php?id=<?= $w['id'] ?>" class="btn btn-sm btn-ghost">Manage</a></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
