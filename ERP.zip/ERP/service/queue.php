<?php
/**
 * Service Queue (New / Unassigned Work Orders)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SERVICE_CONTROLLER']);

if (isset($_POST['accept_wo'])) {
    $woId = (int)$_POST['wo_id'];
    $hasTech = dbOne("SELECT id FROM pre_sale_visits WHERE work_order_id=? AND visit_type='TECHNICAL' AND status='COMPLETED'", [$woId]);
    
    if ($hasTech) {
        dbExec("UPDATE work_orders SET status='TECH_VISIT_DONE', service_owner_id=? WHERE id=? AND status='HANDED_TO_SERVICE'", [$user['id'], $woId]);
        addLog($woId, $user['id'], 'Accepted Work Order (Skipped Tech Visit)', 'HANDED_TO_SERVICE', 'TECH_VISIT_DONE');
    } else {
        dbExec("UPDATE work_orders SET status='SERVICE_ACCEPTED', service_owner_id=? WHERE id=? AND status='HANDED_TO_SERVICE'", [$user['id'], $woId]);
        addLog($woId, $user['id'], 'Accepted Work Order', 'HANDED_TO_SERVICE', 'SERVICE_ACCEPTED');
    }
    
    setFlash('success', 'Work order accepted. You are now the Work Controller.');
    redirect("workorder_view.php?id=$woId");
}

$pageTitle = 'Service Queue';
// Show WOs handed to service but not yet accepted
$sql = "SELECT w.*, c.name AS customer_name, c.phone 
        FROM work_orders w 
        JOIN customers c ON w.customer_id = c.id 
        WHERE w.status = 'HANDED_TO_SERVICE' 
        ORDER BY w.updated_at ASC";
$queue = dbAll($sql);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Service Queue</h1>
    <p>New work orders handed over from Sales. Accept to take ownership.</p>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Work Order #</th>
          <th>Handed Over</th>
          <th>Customer</th>
          <th>Requirement</th>
          <th>Notes from Sales</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$queue): ?>
          <tr><td colspan="6" class="empty-state">Queue is empty. No new work orders.</td></tr>
        <?php else: foreach ($queue as $q): ?>
          <tr>
            <td class="font-mono"><strong><?= e($q['work_order_no']) ?></strong></td>
            <td><?= dtShort($q['updated_at']) ?></td>
            <td>
              <div style="font-weight: 600; color: var(--navy2)"><?= e($q['customer_name']) ?></div>
              <div style="font-size: 11px; color: var(--slate5)"><?= e($q['phone']) ?></div>
            </td>
            <td><div style="max-height:40px; overflow:hidden; text-overflow:ellipsis; max-width:250px;"><?= e($q['requirement_description']) ?></div></td>
            <td><div style="max-height:40px; overflow:hidden; text-overflow:ellipsis; max-width:200px;" class="text-sm"><?= e($q['handover_note']?:'—') ?></div></td>
            <td>
              <form method="POST" style="display:inline-block">
                <input type="hidden" name="wo_id" value="<?= $q['id'] ?>">
                <button type="submit" name="accept_wo" class="btn btn-sm btn-primary">Accept & Take Ownership</button>
              </form>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
