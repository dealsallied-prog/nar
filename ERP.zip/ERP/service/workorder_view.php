<?php
/**
 * Service Controller WO View & Management
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SERVICE_CONTROLLER']);

$id = (int)($_GET['id'] ?? 0);
$wo = dbOne("SELECT w.*, c.name AS customer_name, c.phone, c.address 
             FROM work_orders w JOIN customers c ON w.customer_id = c.id 
             WHERE w.id=?", [$id]);
if (!$wo) die("Work order not found.");

// Schedule Tech Visit
if (isset($_POST['schedule_tech_visit'])) {
    $date = trim($_POST['visit_date']);
    $notes = trim($_POST['notes']);
    $techIds = $_POST['tech_ids'] ?? [];
    
    if (empty($techIds)) {
        setFlash('error', 'Please select at least one technician.');
        redirect("workorder_view.php?id=$id");
    }

    $assignedToId = $techIds[0];
    $assignedTechsStr = implode(',', $techIds);
    
    dbExec("INSERT INTO pre_sale_visits (work_order_id, assigned_to_id, assigned_techs, scheduled_date, status, notes, created_by_id, visit_type) 
            VALUES (?, ?, ?, ?, 'SCHEDULED', ?, ?, 'TECHNICAL')",
        [$id, $assignedToId, $assignedTechsStr, $date?:null, $notes, $user['id']]);
    
    dbExec("UPDATE work_orders SET status='TECH_VISIT_SCHEDULED' WHERE id=?", [$id]);
    addLog($id, $user['id'], 'Scheduled Technical Visit', $wo['status'], 'TECH_VISIT_SCHEDULED');
    
    foreach ($techIds as $tid) {
        notify("You have been assigned a Technical Site Visit for {$wo['work_order_no']}", $tid, null, $id);
    }
    
    setFlash('success', 'Technical site visit scheduled.');
    redirect("workorder_view.php?id=$id");
}

// Send to Sales for Revision
if (isset($_POST['send_to_sales'])) {
    $notes = trim($_POST['revision_notes']);
    dbExec("UPDATE work_orders SET status='REVISION_IN_PROGRESS', revision_change_list=? WHERE id=?", [$notes, $id]);
    addLog($id, $user['id'], 'Sent to Sales for Quote Revision', $wo['status'], 'REVISION_IN_PROGRESS', $notes);
    notify("Work order {$wo['work_order_no']} requires a revised quote.", null, 'SALES', $id);
    setFlash('success', 'Sent back to Sales for revision.');
    redirect("workorder_view.php?id=$id");
}

// Send to Logistics
if (isset($_POST['send_to_logistics'])) {
    // We need the approved quotation items to create part requirements
    $q = dbOne("SELECT id FROM quotations WHERE work_order_id=? AND status='APPROVED' ORDER BY version DESC LIMIT 1", [$id]);
    if ($q) {
        $items = dbAll("SELECT * FROM quotation_items WHERE quotation_id=? AND item_type='PARTS'", [$q['id']]);
        foreach ($items as $it) {
            if ($it['part_id']) {
                // Check if already requested (in case of revisions)
                $ext = dbOne("SELECT id FROM work_order_part_requirements WHERE work_order_id=? AND part_id=?", [$id, $it['part_id']]);
                if (!$ext) {
                    dbExec("INSERT INTO work_order_part_requirements (work_order_id, part_id, quotation_item_id, quantity_required) VALUES (?,?,?,?)",
                        [$id, $it['part_id'], $it['id'], $it['quantity']]);
                }
            }
        }
    }
    dbExec("UPDATE work_orders SET status='SENT_TO_LOGISTICS' WHERE id=?", [$id]);
    addLog($id, $user['id'], 'Sent Parts to Logistics', $wo['status'], 'SENT_TO_LOGISTICS');
    notify("New part requirements for {$wo['work_order_no']}. Please review stock.", null, 'LOGISTICS', $id);
    setFlash('success', 'Parts list sent to Logistics.');
    redirect("workorder_view.php?id=$id");
}

// Schedule Engineer Visit & Request Parts
if (isset($_POST['schedule_engineer'])) {
    $date = trim($_POST['exec_date']);
    $notes = trim($_POST['exec_notes']);
    $techId = (int)$_POST['exec_tech_id']; // primary tech for now
    
    // Assign Tech
    dbExec("INSERT INTO work_order_assignments (work_order_id, technician_id, assigned_by_id) VALUES (?,?,?)", [$id, $techId, $user['id']]);
    
    dbExec("UPDATE work_orders SET status='ENGINEER_VISIT_SCHEDULED' WHERE id=?", [$id]);
    addLog($id, $user['id'], 'Scheduled Engineer Visit', $wo['status'], 'ENGINEER_VISIT_SCHEDULED');
    
    setFlash('success', 'Engineer Visit Scheduled. You can now request part allocations for them.');
    redirect("workorder_view.php?id=$id");
}

// Close WO
if (isset($_POST['close_wo'])) {
    dbExec("UPDATE work_orders SET status='CLOSED' WHERE id=?", [$id]);
    addLog($id, $user['id'], 'Closed Work Order', $wo['status'], 'CLOSED');
    setFlash('success', 'Work order closed.');
    redirect("workorder_view.php?id=$id");
}

// Data fetching
$visits = dbAll("SELECT v.*, u.name as tech_name FROM pre_sale_visits v LEFT JOIN users u ON v.assigned_to_id=u.id WHERE v.work_order_id=? AND v.visit_type='TECHNICAL' ORDER BY v.id DESC", [$id]);
$partReqs = dbAll("SELECT pr.*, p.sku, p.name FROM work_order_part_requirements pr JOIN parts p ON pr.part_id=p.id WHERE pr.work_order_id=?", [$id]);
$techs = dbAll("SELECT id, name FROM users WHERE role='TECHNICIAN' AND active=1");
$logs = dbAll("SELECT l.*, u.name as actor FROM work_order_logs l LEFT JOIN users u ON l.actor_id=u.id WHERE l.work_order_id=? ORDER BY l.id DESC", [$id]);
$quotes = dbAll("SELECT id, version, status, total, revision_reason, approval_proof FROM quotations WHERE work_order_id=? ORDER BY version DESC", [$id]);

$pageTitle = $wo['work_order_no'];
require_once __DIR__ . '/../includes/header.php';
?>

<div class="breadcrumb">
  <a href="workorders.php">Active Work Orders</a> <span>›</span>
  <?= e($wo['work_order_no']) ?>
</div>

<div class="page-header">
  <div>
    <h1><?= e($wo['work_order_no']) ?></h1>
    <p><?= e($wo['customer_name']) ?> — <span class="<?= badgeClass($wo['status']) ?>"><?= e(woStatusLabel($wo['status'])) ?></span></p>
  </div>
  <div class="page-actions">
    <?php if ($wo['status'] === 'SERVICE_ACCEPTED'): ?>
      <?php $hasCompletedTech = dbOne("SELECT id FROM pre_sale_visits WHERE work_order_id=? AND visit_type='TECHNICAL' AND status='COMPLETED'", [$id]); ?>
      <?php if ($hasCompletedTech): ?>
        <form method="POST" style="display:inline-block"><button type="submit" name="send_to_logistics" class="btn btn-primary">📤 Send to Logistics (Tech Visit Done)</button></form>
        <button class="btn btn-outline-sky" onclick="openModal('techVisitModal')">📅 Schedule Another Tech Visit</button>
      <?php else: ?>
        <button class="btn btn-primary" onclick="openModal('techVisitModal')">📅 Schedule Tech Visit</button>
        <form method="POST" style="display:inline-block"><button type="submit" name="send_to_logistics" class="btn btn-ghost" onclick="return confirm('Skip Tech Visit and send parts to Logistics directly?')">Skip to Logistics</button></form>
      <?php endif; ?>
    <?php elseif ($wo['status'] === 'TECH_VISIT_DONE'): ?>
      <button class="btn btn-warning" onclick="openModal('revisionModal')">🔙 Send to Sales for Revision</button>
      <form method="POST" style="display:inline-block"><button type="submit" name="send_to_logistics" class="btn btn-primary">📤 Send to Logistics</button></form>
    <?php elseif ($wo['status'] === 'FINAL_QUOTE_APPROVED'): ?>
      <form method="POST" style="display:inline-block"><button type="submit" name="send_to_logistics" class="btn btn-primary">📤 Send to Logistics</button></form>
    <?php elseif ($wo['status'] === 'PARTS_RECEIVED'): ?>
      <button class="btn btn-primary" onclick="openModal('execVisitModal')">👷 Schedule Engineer Visit</button>
    <?php elseif ($wo['status'] === 'ENGINEER_VISIT_SCHEDULED'): ?>
      <a href="../logistics/allocations.php" class="btn btn-primary">📦 Request Part Allocation</a>
    <?php elseif ($wo['status'] === 'COMPLETED'): ?>
      <form method="POST" style="display:inline-block"><button type="submit" name="close_wo" class="btn btn-success" onclick="return confirm('Close this Work Order?')">🏁 Close Work Order</button></form>
    <?php endif; ?>
  </div>
</div>

<div class="section status-timeline card">
  <div class="card-body" style="padding: 14px 20px;">
    <div class="status-timeline">
      <?php foreach (MASTER_STATUS_ORDER as $st): 
          $isActive = ($wo['status'] === $st);
          $isDone = array_search($wo['status'], MASTER_STATUS_ORDER) > array_search($st, MASTER_STATUS_ORDER);
          $cls = $isActive ? 'active' : ($isDone ? 'done' : '');
      ?>
      <div class="timeline-step">
        <div class="timeline-dot <?= $cls ?>"><?= $isDone ? '✓' : '' ?></div>
        <div class="timeline-label <?= $cls ?>"><?= e(woStatusLabel($st)) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="tabs">
  <button class="tab-btn active" data-tab-group="svc" data-tab="visits" onclick="switchTab('visits','svc')">Site Visits</button>
  <button class="tab-btn" data-tab-group="svc" data-tab="parts" onclick="switchTab('parts','svc')">Parts Tracking (<?= count($partReqs) ?>)</button>
  <button class="tab-btn" data-tab-group="svc" data-tab="quotes" onclick="switchTab('quotes','svc')">Quotations</button>
  <button class="tab-btn" data-tab-group="svc" data-tab="logs" onclick="switchTab('logs','svc')">Audit Log</button>
</div>

<!-- VISITS TAB -->
<div class="tab-panel active" data-tab-panel-group="svc" data-panel="visits">
  <div class="card">
    <div class="card-header"><div class="card-title">Technical Site Visits</div></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>Date</th><th>Technician</th><th>Status</th><th>Findings / Remarks</th></tr>
        </thead>
        <tbody>
          <?php if(!$visits): ?><tr><td colspan="4" class="empty-state">No tech visits scheduled.</td></tr><?php endif; ?>
          <?php foreach($visits as $v): ?>
          <tr>
            <td><?= dt($v['scheduled_date']) ?></td>
            <td>
              <?php 
                if (!empty($v['assigned_techs'])) {
                    $techIds = explode(',', $v['assigned_techs']);
                    $names = [];
                    foreach($techIds as $tid) {
                        $names[] = e(dbOne("SELECT name FROM users WHERE id=?", [$tid])['name'] ?? 'Unknown');
                    }
                    echo implode(', ', $names);
                } else {
                    echo e($v['tech_name'] ?? '—');
                }
              ?>
            </td>
            <td><span class="<?= badgeClass($v['status']==='COMPLETED'?'COMPLETED':'PENDING') ?>"><?= e($v['status']) ?></span></td>
            <td>
              <?= nl2br(e($v['measurements'] ?: $v['notes'] ?: '—')) ?>
              <?php 
                if (!empty($v['photos'])) {
                    $photos = json_decode($v['photos'] ?? '[]', true);
                    if (is_array($photos) && count($photos) > 0) {
                        echo '<div style="margin-top:8px;"><span class="badge badge-blue">📎 ' . count($photos) . ' Media File(s) Attached</span></div>';
                        echo '<div style="margin-top:4px;"><a href="' . BASE_URL . '/technician/visit_view.php?id=' . $v['id'] . '" target="_blank" class="text-sky text-sm">View Full Report</a></div>';
                    }
                }
              ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- PARTS TAB -->
<div class="tab-panel" data-tab-panel-group="svc" data-panel="parts">
  <div class="card">
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>Part (SKU)</th>
            <th>Required Qty</th>
            <th>Reserved (Stock)</th>
            <th>Ordered</th>
            <th>Received</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <?php if(!$partReqs): ?><tr><td colspan="6" class="empty-state">No parts requested yet. Send to logistics.</td></tr><?php endif; ?>
          <?php foreach($partReqs as $pr): ?>
          <tr>
            <td>
              <div style="font-weight:600"><?= e($pr['name']) ?></div>
              <div class="text-sm text-muted"><?= e($pr['sku']) ?></div>
            </td>
            <td><?= qty($pr['quantity_required']) ?></td>
            <td><?= qty($pr['quantity_reserved']) ?></td>
            <td><?= qty($pr['quantity_ordered']) ?></td>
            <td><?= qty($pr['quantity_received']) ?></td>
            <td><span class="<?= badgeClass($pr['status']) ?>"><?= e($pr['status']) ?></span></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- QUOTES TAB -->
<div class="tab-panel" data-tab-panel-group="svc" data-panel="quotes">
  <div class="card">
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>Version</th><th>Status</th><th>Total</th><th>Revision Reason</th><th>Approval Proof</th><th style="text-align:right;">Actions</th></tr>
        </thead>
        <tbody>
          <?php foreach($quotes as $q): ?>
          <tr>
            <td><span class="tag bg-slate2">V<?= $q['version'] ?></span></td>
            <td><span class="<?= badgeClass($q['status']) ?>"><?= e($q['status']) ?></span></td>
            <td><?= money($q['total']) ?></td>
            <td><?= e($q['revision_reason']?:'—') ?></td>
            <td>
              <?php 
                $proof = json_decode($q['approval_proof'] ?? '', true);
                if (is_array($proof)) {
                    echo e($proof['text'] ?: '—');
                    if (!empty($proof['file'])) {
                        echo '<br><a href="' . BASE_URL . '/uploads/approvals/' . e($proof['file']) . '" target="_blank" class="text-sky text-sm" style="display:inline-flex; align-items:center; gap:4px; margin-top:4px;"><span style="font-size:16px;">📎</span> View File</a>';
                    }
                } else {
                    echo e($q['approval_proof'] ?: '—');
                }
              ?>
            </td>
            <td style="text-align:right;">
              <a href="<?= BASE_URL ?>/sales/quotation_print.php?id=<?= $q['id'] ?>" target="_blank" class="btn btn-xs btn-outline-sky">🖨️ View PDF</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- LOGS TAB -->
<div class="tab-panel" data-tab-panel-group="svc" data-panel="logs">
  <div class="card">
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Time</th><th>User</th><th>Action</th><th>Status Change</th></tr></thead>
        <tbody>
          <?php foreach($logs as $l): ?>
          <tr>
            <td><?= dt($l['created_at']) ?></td>
            <td><?= e($l['actor']) ?></td>
            <td><strong><?= e($l['action']) ?></strong><br><span class="text-sm text-muted"><?= e($l['remarks']) ?></span></td>
            <td>
              <?php if($l['from_status'] && $l['from_status'] !== $l['to_status']): ?>
                <span class="text-muted"><?= e(woStatusLabel($l['from_status'])) ?></span> → 
              <?php endif; ?>
              <?php if($l['to_status']): ?>
                <span class="text-sm font-semibold"><?= e(woStatusLabel($l['to_status'])) ?></span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modals -->
<div id="techVisitModal" class="modal-overlay">
  <div class="modal-box">
    <h3 class="modal-title">Schedule Technical Site Visit</h3>
    <form method="POST">
      <div class="form-group">
        <label>Assign Technician(s)</label>
        <select name="tech_ids[]" multiple required style="height:120px;" class="form-control">
          <?php foreach($techs as $t): ?><option value="<?= $t['id'] ?>"><?= e($t['name']) ?></option><?php endforeach; ?>
        </select>
        <p class="text-sm text-muted" style="margin-top:4px;">Hold Ctrl (Windows) or Cmd (Mac) to select multiple technicians.</p>
      </div>
      <div class="form-group" style="margin-top:12px;"><label>Date & Time</label><input type="datetime-local" name="visit_date"></div>
      <div class="form-group" style="margin-top:12px;"><label>Notes / Instructions</label><textarea name="notes"></textarea></div>
      <div style="margin-top:20px; display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn btn-ghost" onclick="closeModal('techVisitModal')">Cancel</button>
        <button type="submit" name="schedule_tech_visit" class="btn btn-primary">Schedule</button>
      </div>
    </form>
  </div>
</div>

<div id="revisionModal" class="modal-overlay">
  <div class="modal-box">
    <h3 class="modal-title">Send to Sales for Revision</h3>
    <form method="POST">
      <div class="form-group">
        <label>Notes for Sales (Parts to add/remove)</label>
        <textarea name="revision_notes" rows="5" required placeholder="e.g. Add 2 more sensors, remove 1 camera..."></textarea>
      </div>
      <div style="margin-top:20px; display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn btn-ghost" onclick="closeModal('revisionModal')">Cancel</button>
        <button type="submit" name="send_to_sales" class="btn btn-warning">Send to Sales</button>
      </div>
    </form>
  </div>
</div>

<div id="execVisitModal" class="modal-overlay">
  <div class="modal-box">
    <h3 class="modal-title">Schedule Engineer Visit (Execution)</h3>
    <form method="POST">
      <div class="form-group">
        <label>Primary Technician</label>
        <select name="exec_tech_id" required>
          <option value="">Select Tech...</option>
          <?php foreach($techs as $t): ?><option value="<?= $t['id'] ?>"><?= e($t['name']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="form-group" style="margin-top:12px;"><label>Date & Time</label><input type="datetime-local" name="exec_date" required></div>
      <div class="form-group" style="margin-top:12px;"><label>Notes for Execution</label><textarea name="exec_notes"></textarea></div>
      <div style="margin-top:20px; display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn btn-ghost" onclick="closeModal('execVisitModal')">Cancel</button>
        <button type="submit" name="schedule_engineer" class="btn btn-primary">Schedule Execution</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
