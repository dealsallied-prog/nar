<?php
/**
 * Technical Site Visits List (Service)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SERVICE_CONTROLLER']);

$pageTitle = 'Technical Site Visits';

$sql = "SELECT v.*, w.work_order_no, c.name as customer_name, u.name as tech_name 
        FROM pre_sale_visits v 
        JOIN work_orders w ON v.work_order_id = w.id 
        JOIN customers c ON w.customer_id = c.id 
        LEFT JOIN users u ON v.assigned_to_id = u.id
        WHERE v.visit_type = 'TECHNICAL' 
        ORDER BY v.scheduled_date DESC";
$visits = dbAll($sql);

require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><div><h1>Technical Site Visits</h1><p>All technical surveys assigned to technicians.</p></div></div>
<div class="card"><div class="table-wrap"><table class="data-table">
  <thead><tr><th>Date</th><th>Work Order</th><th>Customer</th><th>Technician</th><th>Status</th><th>Action</th></tr></thead>
  <tbody>
    <?php foreach ($visits as $v): ?>
      <tr>
        <td><?= dtShort($v['scheduled_date']) ?></td>
        <td><a href="workorder_view.php?id=<?= $v['work_order_id'] ?>"><strong><?= e($v['work_order_no']) ?></strong></a></td>
        <td><?= e($v['customer_name']) ?></td>
        <td><?= e($v['tech_name']) ?></td>
        <td><span class="<?= badgeClass($v['status']=='COMPLETED'?'COMPLETED':'PENDING') ?>"><?= e($v['status']) ?></span></td>
        <td><a href="workorder_view.php?id=<?= $v['work_order_id'] ?>" class="btn btn-xs btn-outline-sky">View WO</a></td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table></div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
