<?php
/**
 * Pending Revised Quotes (Service)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SERVICE_CONTROLLER']);

$pageTitle = 'Pending Revised Quotes';

$sql = "SELECT w.*, c.name as customer_name 
        FROM work_orders w 
        JOIN customers c ON w.customer_id = c.id 
        WHERE w.status = 'FINAL_QUOTE_APPROVED' 
        ORDER BY w.updated_at DESC";
$wos = dbAll($sql);

require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><div><h1>Pending Revised Quotes</h1><p>Work orders returned from Sales with customer approval on the revised quote.</p></div></div>
<div class="card"><div class="table-wrap"><table class="data-table">
  <thead><tr><th>Work Order</th><th>Customer</th><th>Updated On</th><th>Action</th></tr></thead>
  <tbody>
    <?php if(!$wos): ?><tr><td colspan="4" class="empty-state">No pending revised quotes.</td></tr><?php endif; ?>
    <?php foreach ($wos as $w): ?>
      <tr>
        <td><a href="workorder_view.php?id=<?= $w['id'] ?>"><strong><?= e($w['work_order_no']) ?></strong></a></td>
        <td><?= e($w['customer_name']) ?></td>
        <td><?= dtShort($w['updated_at']) ?></td>
        <td>
           <form method="POST" action="workorder_view.php?id=<?= $w['id'] ?>">
             <button type="submit" name="send_to_logistics" class="btn btn-sm btn-primary">Send Parts to Logistics</button>
           </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </tbody>
</table></div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
