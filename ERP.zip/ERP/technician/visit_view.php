<?php
/**
 * Technician Visit View & Completion
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['TECHNICIAN', 'ADMIN']);

$id = (int)($_GET['id'] ?? 0);
$sql = "SELECT v.*, w.work_order_no, w.status as wo_status, w.customer_id, c.name as customer_name, c.phone, c.email, c.address 
        FROM pre_sale_visits v 
        JOIN work_orders w ON v.work_order_id = w.id 
        JOIN customers c ON w.customer_id = c.id 
        WHERE v.id = ? AND v.visit_type = 'TECHNICAL'";
$v = dbOne($sql, [$id]);

if (!$v) die("Visit not found.");

// Verify access
if ($user['role'] === 'TECHNICIAN' && $v['assigned_to_id'] != $user['id'] && strpos(','.$v['assigned_techs'].',', ','.$user['id'].',') === false) {
    die("Access denied.");
}

$woId = $v['work_order_id'];

$latestQuote = dbOne("SELECT id, version, status FROM quotations WHERE work_order_id = ? ORDER BY version DESC LIMIT 1", [$woId]);
$quotedParts = [];
if ($latestQuote) {
    $quotedParts = dbAll("SELECT q.*, p.sku, p.name FROM quotation_items q LEFT JOIN parts p ON q.part_id = p.id WHERE q.quotation_id = ? ORDER BY q.id ASC", [$latestQuote['id']]);
}

// Complete Visit
if (isset($_POST['complete_visit'])) {
    $meas = trim($_POST['measurements']);
    $needsRevision = isset($_POST['needs_revision']) ? 1 : 0;
    
    $photos = [];
    $uploadDir = __DIR__ . '/../uploads/visits/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
    
    if (!empty($_FILES['media']['name'][0])) {
        foreach ($_FILES['media']['name'] as $i => $name) {
            if ($_FILES['media']['error'][$i] === UPLOAD_ERR_OK) {
                $tmpName = $_FILES['media']['tmp_name'][$i];
                $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                $newName = uniqid('vis_') . '.' . $ext;
                if (move_uploaded_file($tmpName, $uploadDir . $newName)) {
                    $photos[] = [
                        'file' => $newName,
                        'caption' => trim($_POST['captions'][$i] ?? ''),
                        'type' => (strpos($_FILES['media']['type'][$i], 'video') !== false || in_array($ext, ['mp4','webm','mov'])) ? 'video' : 'image'
                    ];
                }
            }
        }
    }
    
    $photosJson = !empty($photos) ? json_encode($photos) : null;
    
    dbExec("UPDATE pre_sale_visits SET status='COMPLETED', measurements=?, photos=?, completed_at=NOW() WHERE id=?", [$meas, $photosJson, $id]);
    
    if ($needsRevision) {
        // Flag for Service Controller to request revision
        dbExec("UPDATE work_orders SET status='TECH_VISIT_DONE', revision_change_list=? WHERE id=?", [$meas, $woId]);
        addLog($woId, $user['id'], 'Technical Visit Completed (Revision Flagged)', $v['wo_status'], 'TECH_VISIT_DONE', 'Revision required: ' . $meas);
        notify("Technician flagged extra requirements during site visit for {$v['work_order_no']}. Please review and send to Sales.", null, 'SERVICE_CONTROLLER', $woId);
        setFlash('warning', 'Visit completed and flagged for the Service Controller to review.');
    } else {
        // Just complete the technical visit
        dbExec("UPDATE work_orders SET status='TECH_VISIT_DONE' WHERE id=?", [$woId]);
        addLog($woId, $user['id'], 'Technical Visit Completed', $v['wo_status'], 'TECH_VISIT_DONE');
        notify("Technical site visit completed for {$v['work_order_no']}", null, 'SERVICE_CONTROLLER', $woId);
        setFlash('success', 'Technical Site Visit marked as completed successfully.');
    }
    
    redirect("visit_view.php?id=$id");
}

$pageTitle = "Visit for " . $v['work_order_no'];
require_once __DIR__ . '/../includes/header.php';
?>

<div class="breadcrumb">
  <a href="visits.php">My Site Visits</a> <span>›</span>
  Visit #<?= $id ?>
</div>

<div class="page-header">
  <div>
    <h1>Site Visit: <?= e($v['work_order_no']) ?></h1>
    <p><?= e($v['customer_name']) ?> — <span class="<?= badgeClass($v['status']=='COMPLETED'?'COMPLETED':'PENDING') ?>"><?= e($v['status']) ?></span></p>
  </div>
  <div class="page-actions">
    <?php if ($v['status'] !== 'COMPLETED'): ?>
      <button class="btn btn-success" onclick="openModal('completeModal')">✅ Mark Completed</button>
    <?php endif; ?>
  </div>
</div>

<div class="detail-grid">
  <!-- Customer Details -->
  <div class="card">
    <div class="card-header"><div class="card-title">Customer Details</div></div>
    <div class="card-body">
      <table class="qi-table" style="border:none;">
        <tr><td style="width:120px; font-weight:600; color:var(--slate5); border:none; padding:8px 0;">Customer</td><td style="border:none; padding:8px 0; font-weight:600;"><?= e($v['customer_name']) ?></td></tr>
        <tr><td style="font-weight:600; color:var(--slate5); border:none; padding:8px 0;">Phone</td><td style="border:none; padding:8px 0;"><a href="tel:<?= e($v['phone']) ?>" class="text-sky"><?= e($v['phone']) ?></a></td></tr>
        <tr><td style="font-weight:600; color:var(--slate5); border:none; padding:8px 0;">Address</td><td style="border:none; padding:8px 0;"><?= nl2br(e($v['address'])) ?></td></tr>
      </table>
    </div>
  </div>

  <!-- Instructions -->
  <div class="card">
    <div class="card-header"><div class="card-title">Schedule & Instructions</div></div>
    <div class="card-body">
      <table class="qi-table" style="border:none;">
        <tr><td style="width:120px; font-weight:600; color:var(--slate5); border:none; padding:8px 0;">Scheduled Date</td><td style="border:none; padding:8px 0;"><?= dt($v['scheduled_date']) ?></td></tr>
        <tr><td style="font-weight:600; color:var(--slate5); border:none; padding:8px 0;">Instructions</td><td style="border:none; padding:8px 0;"><?= nl2br(e($v['notes'] ?: 'No specific instructions provided.')) ?></td></tr>
      </table>
    </div>
  </div>
</div>

<?php if ($latestQuote): ?>
<div class="card" style="margin-top: 24px;">
  <div class="card-header"><div class="card-title">Quoted Parts List (V<?= $latestQuote['version'] ?>)</div></div>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Part / Description</th>
          <th style="width:100px; text-align:center;">Qty</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$quotedParts): ?>
          <tr><td colspan="2" class="empty-state">No parts found in this quotation.</td></tr>
        <?php else: foreach ($quotedParts as $qp): ?>
          <tr>
            <td>
              <?php if ($qp['part_id']): ?>
                <div style="font-weight:600;"><?= e($qp['name']) ?> <span class="text-sm text-muted">(<?= e($qp['sku']) ?>)</span></div>
                <?php if ($qp['description']): ?>
                  <div class="text-sm text-muted" style="margin-top:4px;"><?= nl2br(e($qp['description'])) ?></div>
                <?php endif; ?>
              <?php else: ?>
                <div style="font-weight:600;"><?= e($qp['description']) ?></div>
              <?php endif; ?>
            </td>
            <td style="text-align:center; font-weight:600;"><?= e((float)$qp['quantity']) ?></td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php if ($v['status'] === 'COMPLETED'): ?>
<div class="card" style="margin-top: 24px;">
  <div class="card-header"><div class="card-title">Completion Details</div></div>
  <div class="card-body">
    <div style="margin-bottom:16px;">
      <h4 style="font-size:13px; font-weight:600; color:var(--slate5); margin-bottom:4px; text-transform:uppercase;">Findings / Notes</h4>
      <p style="white-space:pre-wrap; line-height:1.5; color:var(--text);"><?= e($v['measurements'] ?: '—') ?></p>
    </div>
    
    <h4 style="font-size:13px; font-weight:600; color:var(--slate5); margin-bottom:12px; text-transform:uppercase;">Photos / Media</h4>
    <?php 
    $media = json_decode($v['photos'] ?? '[]', true);
    if ($media && is_array($media) && count($media) > 0): 
    ?>
      <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap:16px;">
        <?php foreach ($media as $m): ?>
          <div style="border: 1px solid var(--border); border-radius:8px; overflow:hidden; background:#fff;">
            <?php if ($m['type'] === 'video'): ?>
              <video src="<?= BASE_URL ?>/uploads/visits/<?= e($m['file']) ?>" controls style="width:100%; height:150px; object-fit:cover; display:block;"></video>
            <?php else: ?>
              <a href="<?= BASE_URL ?>/uploads/visits/<?= e($m['file']) ?>" target="_blank">
                <img src="<?= BASE_URL ?>/uploads/visits/<?= e($m['file']) ?>" style="width:100%; height:150px; object-fit:cover; display:block;">
              </a>
            <?php endif; ?>
            <?php if (!empty($m['caption'])): ?>
              <div style="padding:8px 12px; font-size:13px; color:var(--slate6); border-top:1px solid var(--border); background:#f8fafc;">
                <?= e($m['caption']) ?>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="text-sm text-muted">No media uploaded.</p>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<!-- Modals -->
<div id="completeModal" class="modal-overlay">
  <div class="modal-box" style="max-width: 600px;">
    <h3 class="modal-title">Mark Visit Completed</h3>
    <p class="text-sm text-muted" style="margin-bottom:16px;">Record findings, measurements, and upload onsite photos.</p>
    <form method="POST" enctype="multipart/form-data">
      <div class="form-group">
        <label>Findings / Notes</label>
        <textarea name="measurements" rows="4" placeholder="Enter any extra requirements, site conditions, measurements, etc."></textarea>
      </div>
      
      <div class="form-group" style="margin-top:16px;">
        <label>
          <input type="checkbox" name="needs_revision" value="1">
          <strong>Requires Quote Revision</strong>
        </label>
        <p class="text-sm text-muted" style="margin-top:4px; margin-left:24px;">Check this box if extra parts are required and the quote needs to be revised. This will notify the Service Controller to validate and send a revision request to Sales.</p>
      </div>

      <div style="border: 1px solid var(--border); padding: 16px; border-radius: 6px; margin-top:20px;">
        <h4 style="font-size:14px; font-weight:600; margin-bottom:12px;">Upload Photos / Videos</h4>
        <div id="mediaUploads">
          <div class="media-row" style="display:flex; gap:10px; margin-bottom:10px; align-items:center;">
            <input type="file" name="media[]" accept="image/*,video/*" class="form-control" style="flex:1;">
            <input type="text" name="captions[]" placeholder="Caption (optional)" class="form-control" style="flex:1;">
          </div>
        </div>
        <button type="button" class="btn btn-sm btn-outline-sky" onclick="addMediaRow()">+ Add Another File</button>
      </div>

      <div style="margin-top:20px; display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn btn-ghost" onclick="closeModal('completeModal')">Cancel</button>
        <button type="submit" name="complete_visit" class="btn btn-success">Mark Completed</button>
      </div>
    </form>
  </div>
</div>

<script>
function addMediaRow() {
    const row = document.createElement('div');
    row.className = 'media-row';
    row.style.cssText = 'display:flex; gap:10px; margin-bottom:10px; align-items:center;';
    row.innerHTML = `
        <input type="file" name="media[]" accept="image/*,video/*" class="form-control" style="flex:1;">
        <input type="text" name="captions[]" placeholder="Caption (optional)" class="form-control" style="flex:1;">
        <button type="button" class="btn btn-sm btn-danger" onclick="this.parentElement.remove()">X</button>
    `;
    document.getElementById('mediaUploads').appendChild(row);
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
