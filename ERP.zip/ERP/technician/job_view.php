<?php
/**
 * Technician Job View & Execution
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['TECHNICIAN', 'ADMIN']);

$id = (int)($_GET['id'] ?? 0);
$wo = dbOne("SELECT w.*, c.name AS customer_name, c.phone, c.address 
             FROM work_orders w JOIN customers c ON w.customer_id = c.id 
             JOIN work_order_assignments wa ON w.id = wa.work_order_id
             WHERE w.id=? AND wa.technician_id=?", [$id, $user['id']]);
if (!$wo) die("Job not found or access denied.");

$allocs = dbAll("SELECT a.*, p.name as part_name, p.sku FROM part_allocations a JOIN parts p ON a.part_id = p.id WHERE a.work_order_id=? AND a.technician_id=?", [$id, $user['id']]);
$quotes = dbAll("SELECT * FROM quotation_items qi JOIN quotations q ON qi.quotation_id=q.id WHERE q.work_order_id=? AND q.status='APPROVED'", [$id]);

// Consumption POST logic has been moved to consume_part.php

// Complete Job
if (isset($_POST['complete_job'])) {
    // Check if all parts have been updated
    $allDone = true;
    foreach ($allocs as $a) {
        if ($a['status'] === 'ALLOCATED') $allDone = false;
    }
    
    if (!$allDone) {
        setFlash('error', 'You must mark Consumed or Not Consumed for ALL allocated parts before completing the job.');
    } else {
        $note = trim($_POST['completion_remarks']);
        dbExec("UPDATE work_orders SET status='COMPLETED' WHERE id=?", [$id]);
        dbExec("UPDATE work_order_assignments SET work_status='COMPLETED', completed_at=NOW() WHERE work_order_id=? AND technician_id=?", [$id, $user['id']]);
        addLog($id, $user['id'], 'Job Completed by Technician', $wo['status'], 'COMPLETED', $note);
        notify("Job {$wo['work_order_no']} has been completed by the technician.", null, 'SERVICE_CONTROLLER', $id);
        setFlash('success', 'Job marked as completed!');
    }
    redirect("job_view.php?id=$id");
}

$pageTitle = $wo['work_order_no'] . ' - Job Execution';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="breadcrumb">
  <a href="jobs.php">My Jobs</a> <span>›</span> <?= e($wo['work_order_no']) ?>
</div>

<div class="page-header">
  <div>
    <h1><?= e($wo['work_order_no']) ?></h1>
    <p><?= e($wo['customer_name']) ?> — <span class="<?= badgeClass($wo['status']) ?>"><?= e(woStatusLabel($wo['status'])) ?></span></p>
  </div>
</div>

<div class="detail-grid" style="margin-bottom: 24px;">
  <div class="card">
    <div class="card-header"><div class="card-title">Site Details</div></div>
    <div class="card-body space-y">
      <div class="detail-row"><div class="detail-label">Name</div><div class="detail-value"><?= e($wo['customer_name']) ?></div></div>
      <div class="detail-row"><div class="detail-label">Phone</div><div class="detail-value"><?= e($wo['phone']) ?></div></div>
      <div class="detail-row"><div class="detail-label">Address</div><div class="detail-value"><?= nl2br(e($wo['address'])) ?></div></div>
      <div class="detail-row"><div class="detail-label">Requirement</div><div class="detail-value"><?= nl2br(e($wo['requirement_description'])) ?></div></div>
    </div>
  </div>
  
  <div class="card">
    <div class="card-header"><div class="card-title">Approved Work Scope</div></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Description</th><th>Qty</th></tr></thead>
        <tbody>
          <?php foreach($quotes as $q): ?>
            <tr><td><?= e($q['description']) ?></td><td><?= qty($q['quantity']) ?></td></tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="card" style="margin-bottom: 24px;">
  <div class="card-header"><div class="card-title">My Allocated Parts</div></div>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr><th>Part (SKU)</th><th>Allocated</th><th>Consumed</th><th>Not Consumed</th><th>Status</th><th>Action</th></tr>
      </thead>
      <tbody>
        <?php if(!$allocs): ?><tr><td colspan="6" class="empty-state">No parts allocated to you.</td></tr><?php endif; ?>
        <?php foreach($allocs as $a): ?>
        <tr>
          <td><div style="font-weight:600"><?= e($a['part_name']) ?></div><div class="text-sm text-muted"><?= e($a['sku']) ?></div></td>
          <td class="font-bold text-sky"><?= qty($a['quantity']) ?></td>
          <td><?= qty($a['qty_consumed']) ?></td>
          <td><?= qty($a['qty_returned']) ?></td>
          <td><span class="<?= badgeClass($a['status']) ?>"><?= e(allocStatusLabel($a['status'])) ?></span></td>
          <td>
            <?php if($a['status'] === 'ALLOCATED' && !in_array($wo['status'], ['COMPLETED', 'CLOSED'])): ?>
              <a href="consume_part.php?alloc_id=<?= $a['id'] ?>" class="btn btn-sm btn-primary">Update Status</a>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if(in_array($wo['status'], ['PARTS_ALLOCATED', 'IN_PROGRESS', 'PARTIALLY_COMPLETED'])): ?>
<div class="card" style="max-width: 600px;">
  <div class="card-header"><div class="card-title">Complete Work</div></div>
  <div class="card-body">
    <form method="POST">
      <div class="form-group">
        <label>Completion Remarks / Notes for Service</label>
        <textarea name="completion_remarks" rows="4" required></textarea>
      </div>
      <div style="margin-top: 20px;">
        <button type="submit" name="complete_job" class="btn btn-success" onclick="return confirm('Ensure all parts are marked consumed/not consumed. Submit completion?')">Mark Work Completed</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
