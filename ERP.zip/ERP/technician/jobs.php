<?php
/**
 * Technician Jobs List
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['TECHNICIAN', 'ADMIN']);

$pageTitle = 'My Assigned Jobs';

$sql = "SELECT w.*, c.name as customer_name, c.address 
        FROM work_orders w 
        JOIN work_order_assignments wa ON w.id = wa.work_order_id 
        JOIN customers c ON w.customer_id = c.id 
        WHERE wa.technician_id = ? 
        ORDER BY w.updated_at DESC";
$jobs = dbAll($sql, [$user['id']]);

require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><div><h1>My Assigned Jobs</h1><p>Work orders scheduled for execution.</p></div></div>
<div class="card"><div class="table-wrap"><table class="data-table">
  <thead><tr><th>Work Order</th><th>Customer</th><th>Address</th><th>Status</th><th>Action</th></tr></thead>
  <tbody>
    <?php if(!$jobs): ?><tr><td colspan="5" class="empty-state">No jobs assigned.</td></tr><?php endif; ?>
    <?php foreach($jobs as $j): ?>
    <tr>
      <td class="font-mono"><strong><?= e($j['work_order_no']) ?></strong></td>
      <td style="font-weight:600"><?= e($j['customer_name']) ?></td>
      <td><div style="max-width:300px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><?= e($j['address']) ?></div></td>
      <td><span class="<?= badgeClass($j['status']) ?>"><?= e(woStatusLabel($j['status'])) ?></span></td>
      <td><a href="job_view.php?id=<?= $j['id'] ?>" class="btn btn-sm btn-primary">Open Job</a></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table></div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
