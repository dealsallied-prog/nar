<?php
/**
 * My Allocated Parts (Technician)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['TECHNICIAN', 'ADMIN']);

$pageTitle = 'My Allocated Parts';
$status = $_GET['status'] ?? 'ALLOCATED';

$sql = "SELECT a.*, p.name as part_name, p.sku, w.work_order_no 
        FROM part_allocations a 
        JOIN parts p ON a.part_id = p.id 
        JOIN work_orders w ON a.work_order_id = w.id 
        WHERE a.technician_id = ? AND a.status = ? 
        ORDER BY a.allocated_at DESC";
$parts = dbAll($sql, [$user['id'], $status]);

require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><div><h1>My Allocated Parts</h1><p>Parts in your custody across all jobs.</p></div></div>
<div class="card">
  <div class="card-header">
    <div class="card-title">Parts List</div>
    <form method="GET">
      <select name="status" onchange="this.form.submit()" class="form-control" style="width:200px; padding:6px; border-radius:4px;">
        <option value="ALLOCATED" <?= $status==='ALLOCATED'?'selected':'' ?>>Active (Allocated)</option>
        <option value="CONSUMED" <?= $status==='CONSUMED'?'selected':'' ?>>Consumed</option>
        <option value="RETURN_PENDING" <?= $status==='RETURN_PENDING'?'selected':'' ?>>Pending Return</option>
        <option value="RETURNED" <?= $status==='RETURNED'?'selected':'' ?>>Returned</option>
      </select>
    </form>
  </div>
  <div class="table-wrap"><table class="data-table">
    <thead><tr><th>Work Order</th><th>Part</th><th>Qty Allocated</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
      <?php if(!$parts): ?><tr><td colspan="5" class="empty-state">No parts found.</td></tr><?php endif; ?>
      <?php foreach($parts as $p): ?>
      <tr>
        <td><a href="job_view.php?id=<?= $p['work_order_id'] ?>" class="font-mono"><strong><?= e($p['work_order_no']) ?></strong></a></td>
        <td><div style="font-weight:600"><?= e($p['part_name']) ?></div><div class="text-sm text-muted"><?= e($p['sku']) ?></div></td>
        <td class="font-bold text-sky"><?= qty($p['quantity']) ?></td>
        <td><span class="<?= badgeClass($p['status']) ?>"><?= e(allocStatusLabel($p['status'])) ?></span></td>
        <td><a href="job_view.php?id=<?= $p['work_order_id'] ?>" class="btn btn-sm btn-ghost">View Job</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table></div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
