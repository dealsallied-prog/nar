<?php
/**
 * Consume Allocated Parts
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['TECHNICIAN', 'ADMIN']);

$allocId = (int)($_GET['alloc_id'] ?? 0);
if (!$allocId) redirect('visits.php');

$alloc = dbOne("SELECT a.*, p.name as part_name, p.sku, w.work_order_no 
                FROM part_allocations a
                JOIN parts p ON a.part_id = p.id
                JOIN work_orders w ON a.work_order_id = w.id
                WHERE a.id=?", [$allocId]);

if (!$alloc) die("Allocation not found");

// Get allocated serials
$serials = dbAll("SELECT * FROM part_serials WHERE allocation_id=?", [$allocId]);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['consume_part'])) {
    $pdo = db();
    $pdo->beginTransaction();
    
    try {
        $cQty = 0;
        $nQty = 0;
        
        // If there are serials, calculate based on selected checkboxes
        if (count($serials) > 0) {
            $consumedSerials = $_POST['consumed_serials'] ?? [];
            foreach ($serials as $sn) {
                if (in_array($sn['id'], $consumedSerials)) {
                    $cQty++;
                    dbExec("UPDATE part_serials SET status='CONSUMED' WHERE id=?", [$sn['id']]);
                } else {
                    $nQty++;
                    dbExec("UPDATE part_serials SET status='RETURN_PENDING' WHERE id=?", [$sn['id']]);
                }
            }
        } else {
            // Bulk items
            $cQty = (float)$_POST['qty_consumed'];
            $nQty = (float)$_POST['qty_not_consumed'];
        }
        
        if (round($cQty + $nQty, 2) != round($alloc['quantity'], 2)) {
            throw new Exception("Consumed + Not Consumed must equal Total Allocated Qty.");
        }
        
        $status = ($nQty > 0) ? 'RETURN_PENDING' : 'CONSUMED';
        $pdo->prepare("UPDATE part_allocations SET qty_consumed=?, qty_returned=?, status=?, consumption_note=?, consumed_at=NOW() WHERE id=?")
            ->execute([$cQty, $nQty, $status, trim($_POST['note']), $allocId]);
            
        // Deduct consumed from ledger
        if ($cQty > 0) {
            dbExec("UPDATE parts SET stock_qty = stock_qty - ? WHERE id=?", [$cQty, $alloc['part_id']]);
            $currStock = dbOne("SELECT stock_qty FROM parts WHERE id=?", [$alloc['part_id']])['stock_qty'];
            dbExec("INSERT INTO stock_ledger (part_id, change_type, quantity, balance_after, work_order_id, created_by_id, note) VALUES (?, 'CONSUME', ?, ?, ?, ?, ?)",
                [$alloc['part_id'], $cQty, $currStock, $alloc['work_order_id'], $user['id'], 'Consumed at site']);
        }
        
        $pdo->commit();
        setFlash('success', 'Part consumption updated.');
        redirect("job_view.php?id={$alloc['work_order_id']}");
        
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('error', $e->getMessage());
    }
}

$pageTitle = 'Update Part Consumption';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Update Consumption</h1>
    <p><?= e($alloc['part_name']) ?> (<?= e($alloc['sku']) ?>)</p>
  </div>
  <div class="page-actions"><a href="job_view.php?id=<?= $alloc['work_order_id'] ?>" class="btn btn-ghost">← Back to Job</a></div>
</div>

<div class="card" style="max-width:600px;">
  <div class="card-body">
    <div style="margin-bottom:20px;">
       <strong>Total Allocated:</strong> <?= qty($alloc['quantity']) ?>
    </div>
    
    <form method="POST">
      <?php if(count($serials) > 0): ?>
        <p class="font-semibold" style="margin-bottom:10px;">Select specific serial numbers that were CONSUMED (used):</p>
        <div style="max-height:250px; overflow-y:auto; border:1px solid var(--border); border-radius:4px; padding:10px; background:#f8fafc; margin-bottom:20px;">
           <?php foreach($serials as $sn): ?>
             <div style="margin-bottom:8px;">
               <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                 <input type="checkbox" name="consumed_serials[]" value="<?= $sn['id'] ?>" checked>
                 <span><?= e($sn['serial_number']) ?> <small class="text-muted">(<?= e($sn['make']) ?> - <?= e($sn['description']) ?>)</small></span>
               </label>
             </div>
           <?php endforeach; ?>
        </div>
        <p class="form-hint" style="margin-bottom:20px;">Any unchecked serial numbers will be marked for return.</p>
      <?php else: ?>
        <div class="form-group">
          <label>Qty Consumed (Used)</label>
          <input type="number" name="qty_consumed" id="cQtyUsed" step="0.01" min="0" max="<?= $alloc['quantity'] ?>" value="<?= $alloc['quantity'] ?>" required oninput="calcNotUsed()">
        </div>
        <div class="form-group">
          <label>Qty Not Consumed (To Return)</label>
          <input type="number" name="qty_not_consumed" id="cQtyNotUsed" step="0.01" min="0" value="0" readonly style="background:#f1f5f9">
        </div>
        <script>
        function calcNotUsed() {
            let max = <?= $alloc['quantity'] ?>;
            let used = parseFloat(document.getElementById('cQtyUsed').value) || 0;
            if (used > max) used = max;
            document.getElementById('cQtyUsed').value = used;
            document.getElementById('cQtyNotUsed').value = (max - used).toFixed(2);
        }
        </script>
      <?php endif; ?>
      
      <div class="form-group full">
        <label>Notes (Optional)</label>
        <textarea name="note" rows="2"></textarea>
      </div>
      
      <button type="submit" name="consume_part" class="btn btn-primary" onclick="return confirm('Save consumption details?')">Save Changes</button>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
