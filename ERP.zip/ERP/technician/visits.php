<?php
/**
 * Technician Site Visits List
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['TECHNICIAN', 'ADMIN']);

$pageTitle = 'My Site Visits';

// Fetch visits where this technician is assigned (either primary or in the multiple techs list, or if user is ADMIN)
$sql = "SELECT v.*, w.work_order_no, w.status as wo_status, c.name as customer_name, c.address 
        FROM pre_sale_visits v 
        JOIN work_orders w ON v.work_order_id = w.id 
        JOIN customers c ON w.customer_id = c.id 
        WHERE v.visit_type = 'TECHNICAL' 
          AND (? = 'ADMIN' OR v.assigned_to_id = ? OR FIND_IN_SET(?, v.assigned_techs))
        ORDER BY v.scheduled_date DESC";
$visits = dbAll($sql, [$user['role'], $user['id'], $user['id']]);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>My Site Visits</h1>
    <p>Technical site surveys scheduled for execution.</p>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Date</th>
          <th>Work Order #</th>
          <th>Customer & Address</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$visits): ?>
          <tr><td colspan="5" class="empty-state">No site visits assigned.</td></tr>
        <?php else: foreach ($visits as $v): ?>
          <tr>
            <td><?= dtShort($v['scheduled_date']) ?></td>
            <td class="font-mono"><strong><?= e($v['work_order_no']) ?></strong></td>
            <td>
               <div style="font-weight:600"><?= e($v['customer_name']) ?></div>
               <div class="text-sm text-muted" style="max-width:300px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><?= e($v['address']) ?></div>
            </td>
            <td><span class="badge badge-<?= $v['status']=='COMPLETED'?'green':'blue' ?>"><?= e($v['status']) ?></span></td>
            <td>
              <a href="visit_view.php?id=<?= $v['id'] ?>" class="btn btn-sm btn-outline-sky">Open Visit</a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
