<?php
define('BASE_URL', '/ERP');
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

getCurrentUser(); // just to start session
$user = getCurrentUser();
if ($user) {
    markNotificationsRead($user['id'], $user['role']);
}
header('Content-Type: application/json');
echo json_encode(['ok' => true]);
