<?php
/**
 * Helper utilities — Smart Home ERP v2
 */

if (!defined('BASE_URL')) {
    define('BASE_URL', '/ERP');
}

function dt(?string $datetime): string {
    if (!$datetime) return '—';
    try { return (new DateTime($datetime))->format('d M Y, h:i A'); }
    catch (Exception $e) { return $datetime; }
}

function dtShort(?string $datetime): string {
    if (!$datetime) return '—';
    try { return (new DateTime($datetime))->format('d M Y'); }
    catch (Exception $e) { return $datetime; }
}

function dtDate(?string $datetime): string {
    if (!$datetime) return '—';
    try { return (new DateTime($datetime))->format('d M Y'); }
    catch (Exception $e) { return $datetime; }
}

function qty($num): string { return number_format((float)$num, 2, '.', ','); }
function money($num): string { return '₹ ' . number_format((float)$num, 2, '.', ','); }

function e(?string $str): string {
    return htmlspecialchars((string)($str ?? ''), ENT_QUOTES, 'UTF-8');
}

// ---------------------------------------------------------------------------
// Status constants (full workflow)
// ---------------------------------------------------------------------------
const WO_STATUS_LABEL = [
    // Phase 1 — Sales
    'LEAD_CREATED'              => 'Lead Created',
    'PRE_SALE_VISIT_SCHEDULED'  => 'Pre-Sale Visit Scheduled',
    'PRE_SALE_VISIT_DONE'       => 'Pre-Sale Visit Completed',
    'QUOTATION_DRAFT'           => 'Quotation Draft',
    'QUOTATION_SENT'            => 'Quotation Sent to Customer',
    'QUOTATION_APPROVED'        => 'Quotation Approved',
    'HANDED_TO_SERVICE'         => 'Handed Over to Service',
    // Phase 2 — Service
    'SERVICE_ACCEPTED'          => 'Accepted by Service',
    'TECH_VISIT_SCHEDULED'      => 'Technical Visit Scheduled',
    'TECH_VISIT_DONE'           => 'Technical Visit Completed',
    'REVISION_IN_PROGRESS'      => 'Revision Requested (Back to Sales)',
    'FINAL_QUOTE_APPROVED'      => 'Final Quote Approved — Parts Ordering',
    // Phase 3 — Logistics
    'SENT_TO_LOGISTICS'         => 'Sent to Logistics',
    'PARTS_APPROVED'            => 'Parts Plan Approved by Logistics',
    'PARTS_ORDERING'            => 'Parts Being Ordered',
    'PARTS_RECEIVED'            => 'All Parts Received',
    // Phase 4 — Scheduling
    'ENGINEER_VISIT_SCHEDULED'  => 'Engineer Visit Scheduled',
    'PARTS_ALLOCATED'           => 'Parts Allocated to Technician',
    // Phase 5 — Execution
    'IN_PROGRESS'               => 'Work In Progress',
    'PARTIALLY_COMPLETED'       => 'Partially Completed',
    'COMPLETED'                 => 'Work Completed',
    // Phase 6 — Closure
    'CLOSED'                    => 'Closed',
    // Legacy statuses (backward compat)
    'NEW'                           => 'Lead Created',
    'PENDING_SERVICE_ACCEPTANCE'    => 'Handed Over to Service',
    'ACCEPTED_BY_SERVICE'           => 'Accepted by Service',
    'TECH_VISIT_ASSIGNED'           => 'Technical Visit Scheduled',
    'TECH_VISIT_UPDATED'            => 'Technical Visit Completed',
    'PENDING_LOGISTICS_REVIEW'      => 'Sent to Logistics',
    'AWAITING_PARTS'                => 'Parts Being Ordered',
    'PART_ALLOCATION_REQUESTED'     => 'Parts Allocated to Technician',
    'QUOTATION_APPROVED_LEGACY'     => 'Quotation Approved',
];

const QUOTATION_STATUS_LABEL = [
    'DRAFT'      => 'Draft',
    'SENT'       => 'Sent to Customer',
    'APPROVED'   => 'Approved',
    'REJECTED'   => 'Rejected',
    'SUPERSEDED' => 'Superseded',
];

const PART_ALLOC_STATUS_LABEL = [
    'REQUESTED'      => 'Allocation Requested',
    'ALLOCATED'      => 'Allocated to Technician',
    'CONSUMED'       => 'Consumed',
    'NOT_CONSUMED'   => 'Not Consumed',
    'RETURN_PENDING' => 'Pending Return to Logistics',
    'RETURNED'       => 'Returned to Stock',
];

const ROLE_LABELS = [
    'ADMIN'              => 'Administrator',
    'SALES'              => 'Sales Executive',
    'SERVICE_CONTROLLER' => 'Service Work Controller',
    'TECHNICIAN'         => 'Technician',
    'LOGISTICS'          => 'Logistics / Inventory',
];

const MASTER_STATUS_ORDER = [
    'LEAD_CREATED', 'PRE_SALE_VISIT_SCHEDULED', 'PRE_SALE_VISIT_DONE',
    'QUOTATION_SENT', 'QUOTATION_APPROVED', 'HANDED_TO_SERVICE',
    'SERVICE_ACCEPTED', 'TECH_VISIT_SCHEDULED', 'TECH_VISIT_DONE',
    'FINAL_QUOTE_APPROVED', 'SENT_TO_LOGISTICS', 'PARTS_ORDERING', 'PARTS_RECEIVED',
    'ENGINEER_VISIT_SCHEDULED', 'PARTS_ALLOCATED', 'IN_PROGRESS',
    'COMPLETED', 'CLOSED',
];

function woStatusLabel(string $status): string {
    return WO_STATUS_LABEL[$status] ?? $status;
}
function quotationStatusLabel(string $status): string {
    return QUOTATION_STATUS_LABEL[$status] ?? $status;
}
function allocStatusLabel(string $status): string {
    return PART_ALLOC_STATUS_LABEL[$status] ?? $status;
}
function roleLabel(string $role): string {
    return ROLE_LABELS[$role] ?? $role;
}

// ---------------------------------------------------------------------------
// Badge CSS classes
// ---------------------------------------------------------------------------
function badgeClass(?string $status): string {
    if (!$status) return 'badge badge-muted';
    $good  = ['COMPLETED','APPROVED','RECEIVED','ALLOCATED','RETURNED','CONSUMED','PARTS_RECEIVED','QUOTATION_APPROVED','SERVICE_ACCEPTED','FINAL_QUOTE_APPROVED','PARTS_APPROVED','CLOSED'];
    $warn  = ['REVISION_IN_PROGRESS','PARTS_ORDERING','RETURN_PENDING','PARTIALLY_COMPLETED','PENDING_LOGISTICS_REVIEW','REQUESTED','PRE_SALE_VISIT_DONE','SENT_TO_LOGISTICS','AWAITING_PARTS','HANDED_TO_SERVICE','PENDING_SERVICE_ACCEPTANCE','TECH_VISIT_DONE','TECH_VISIT_UPDATED'];
    $info  = ['LEAD_CREATED','NEW','SENT','QUOTATION_SENT','DRAFT','TECH_VISIT_SCHEDULED','TECH_VISIT_ASSIGNED','ORDERED','PRE_SALE_VISIT_SCHEDULED','PARTS_ALLOCATED','IN_PROGRESS','ENGINEER_VISIT_SCHEDULED','PART_ALLOCATION_REQUESTED'];
    $muted = ['REJECTED','SUPERSEDED','CANCELLED','NOT_CONSUMED'];

    if (in_array($status, $good))  return 'badge badge-green';
    if (in_array($status, $warn))  return 'badge badge-amber';
    if (in_array($status, $info))  return 'badge badge-blue';
    if (in_array($status, $muted)) return 'badge badge-muted';
    return 'badge badge-purple';
}

// ---------------------------------------------------------------------------
// Flash & Session helpers
// ---------------------------------------------------------------------------
function flash(string $key): ?string {
    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}
function setFlash(string $key, string $msg): void {
    $_SESSION['flash'][$key] = $msg;
}
function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}

// ---------------------------------------------------------------------------
// Audit log
// ---------------------------------------------------------------------------
function addLog(int $woId, ?int $actorId, string $action, ?string $fromStatus, ?string $toStatus, string $remarks = ''): void {
    dbExec('INSERT INTO work_order_logs (work_order_id, actor_id, action, from_status, to_status, remarks) VALUES (?,?,?,?,?,?)',
        [$woId, $actorId, $action, $fromStatus, $toStatus, $remarks]);
}

// ---------------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------------
function notify(string $msg, ?int $targetUserId = null, ?string $targetRole = null, ?int $woId = null): void {
    dbExec('INSERT INTO notifications (target_user_id, target_role, work_order_id, message) VALUES (?,?,?,?)',
        [$targetUserId, $targetRole, $woId, $msg]);
}

function getNotifications(int $userId, string $role): array {
    return dbAll(
        "SELECT * FROM notifications WHERE (target_user_id=? OR target_role=?) ORDER BY created_at DESC LIMIT 20",
        [$userId, $role]
    );
}

function markNotificationsRead(int $userId, string $role): void {
    dbExec("UPDATE notifications SET is_read=1 WHERE target_user_id=? OR target_role=?", [$userId, $role]);
}

// ---------------------------------------------------------------------------
// WO Number generator
// ---------------------------------------------------------------------------
function nextWorkOrderNo(): string {
    $year = date('Y');
    $max  = dbOne("SELECT work_order_no FROM work_orders ORDER BY id DESC LIMIT 1");
    if (!$max) return "WO-$year-00001";
    // Try to parse any format
    preg_match('/(\d+)$/', $max['work_order_no'], $m);
    $next = (int)($m[1] ?? 0) + 1;
    return "WO-$year-" . str_pad($next, 5, '0', STR_PAD_LEFT);
}
