
  </main><!-- /.main-content -->

  <footer class="site-footer">
    NAYENDRA : SMART ERP &copy; <?= date('Y') ?> &nbsp;|&nbsp; All rights reserved
  </footer>

</div><!-- /.app-body -->
</div><!-- /.app-shell -->
</body>
</html>
