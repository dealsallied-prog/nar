<?php
/**
 * Shared header — Sidebar layout
 * Requires: $pageTitle, $user (set before including)
 */

$notifications = getNotifications($user['id'], $user['role']);
$unread = count(array_filter($notifications, fn($n) => !$n['is_read']));

// ── Sidebar badge counts ─────────────────────────────────────
$revisionCount = (int)(dbOne("SELECT COUNT(*) AS c FROM work_orders WHERE status='REVISION_IN_PROGRESS'")['c'] ?? 0);
$serviceQueue  = (int)(dbOne("SELECT COUNT(*) AS c FROM work_orders WHERE status='HANDED_TO_SERVICE'")['c'] ?? 0);
$pendingRevQ   = (int)(dbOne("SELECT COUNT(*) AS c FROM work_orders WHERE status='FINAL_QUOTE_APPROVED'")['c'] ?? 0);
$allocReqCount = (int)(dbOne("SELECT COUNT(*) AS c FROM part_allocations WHERE status='REQUESTED'")['c'] ?? 0);
$returnPending = (int)(dbOne("SELECT COUNT(*) AS c FROM part_allocations WHERE status='RETURN_PENDING'")['c'] ?? 0);

// ── Sidebar structure ───────────────────────────────────────
$sidebar = [
  [
    'type'  => 'link',
    'icon'  => '🏠',
    'label' => 'Dashboard',
    'href'  => BASE_URL . '/dashboard.php',
    'roles' => ['ADMIN','SALES','SERVICE_CONTROLLER','TECHNICIAN','LOGISTICS'],
  ],

  [
    'type'  => 'section',
    'icon'  => '💼',
    'label' => 'Sales',
    'id'    => 'sales',
    'roles' => ['ADMIN','SALES'],
    'items' => [
      ['label' => 'Leads & Work Orders', 'href' => BASE_URL . '/sales/leads.php'],
      ['label' => 'Pre-Sale Visits',     'href' => BASE_URL . '/sales/visits.php'],
      ['label' => 'Quotations',          'href' => BASE_URL . '/sales/quotations.php'],
      ['label' => 'Revision Requests',   'href' => BASE_URL . '/sales/revisions.php', 'badge' => $revisionCount],
    ],
  ],
  [
    'type'  => 'section',
    'icon'  => '🔧',
    'label' => 'Service',
    'id'    => 'service',
    'roles' => ['ADMIN','SERVICE_CONTROLLER'],
    'items' => [
      ['label' => 'New / Unassigned WOs',   'href' => BASE_URL . '/service/queue.php',            'badge' => $serviceQueue],
      ['label' => 'My Active Work Orders',  'href' => BASE_URL . '/service/workorders.php'],
      ['label' => 'Technical Site Visits',  'href' => BASE_URL . '/service/tech_visits.php'],
      ['label' => 'Pending Revised Quotes', 'href' => BASE_URL . '/service/pending_revision.php', 'badge' => $pendingRevQ],
    ],
  ],
  [
    'type'  => 'section',
    'icon'  => '🚚',
    'label' => 'Logistics',
    'id'    => 'logistics',
    'roles' => ['ADMIN','LOGISTICS'],
    'items' => [
      ['label' => 'Part Requirements',  'href' => BASE_URL . '/logistics/requirements.php'],
      ['label' => 'Purchase Orders',    'href' => BASE_URL . '/logistics/orders.php'],
      ['label' => 'Goods Receipt',      'href' => BASE_URL . '/logistics/receipt.php'],
      ['label' => 'Stock Reservations', 'href' => BASE_URL . '/logistics/reservations.php'],
      ['label' => 'Part Allocations',   'href' => BASE_URL . '/logistics/allocations.php', 'badge' => $allocReqCount],
      ['label' => 'Returns',            'href' => BASE_URL . '/logistics/returns.php',     'badge' => $returnPending],
    ],
  ],
  [
    'type'  => 'section',
    'icon'  => '📦',
    'label' => 'Inventory',
    'id'    => 'inventory',
    'roles' => ['ADMIN','LOGISTICS','SERVICE_CONTROLLER'],
    'items' => [
      ['label' => 'Parts Master',      'href' => BASE_URL . '/inventory/index.php'],
      ['label' => 'Stock Ledger',      'href' => BASE_URL . '/inventory/ledger.php'],
      ['label' => 'Low Stock Alerts',  'href' => BASE_URL . '/inventory/low_stock.php'],
    ],
  ],
  [
    'type'  => 'section',
    'icon'  => '👷',
    'label' => 'Onsite',
    'id'    => 'onsite',
    'roles' => ['ADMIN','TECHNICIAN'],
    'items' => [
      ['label' => 'My Site Visits',     'href' => BASE_URL . '/technician/visits.php'],
      ['label' => 'My Assigned Jobs',   'href' => BASE_URL . '/technician/jobs.php'],
      ['label' => 'My Allocated Parts', 'href' => BASE_URL . '/technician/parts.php'],
    ],
  ],
  [
    'type'  => 'link',
    'icon'  => '📊',
    'label' => 'Reports',
    'href'  => BASE_URL . '/reports/index.php',
    'roles' => ['ADMIN'],
  ],
  [
    'type'  => 'section',
    'icon'  => '⚙️',
    'label' => 'Administration',
    'id'    => 'admin',
    'roles' => ['ADMIN'],
    'items' => [
      ['label' => 'System Settings', 'href' => BASE_URL . '/admin/system.php'],
      ['label' => 'User Management', 'href' => BASE_URL . '/admin/users.php'],
    ],
  ],
];

// Active detection
function isActive(string $href): bool {
    $cur  = strtok($_SERVER['REQUEST_URI'] ?? '', '?');
    $link = parse_url($href, PHP_URL_PATH);
    return $cur === $link;
}
function isSectionActive(array $items): bool {
    foreach ($items as $it) { if (isActive($it['href'])) return true; }
    return false;
}

// Avatar initials
$initials = implode('', array_map(fn($w) => strtoupper($w[0]), array_slice(explode(' ', $user['name']), 0, 2)));

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= e($pageTitle ?? 'Dashboard') ?> — NAYENDRA : SMART ERP</title>
  <meta name="description" content="NAYENDRA : SMART ERP — Sales, Service, Technician, Inventory & Logistics." />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/app.css" />
</head>
<body>
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>
<div class="app-shell">

<!-- ═══════════════════════════════════════════════════════
     SIDEBAR
═══════════════════════════════════════════════════════ -->
<aside class="sidebar" id="sidebar">
  <!-- Header / Brand -->
  <div class="sidebar-header">
    <div class="sidebar-logo">
      <img src="<?= BASE_URL ?>/assets/img/logo.png" alt="Logo" style="height: 24px; width: auto; display: block; object-fit: contain;">
    </div>
    <div>
      <div class="sidebar-brand-name" style="font-size: 13px;">NAYENDRA : SMART ERP</div>
      <div class="sidebar-brand-sub">Management System</div>
    </div>
  </div>

  <!-- Navigation -->
  <nav class="sidebar-nav">
    <?php foreach ($sidebar as $item):
      if (!in_array($user['role'], $item['roles'])) continue;

      if ($item['type'] === 'link'): ?>
        <a href="<?= e($item['href']) ?>"
           class="sidebar-top-link <?= isActive($item['href']) ? 'active' : '' ?>">
          <span class="nav-icon"><?= $item['icon'] ?></span>
          <?= e($item['label']) ?>
        </a>
        <div class="sidebar-divider"></div>

      <?php elseif ($item['type'] === 'section'):
        $sectionOpen = isSectionActive($item['items']);
      ?>
        <div class="sidebar-section <?= $sectionOpen ? 'open' : '' ?>" id="sec-<?= $item['id'] ?>">
          <div class="sidebar-section-toggle" onclick="toggleSection('<?= $item['id'] ?>')">
            <span class="sidebar-section-label">
              <span class="nav-icon"><?= $item['icon'] ?></span>
              <?= e($item['label']) ?>
            </span>
            <span class="sidebar-chevron">▶</span>
          </div>
          <div class="sidebar-section-body">
            <?php foreach ($item['items'] as $sub): ?>
              <a href="<?= e($sub['href']) ?>"
                 class="sidebar-link <?= isActive($sub['href']) ? 'active' : '' ?>">
                <?= e($sub['label']) ?>
                <?php if (!empty($sub['badge']) && $sub['badge'] > 0): ?>
                  <span class="sidebar-badge"><?= $sub['badge'] ?></span>
                <?php endif; ?>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endif; ?>
    <?php endforeach; ?>
  </nav>

  <!-- User Card + Logout -->
  <div class="sidebar-footer">
    <div class="sidebar-user-card">
      <div class="sidebar-avatar"><?= e($initials) ?></div>
      <div>
        <div class="sidebar-user-name"><?= e($user['name']) ?></div>
        <div class="sidebar-user-role"><?= roleLabel($user['role']) ?></div>
      </div>
    </div>
    <a href="<?= BASE_URL ?>/logout.php" class="sidebar-logout">🚪 Sign Out</a>
  </div>
</aside>

<!-- ═══════════════════════════════════════════════════════
     APP BODY
═══════════════════════════════════════════════════════ -->
<div class="app-body">

  <!-- Topbar -->
  <header class="topbar">
    <div class="topbar-left">
      <button class="sidebar-toggle" onclick="openSidebar()" aria-label="Menu">☰</button>
      <div>
        <div class="topbar-title"><?= e($pageTitle ?? 'Dashboard') ?></div>
      </div>
    </div>
    <div class="topbar-right">
      <!-- Notifications -->
      <div class="notif-wrapper" id="notifWrapper">
        <button class="notif-btn" id="notifBtn" onclick="toggleNotif()" aria-label="Notifications">
          🔔
          <?php if ($unread > 0): ?>
            <span class="notif-badge"><?= $unread ?></span>
          <?php endif; ?>
        </button>
        <div class="notif-dropdown" id="notifDropdown" style="display:none">
          <p class="notif-header">Notifications <?php if ($unread): ?><span style="color:#0ea5e9">(<?= $unread ?> new)</span><?php endif; ?></p>
          <?php if (empty($notifications)): ?>
            <p class="notif-empty">No notifications yet.</p>
          <?php else: ?>
            <?php foreach (array_slice($notifications, 0, 12) as $n): ?>
              <div class="notif-item <?= $n['is_read'] ? '' : 'notif-unread' ?>">
                <p class="notif-msg"><?= e($n['message']) ?></p>
                <p class="notif-time"><?= dt($n['created_at']) ?></p>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
      <!-- User chip -->
      <div class="user-chip">
        <div class="user-chip-avatar"><?= e($initials) ?></div>
        <div>
          <div class="user-chip-name"><?= e(explode(' ', $user['name'])[0]) ?></div>
          <div class="user-chip-role"><?= roleLabel($user['role']) ?></div>
        </div>
      </div>
    </div>
  </header>

  <!-- Main content -->
  <main class="main-content">

<?php
$successMsg = flash('success');
$errorMsg   = flash('error');
$infoMsg    = flash('info');
if ($successMsg): ?><div class="alert alert-success">✓ <?= e($successMsg) ?></div><?php endif;
if ($errorMsg):   ?><div class="alert alert-error">⚠ <?= e($errorMsg) ?></div><?php endif;
if ($infoMsg):    ?><div class="alert alert-info">ℹ <?= e($infoMsg) ?></div><?php endif;
?>

<script>
// ── Sidebar toggle ──────────────────────────────────
function openSidebar() {
  document.getElementById('sidebar').classList.add('mobile-open');
  document.getElementById('sidebarOverlay').classList.add('visible');
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('mobile-open');
  document.getElementById('sidebarOverlay').classList.remove('visible');
}

// ── Section collapse ────────────────────────────────
function toggleSection(id) {
  const sec = document.getElementById('sec-' + id);
  if (sec) sec.classList.toggle('open');
}

// ── Notifications ────────────────────────────────────
function toggleNotif() {
  const d = document.getElementById('notifDropdown');
  d.style.display = d.style.display === 'none' ? 'block' : 'none';
  if (d.style.display === 'block') {
    fetch('<?= BASE_URL ?>/api/mark_notifications_read.php');
    document.querySelectorAll('.notif-badge').forEach(el => el.remove());
  }
}
document.addEventListener('click', e => {
  const w = document.getElementById('notifWrapper');
  if (w && !w.contains(e.target)) {
    const d = document.getElementById('notifDropdown');
    if (d) d.style.display = 'none';
  }
});

// ── Tab helper ───────────────────────────────────────
function switchTab(tabId, groupId) {
  const group = groupId || 'default';
  document.querySelectorAll(`[data-tab-group="${group}"]`).forEach(el => el.classList.remove('active'));
  document.querySelectorAll(`[data-tab-panel-group="${group}"]`).forEach(el => el.classList.remove('active'));
  document.querySelector(`[data-tab-group="${group}"][data-tab="${tabId}"]`)?.classList.add('active');
  document.querySelector(`[data-tab-panel-group="${group}"][data-panel="${tabId}"]`)?.classList.add('active');
}

// ── Modal helper ──────────────────────────────────────
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});
</script>
