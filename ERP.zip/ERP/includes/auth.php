<?php
/**
 * Auth helpers — Smart Home ERP
 * Uses PHP $_SESSION for session management.
 */

require_once __DIR__ . '/db.php';

function sessionStart(): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_start([
            'cookie_httponly' => true,
            'cookie_samesite' => 'Lax',
            'gc_maxlifetime'  => 86400 * 30,
        ]);
    }
}

function getCurrentUser(): ?array {
    sessionStart();
    if (empty($_SESSION['user_id'])) return null;
    $user = dbOne('SELECT id, name, email, role FROM users WHERE id = ? AND active = 1', [$_SESSION['user_id']]);
    return $user ?: null;
}

function requireUser(array $roles = []): array {
    $user = getCurrentUser();
    if (!$user) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
    if (!empty($roles) && $user['role'] !== 'ADMIN' && !in_array($user['role'], $roles, true)) {
        header('Location: ' . BASE_URL . '/dashboard.php');
        exit;
    }
    return $user;
}

function login(string $usernameOrEmail, string $password): bool {
    sessionStart();
    $user = dbOne('SELECT id, password_hash, active FROM users WHERE email = ? OR name = ?', [trim($usernameOrEmail), trim($usernameOrEmail)]);
    if (!$user || !$user['active']) return false;
    if (!password_verify($password, $user['password_hash'])) return false;
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    return true;
}

function logout(): void {
    sessionStart();
    session_destroy();
}


