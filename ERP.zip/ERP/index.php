<?php
/** Root redirect */
header('Location: /ERP/login.php');
exit;
