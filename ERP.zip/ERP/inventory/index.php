<?php
/**
 * Parts Master (Inventory)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['ADMIN', 'LOGISTICS', 'SERVICE_CONTROLLER']);

$pageTitle = 'Parts Master';

$parts = dbAll("SELECT * FROM parts ORDER BY name ASC");

require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><div><h1>Parts Master</h1><p>Full catalog of all inventory items.</p></div></div>
<div class="card"><div class="table-wrap"><table class="data-table">
  <thead><tr><th>SKU</th><th>Part Name</th><th>Unit Price</th><th>In Stock</th><th>Reserved</th><th>Available</th></tr></thead>
  <tbody>
    <?php if(!$parts): ?><tr><td colspan="6" class="empty-state">No parts found.</td></tr><?php endif; ?>
    <?php foreach($parts as $p): 
      $avail = max(0, $p['stock_qty'] - $p['reserved_qty']);
    ?>
    <tr class="<?= ($avail <= $p['reorder_level']) ? 'row-low-stock' : '' ?>">
      <td class="font-mono text-muted"><?= e($p['sku']) ?></td>
      <td><div style="font-weight:600"><?= e($p['name']) ?></div><div class="text-sm text-muted"><?= e($p['description']) ?></div></td>
      <td><?= money($p['unit_price']) ?></td>
      <td class="font-bold text-sky"><?= qty($p['stock_qty']) ?></td>
      <td class="text-amber"><?= qty($p['reserved_qty']) ?></td>
      <td class="font-bold <?= $avail <= $p['reorder_level'] ? 'text-rose' : 'text-green' ?>"><?= qty($avail) ?></td>
    </tr>
    <?php endendforeach; ?>
  </tbody>
</table></div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
