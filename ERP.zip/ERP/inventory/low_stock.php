<?php
/**
 * Low Stock Alerts
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['ADMIN', 'LOGISTICS']);

$pageTitle = 'Low Stock Alerts';

// Stock <= reorder_level
$sql = "SELECT p.*, (p.stock_qty - p.reserved_qty) as available 
        FROM parts p 
        WHERE (p.stock_qty - p.reserved_qty) <= p.reorder_level 
        ORDER BY available ASC";
$parts = dbAll($sql);

require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><div><h1>Low Stock Alerts</h1><p>Parts that need replenishing.</p></div></div>
<?php if(empty($parts)): ?>
<div class="alert alert-success">All parts are above their reorder levels.</div>
<?php else: ?>
<div class="card"><div class="table-wrap"><table class="data-table">
  <thead><tr><th>SKU</th><th>Part Name</th><th>Available</th><th>Reorder Level</th><th>Deficit</th></tr></thead>
  <tbody>
    <?php foreach($parts as $p): 
      $deficit = $p['reorder_level'] - $p['available'];
    ?>
    <tr class="row-low-stock">
      <td class="font-mono text-muted"><?= e($p['sku']) ?></td>
      <td><div style="font-weight:600"><?= e($p['name']) ?></div></td>
      <td class="font-bold text-rose"><?= qty($p['available']) ?></td>
      <td class="text-muted"><?= qty($p['reorder_level']) ?></td>
      <td class="font-bold text-amber"><?= qty($deficit > 0 ? $deficit : 0) ?></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table></div></div>
<?php endif; ?>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
