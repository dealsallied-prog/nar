<?php
/**
 * Stock Ledger (Inventory)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['ADMIN', 'LOGISTICS', 'SERVICE_CONTROLLER']);

$pageTitle = 'Stock Ledger';
$partId = (int)($_GET['part_id'] ?? 0);

$params = [];
$sql = "SELECT l.*, p.name as part_name, p.sku, u.name as user_name, w.work_order_no 
        FROM stock_ledger l 
        JOIN parts p ON l.part_id = p.id 
        LEFT JOIN users u ON l.created_by_id = u.id 
        LEFT JOIN work_orders w ON l.work_order_id = w.id ";

if ($partId) {
    $sql .= " WHERE l.part_id = ? ";
    $params[] = $partId;
}
$sql .= " ORDER BY l.id DESC LIMIT 100";
$logs = dbAll($sql, $params);
$parts = dbAll("SELECT id, name, sku FROM parts ORDER BY name ASC");

require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><div><h1>Stock Ledger</h1><p>Full audit trail of all stock movements.</p></div></div>
<div class="card">
  <div class="card-header">
    <div class="card-title">Ledger Entries</div>
    <form method="GET">
      <select name="part_id" onchange="this.form.submit()" class="form-control" style="width:250px; padding:6px; border-radius:4px;">
        <option value="">All Parts</option>
        <?php foreach($parts as $p): ?>
          <option value="<?= $p['id'] ?>" <?= $p['id']==$partId?'selected':'' ?>><?= e($p['name']) ?> (<?= e($p['sku']) ?>)</option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>
  <div class="table-wrap"><table class="data-table">
    <thead><tr><th>Date & Time</th><th>Part</th><th>Type</th><th>Qty</th><th>Bal. After</th><th>Reference</th><th>User</th></tr></thead>
    <tbody>
      <?php if(!$logs): ?><tr><td colspan="7" class="empty-state">No ledger entries.</td></tr><?php endif; ?>
      <?php foreach($logs as $l): ?>
      <tr>
        <td><?= dt($l['created_at']) ?></td>
        <td><div style="font-weight:600"><?= e($l['part_name']) ?></div><div class="text-sm text-muted"><?= e($l['sku']) ?></div></td>
        <td><span class="badge bg-slate2"><?= e($l['change_type']) ?></span></td>
        <td class="font-bold text-sky"><?= qty($l['quantity']) ?></td>
        <td class="font-bold text-navy2"><?= qty($l['balance_after']) ?></td>
        <td>
          <?php if($l['work_order_no']): ?><a href="../service/workorder_view.php?id=<?= $l['work_order_id'] ?>" class="font-mono"><?= e($l['work_order_no']) ?></a><br><?php endif; ?>
          <span class="text-sm text-muted"><?= e($l['note']) ?></span>
        </td>
        <td><?= e($l['user_name']) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table></div>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
