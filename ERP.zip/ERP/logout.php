<?php
define('BASE_URL', '/ERP');
require_once __DIR__ . '/includes/auth.php';
logout();
header('Location: ' . BASE_URL . '/login.php');
exit;
