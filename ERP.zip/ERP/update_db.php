<?php
/**
 * update_db.php — Non-destructive schema migration
 * Adds new columns & tables to support the full workflow.
 * Run once via http://localhost/ERP/update_db.php
 */
define('DB_HOST','127.0.0.1'); define('DB_PORT','3306');
define('DB_USER','root');      define('DB_PASS','');
set_time_limit(120);

$log = [];
function ok(string $msg): void { global $log; $log[] = ['ok', $msg]; }
function err(string $msg): void { global $log; $log[] = ['err', $msg]; }

function runAlter(PDO $pdo, string $sql, string $label): void {
    try { $pdo->exec($sql); ok($label); }
    catch (PDOException $e) {
        if (str_contains($e->getMessage(), 'Duplicate column')) ok("$label (already exists)");
        elseif (str_contains($e->getMessage(), 'already exists')) ok("$label (already exists)");
        else err("$label: " . $e->getMessage());
    }
}

try {
    $pdo = new PDO("mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=smart_home_erp;charset=utf8mb4",
        DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    ok("Connected to smart_home_erp");

    // ── work_orders ──────────────────────────────────────────────
    runAlter($pdo, "ALTER TABLE work_orders MODIFY status VARCHAR(60) NOT NULL DEFAULT 'LEAD_CREATED'", "Expand work_orders.status to VARCHAR(60)");
    runAlter($pdo, "ALTER TABLE work_orders ADD COLUMN expected_budget DECIMAL(12,2) DEFAULT NULL AFTER requirement_description", "work_orders.expected_budget");
    runAlter($pdo, "ALTER TABLE work_orders ADD COLUMN dept_status VARCHAR(60) DEFAULT NULL AFTER status", "work_orders.dept_status");
    runAlter($pdo, "ALTER TABLE work_orders ADD COLUMN attachments TEXT DEFAULT NULL AFTER dept_status", "work_orders.attachments");
    runAlter($pdo, "ALTER TABLE work_orders ADD COLUMN handover_note TEXT DEFAULT NULL AFTER attachments", "work_orders.handover_note");
    runAlter($pdo, "ALTER TABLE work_orders ADD COLUMN revision_change_list TEXT DEFAULT NULL AFTER handover_note", "work_orders.revision_change_list");

    // Update existing 'NEW' status to 'LEAD_CREATED'
    $n = $pdo->exec("UPDATE work_orders SET status='LEAD_CREATED' WHERE status='NEW'");
    ok("Migrated $n work orders from NEW → LEAD_CREATED");

    // ── quotations ────────────────────────────────────────────────
    runAlter($pdo, "ALTER TABLE quotations ADD COLUMN revision_reason TEXT DEFAULT NULL AFTER notes", "quotations.revision_reason");
    runAlter($pdo, "ALTER TABLE quotations ADD COLUMN tax_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00 AFTER revision_reason", "quotations.tax_percent");
    runAlter($pdo, "ALTER TABLE quotations ADD COLUMN discount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER tax_percent", "quotations.discount");
    runAlter($pdo, "ALTER TABLE quotations ADD COLUMN validity_days INT NOT NULL DEFAULT 30 AFTER discount", "quotations.validity_days");
    runAlter($pdo, "ALTER TABLE quotations ADD COLUMN terms TEXT DEFAULT NULL AFTER validity_days", "quotations.terms");
    runAlter($pdo, "ALTER TABLE quotations ADD COLUMN approval_proof TEXT DEFAULT NULL AFTER approved_at", "quotations.approval_proof");
    runAlter($pdo, "ALTER TABLE quotations ADD COLUMN tax_amount DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER tax_percent", "quotations.tax_amount");

    // ── quotation_items ───────────────────────────────────────────
    runAlter($pdo, "ALTER TABLE quotation_items ADD COLUMN item_type VARCHAR(20) NOT NULL DEFAULT 'PARTS' AFTER id", "quotation_items.item_type (PARTS/LABOUR/OTHER)");

    // ── pre_sale_visits → now supports both pre-sale and technical visits ──
    runAlter($pdo, "ALTER TABLE pre_sale_visits MODIFY status VARCHAR(30) NOT NULL DEFAULT 'SCHEDULED'", "Expand pre_sale_visits.status");
    runAlter($pdo, "ALTER TABLE pre_sale_visits ADD COLUMN visit_type VARCHAR(20) NOT NULL DEFAULT 'PRE_SALE' AFTER id", "pre_sale_visits.visit_type (PRE_SALE/TECHNICAL)");
    runAlter($pdo, "ALTER TABLE pre_sale_visits ADD COLUMN measurements TEXT DEFAULT NULL AFTER notes", "pre_sale_visits.measurements");
    runAlter($pdo, "ALTER TABLE pre_sale_visits ADD COLUMN photos TEXT DEFAULT NULL AFTER measurements", "pre_sale_visits.photos");

    // ── part_allocations ─────────────────────────────────────────
    runAlter($pdo, "ALTER TABLE part_allocations ADD COLUMN qty_consumed DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER quantity", "part_allocations.qty_consumed");
    runAlter($pdo, "ALTER TABLE part_allocations ADD COLUMN qty_returned DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER qty_consumed", "part_allocations.qty_returned");
    runAlter($pdo, "ALTER TABLE part_allocations ADD COLUMN consumption_note TEXT DEFAULT NULL AFTER qty_returned", "part_allocations.consumption_note");
    runAlter($pdo, "ALTER TABLE part_allocations ADD COLUMN completion_submitted_at DATETIME DEFAULT NULL AFTER returned_at", "part_allocations.completion_submitted_at");

    // ── part_orders ───────────────────────────────────────────────
    runAlter($pdo, "ALTER TABLE part_orders ADD COLUMN po_number VARCHAR(40) DEFAULT NULL AFTER id", "part_orders.po_number");
    runAlter($pdo, "ALTER TABLE part_orders ADD COLUMN supplier TEXT DEFAULT NULL AFTER po_number", "part_orders.supplier");
    runAlter($pdo, "ALTER TABLE part_orders ADD COLUMN expected_delivery_date DATE DEFAULT NULL AFTER supplier", "part_orders.expected_delivery_date");
    runAlter($pdo, "ALTER TABLE part_orders ADD COLUMN cost_per_unit DECIMAL(12,2) DEFAULT NULL AFTER expected_delivery_date", "part_orders.cost_per_unit");
    runAlter($pdo, "ALTER TABLE part_orders ADD COLUMN qty_received DECIMAL(12,2) NOT NULL DEFAULT 0.00 AFTER quantity", "part_orders.qty_received");

    // ── NEW: tech_visit_part_changes ─────────────────────────────
    runAlter($pdo, "CREATE TABLE IF NOT EXISTS tech_visit_part_changes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        work_order_id INT NOT NULL,
        visit_update_id INT,
        change_type VARCHAR(10) NOT NULL COMMENT 'ADD or REMOVE',
        part_id INT,
        description TEXT NOT NULL,
        quantity DECIMAL(12,2) NOT NULL DEFAULT 1.00,
        reason TEXT,
        created_by_id INT,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
        FOREIGN KEY (part_id) REFERENCES parts(id),
        FOREIGN KEY (created_by_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "CREATE tech_visit_part_changes");

    // ── NEW: work_order_schedule (engineer visit scheduling) ─────
    runAlter($pdo, "CREATE TABLE IF NOT EXISTS work_order_schedule (
        id INT AUTO_INCREMENT PRIMARY KEY,
        work_order_id INT NOT NULL,
        scheduled_date DATETIME,
        notes TEXT,
        scheduled_by_id INT,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (work_order_id) REFERENCES work_orders(id),
        FOREIGN KEY (scheduled_by_id) REFERENCES users(id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", "CREATE work_order_schedule");

    // ── Auto-generate PO numbers for existing orders without one ─
    $orders = $pdo->query("SELECT id FROM part_orders WHERE po_number IS NULL ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    $stmt   = $pdo->prepare("UPDATE part_orders SET po_number=? WHERE id=?");
    foreach ($orders as $i => $o) {
        $stmt->execute(['PO-' . str_pad($o['id'], 5, '0', STR_PAD_LEFT), $o['id']]);
    }
    ok("Generated PO numbers for " . count($orders) . " existing orders");

    ok("✅ All schema updates applied successfully!");
} catch (PDOException $e) {
    err("Fatal: " . $e->getMessage());
}
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>ERP Schema Update</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
body{font-family:Inter,sans-serif;background:#0f172a;color:#e2e8f0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}
.box{background:#1e293b;border-radius:16px;padding:32px;max-width:640px;width:100%;box-shadow:0 8px 32px rgba(0,0,0,.4);}
h1{font-size:22px;font-weight:700;margin-bottom:20px;color:#fff;}
.log-item{padding:8px 12px;border-radius:8px;margin:5px 0;font-size:13px;display:flex;gap:10px;align-items:flex-start;}
.ok{background:#052e16;border:1px solid #166534;}.ok::before{content:'✓';color:#4ade80;font-weight:700;}
.err{background:#450a0a;border:1px solid #7f1d1d;}.err::before{content:'✕';color:#f87171;font-weight:700;}
.go-btn{display:block;text-align:center;margin-top:24px;background:#0ea5e9;color:#fff;padding:12px 24px;border-radius:10px;font-weight:700;text-decoration:none;font-size:14px;}
.go-btn:hover{background:#0284c7;}
</style></head><body>
<div class="box">
  <h1>🔧 ERP Schema Update</h1>
  <?php foreach ($log as [$t,$m]): ?>
    <div class="log-item <?= $t ?>"><span><?= htmlspecialchars($m) ?></span></div>
  <?php endforeach; ?>
  <a class="go-btn" href="/ERP/dashboard.php">→ Go to Dashboard</a>
</div></body></html>
