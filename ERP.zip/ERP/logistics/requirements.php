<?php
/**
 * Part Requirements (Logistics)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['LOGISTICS', 'ADMIN']);

if (isset($_POST['approve_parts'])) {
    $woId = (int)$_POST['wo_id'];
    
    // Check all requirements
    $reqs = dbAll("SELECT pr.*, p.stock_qty, p.name FROM work_order_part_requirements pr JOIN parts p ON pr.part_id=p.id WHERE pr.work_order_id=? AND pr.status='PENDING'", [$woId]);
    $allInStock = true;
    
    foreach ($reqs as $r) {
        $needed = $r['quantity_required'];
        $inStock = $r['stock_qty'];
        
        if ($inStock >= $needed) {
            // Fully reserve
            dbExec("UPDATE work_order_part_requirements SET status='RESERVED', quantity_reserved=? WHERE id=?", [$needed, $r['id']]);
            // Update stock register
            dbExec("UPDATE parts SET stock_qty = stock_qty - ?, reserved_qty = reserved_qty + ? WHERE id=?", [$needed, $needed, $r['part_id']]);
            dbExec("INSERT INTO stock_ledger (part_id, change_type, quantity, balance_after, work_order_id, created_by_id, note) VALUES (?, 'RESERVE', ?, ?, ?, ?, ?)",
                [$r['part_id'], $needed, $inStock - $needed, $woId, $user['id'], 'Reserved for WO']);
        } else {
            // Partially reserve
            $reserve = $inStock > 0 ? $inStock : 0;
            $shortfall = $needed - $reserve;
            $allInStock = false;
            
            if ($reserve > 0) {
                dbExec("UPDATE parts SET stock_qty = stock_qty - ?, reserved_qty = reserved_qty + ? WHERE id=?", [$reserve, $reserve, $r['part_id']]);
                dbExec("INSERT INTO stock_ledger (part_id, change_type, quantity, balance_after, work_order_id, created_by_id, note) VALUES (?, 'RESERVE', ?, ?, ?, ?, ?)",
                    [$r['part_id'], $reserve, $inStock - $reserve, $woId, $user['id'], 'Reserved for WO']);
            }
            
            // Generate PO requirement
            dbExec("UPDATE work_order_part_requirements SET status='ORDERED', quantity_reserved=?, quantity_ordered=? WHERE id=?", [$reserve, $shortfall, $r['id']]);
            $poNo = "PO-" . str_pad(random_int(1000, 9999), 4, '0', STR_PAD_LEFT); // simple for now
            dbExec("INSERT INTO part_orders (work_order_id, part_id, requirement_id, quantity, status, po_number, created_by_id) VALUES (?,?,?,?,'ORDERED',?,?)",
                [$woId, $r['part_id'], $r['id'], $shortfall, $poNo, $user['id']]);
        }
    }
    
    // Update Master Status
    if ($allInStock) {
        dbExec("UPDATE work_orders SET status='PARTS_RECEIVED' WHERE id=?", [$woId]);
        addLog($woId, $user['id'], 'Parts Approved & Reserved', 'SENT_TO_LOGISTICS', 'PARTS_RECEIVED', 'All parts available in stock.');
        notify("All parts reserved for WO-$woId. Ready for scheduling.", null, 'SERVICE_CONTROLLER', $woId);
    } else {
        dbExec("UPDATE work_orders SET status='PARTS_ORDERING' WHERE id=?", [$woId]);
        addLog($woId, $user['id'], 'Parts Ordered', 'SENT_TO_LOGISTICS', 'PARTS_ORDERING', 'Some parts out of stock. PO created.');
    }
    
    setFlash('success', 'Parts requirements processed. Stock reserved and/or ordered.');
    redirect('requirements.php');
}

$pageTitle = 'Part Requirements';
$sql = "SELECT DISTINCT w.id, w.work_order_no, w.status 
        FROM work_orders w JOIN work_order_part_requirements pr ON w.id = pr.work_order_id 
        WHERE pr.status = 'PENDING' OR w.status = 'SENT_TO_LOGISTICS'
        ORDER BY w.updated_at ASC";
$wos = dbAll($sql);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Part Requirements</h1>
    <p>Review requirements sent by Service. System will auto-check stock and reserve or order.</p>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Work Order</th><th>Required Parts Count</th><th>Action</th></tr></thead>
      <tbody>
        <?php if(!$wos): ?><tr><td colspan="3" class="empty-state">No pending requirements.</td></tr><?php endif; ?>
        <?php foreach($wos as $w): 
          $reqCount = dbOne("SELECT COUNT(*) as c FROM work_order_part_requirements WHERE work_order_id=?", [$w['id']])['c'];
        ?>
        <tr>
          <td><a href="../service/workorder_view.php?id=<?= $w['id'] ?>" class="font-mono"><strong><?= e($w['work_order_no']) ?></strong></a></td>
          <td><?= $reqCount ?> Items</td>
          <td>
            <form method="POST" style="display:inline-block">
              <input type="hidden" name="wo_id" value="<?= $w['id'] ?>">
              <button type="submit" name="approve_parts" class="btn btn-sm btn-primary">Process & Check Stock</button>
            </form>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
