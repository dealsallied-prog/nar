<?php
/**
 * Part Allocations (Logistics -> Technician)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['LOGISTICS', 'ADMIN']);

$pageTitle = 'Part Allocations';

// The allocation POST logic has been moved to allocation_process.php

$sql = "SELECT w.id, w.work_order_no, w.status, u.name as tech_name, COUNT(pr.id) as item_count 
        FROM work_orders w 
        JOIN work_order_part_requirements pr ON w.id = pr.work_order_id 
        JOIN work_order_assignments wa ON w.id = wa.work_order_id
        JOIN users u ON wa.technician_id = u.id
        WHERE w.status = 'ENGINEER_VISIT_SCHEDULED' OR pr.status='ALLOCATED'
        GROUP BY w.id 
        ORDER BY w.updated_at DESC";
$wos = dbAll($sql);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Part Allocations</h1>
    <p>Issue reserved parts to technicians for scheduled jobs.</p>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Work Order #</th>
          <th>Technician</th>
          <th>Items</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if(!$wos): ?><tr><td colspan="5" class="empty-state">No pending allocation requests.</td></tr><?php endif; ?>
        <?php foreach($wos as $w): ?>
        <tr>
          <td class="font-mono"><strong><?= e($w['work_order_no']) ?></strong></td>
          <td><div style="font-weight:600"><?= e($w['tech_name']) ?></div></td>
          <td><?= $w['item_count'] ?> Parts</td>
          <td><span class="<?= badgeClass($w['status']) ?>"><?= e(woStatusLabel($w['status'])) ?></span></td>
          <td>
            <?php if($w['status'] === 'ENGINEER_VISIT_SCHEDULED'): ?>
              <a href="allocation_process.php?wo_id=<?= $w['id'] ?>" class="btn btn-sm btn-primary">Allocate Parts</a>
            <?php else: ?>
              <span class="text-muted text-sm">Allocated</span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
