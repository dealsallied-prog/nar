<?php
/**
 * Purchase Orders (Logistics)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['LOGISTICS', 'ADMIN']);

$pageTitle = 'Purchase Orders';
$status = $_GET['status'] ?? 'ORDERED';

$sql = "SELECT po.*, p.name as part_name, p.sku, w.work_order_no 
        FROM part_orders po 
        JOIN parts p ON po.part_id = p.id 
        LEFT JOIN work_orders w ON po.work_order_id = w.id 
        WHERE po.status = ? ORDER BY po.id DESC";
$orders = dbAll($sql, [$status]);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Purchase Orders</h1>
    <p>Track parts ordered from suppliers.</p>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title">Order List</div>
    <form method="GET">
      <select name="status" onchange="this.form.submit()" class="form-control" style="width: 200px; padding: 6px; border-radius: 4px;">
        <option value="ORDERED" <?= $status === 'ORDERED' ? 'selected' : '' ?>>Ordered (Pending)</option>
        <option value="RECEIVED" <?= $status === 'RECEIVED' ? 'selected' : '' ?>>Received</option>
      </select>
    </form>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>PO Number</th>
          <th>Work Order</th>
          <th>Part (SKU)</th>
          <th>Qty Ordered</th>
          <th>Qty Received</th>
          <th>Status</th>
          <?php if($status==='ORDERED'): ?><th>Action</th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php if(!$orders): ?><tr><td colspan="7" class="empty-state">No orders found.</td></tr><?php endif; ?>
        <?php foreach($orders as $o): ?>
        <tr>
          <td class="font-mono"><strong><?= e($o['po_number']?:'—') ?></strong></td>
          <td><a href="../service/workorder_view.php?id=<?= $o['work_order_id'] ?>" class="font-mono"><?= e($o['work_order_no']) ?></a></td>
          <td><div style="font-weight:600"><?= e($o['part_name']) ?></div><div class="text-sm text-muted"><?= e($o['sku']) ?></div></td>
          <td><?= qty($o['quantity']) ?></td>
          <td><?= qty($o['qty_received']) ?></td>
          <td><span class="<?= badgeClass($o['status']) ?>"><?= e($o['status']) ?></span></td>
          <?php if($status==='ORDERED'): ?>
          <td>
            <a href="receipt.php?po_id=<?= $o['id'] ?>" class="btn btn-sm btn-primary" style="color: white; font-weight: 600;">Receive Goods</a>
          </td>
          <?php endif; ?>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
