<?php
/**
 * Goods Receipt (Logistics)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['LOGISTICS', 'ADMIN']);

$poId = (int)($_GET['po_id'] ?? 0);
if (!$poId) {
    setFlash('error', 'Select a PO to receive.');
    redirect('orders.php');
}

$po = dbOne("SELECT po.*, p.name as part_name, p.sku, w.work_order_no 
             FROM part_orders po 
             JOIN parts p ON po.part_id = p.id 
             JOIN work_orders w ON po.work_order_id = w.id 
             WHERE po.id = ?", [$poId]);
if (!$po) die("Order not found.");

$remaining = $po['quantity'] - $po['qty_received'];
if ($remaining <= 0 && $po['status'] === 'RECEIVED') {
    setFlash('info', 'This order is already fully received.');
    redirect('orders.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $qtyRcv = (float)$_POST['qty_received'];
    if ($qtyRcv <= 0 || $qtyRcv > $remaining) {
        setFlash('error', 'Invalid quantity received.');
    } else {
        try {
            $pdo = db();
            $pdo->beginTransaction();
            
            // Update PO
            $newRcv = $po['qty_received'] + $qtyRcv;
            $newStatus = ($newRcv >= $po['quantity']) ? 'RECEIVED' : 'ORDERED';
            $pdo->prepare("UPDATE part_orders SET qty_received=?, status=?, received_at=NOW() WHERE id=?")
                ->execute([$newRcv, $newStatus, $poId]);
            
            // Update Requirement
            $req = dbOne("SELECT quantity_ordered, quantity_received, quantity_reserved FROM work_order_part_requirements WHERE id=?", [$po['requirement_id']]);
            $reqRcv = $req['quantity_received'] + $qtyRcv;
            $reqRes = $req['quantity_reserved'] + $qtyRcv;
            $reqStatus = ($reqRcv >= $req['quantity_ordered']) ? 'RECEIVED' : 'ORDERED'; // Received part is automatically reserved to WO
            
            // The received part goes straight into reserved stock for this WO
            $pdo->prepare("UPDATE work_order_part_requirements SET quantity_received=?, quantity_reserved=?, status=? WHERE id=?")
                ->execute([$reqRcv, $reqRes, $reqStatus, $po['requirement_id']]);
                
            // Auto Reserve for WO
            dbExec("UPDATE parts SET stock_qty = stock_qty + ? WHERE id=?", [$qtyRcv, $po['part_id']]);
            $currStock = dbOne("SELECT stock_qty FROM parts WHERE id=?", [$po['part_id']])['stock_qty'];
            dbExec("INSERT INTO stock_ledger (part_id, change_type, quantity, balance_after, note, created_by_id) VALUES (?, 'STOCK_IN', ?, ?, ?, ?)",
                [$po['part_id'], $qtyRcv, $currStock, "PO: {$po['po_number']}", $user['id']]);
                
            // Insert Serials if provided
            $serials = $_POST['serial'] ?? [];
            $makes = $_POST['make'] ?? [];
            $descs = $_POST['desc'] ?? [];
            for ($i = 0; $i < $qtyRcv; $i++) {
                $sn = trim($serials[$i] ?? '');
                if ($sn !== '') {
                    $mk = trim($makes[$i] ?? '');
                    $ds = trim($descs[$i] ?? '');
                    // The item is automatically reserved for the WO upon receipt, so we set the status to IN_STOCK but allocate it to the WO (by work_order_id)
                    dbExec("INSERT INTO part_serials (part_id, purchase_order_id, work_order_id, serial_number, make, description, status) 
                            VALUES (?, ?, ?, ?, ?, ?, 'IN_STOCK')",
                        [$po['part_id'], $poId, $po['work_order_id'], $sn, $mk, $ds]);
                }
            }
                
            // Auto Reserve for WO
            dbExec("UPDATE parts SET stock_qty = stock_qty - ?, reserved_qty = reserved_qty + ? WHERE id=?", [$qtyRcv, $qtyRcv, $po['part_id']]);
            $currStock2 = dbOne("SELECT stock_qty FROM parts WHERE id=?", [$po['part_id']])['stock_qty'];
            dbExec("INSERT INTO stock_ledger (part_id, change_type, quantity, balance_after, work_order_id, note, created_by_id) VALUES (?, 'RESERVE', ?, ?, ?, ?, ?)",
                [$po['part_id'], $qtyRcv, $currStock2, $po['work_order_id'], "Auto-reserved from PO {$po['po_number']}", $user['id']]);

            // Notify Service Controller
            notify("{$po['work_order_no']}: Part {$po['sku']} received (" . qty($qtyRcv) . " " . ($newStatus === 'RECEIVED' ? "Full" : "Partial") . ")", null, 'SERVICE_CONTROLLER', $po['work_order_id']);

            // Check if WO is completely fulfilled (all parts received/reserved)
            $allReqs = dbAll("SELECT status FROM work_order_part_requirements WHERE work_order_id=?", [$po['work_order_id']]);
            $allDone = true;
            foreach ($allReqs as $r) {
                if (!in_array($r['status'], ['RESERVED', 'RECEIVED'])) $allDone = false;
            }
            if ($allDone) {
                dbExec("UPDATE work_orders SET status='PARTS_RECEIVED' WHERE id=?", [$po['work_order_id']]);
                addLog($po['work_order_id'], $user['id'], 'All Parts Received', 'PARTS_ORDERING', 'PARTS_RECEIVED');
                notify("All parts ready for {$po['work_order_no']}. Schedule Engineer Visit.", null, 'SERVICE_CONTROLLER', $po['work_order_id']);
            }
            
            $pdo->commit();
            setFlash('success', 'Goods received and automatically reserved for Work Order.');
            redirect('orders.php');
        } catch (Exception $e) {
            if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
            setFlash('error', 'Error: ' . $e->getMessage());
        }
    }
}

$pageTitle = 'Receive Goods';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Receive Goods</h1>
    <p>PO: <?= e($po['po_number']) ?></p>
  </div>
  <div class="page-actions"><a href="orders.php" class="btn btn-ghost">← Back</a></div>
</div>

<div class="card" style="max-width: 600px;">
  <div class="card-header"><div class="card-title">Receipt Details</div></div>
  <div class="card-body">
    <div class="detail-grid" style="margin-bottom: 20px;">
      <div class="detail-row"><div class="detail-label">Part</div><div class="detail-value"><?= e($po['part_name']) ?> (<?= e($po['sku']) ?>)</div></div>
      <div class="detail-row"><div class="detail-label">Work Order</div><div class="detail-value font-mono"><?= e($po['work_order_no']) ?></div></div>
      <div class="detail-row"><div class="detail-label">Total Ordered</div><div class="detail-value"><?= qty($po['quantity']) ?></div></div>
      <div class="detail-row"><div class="detail-label">Already Received</div><div class="detail-value"><?= qty($po['qty_received']) ?></div></div>
      <div class="detail-row"><div class="detail-label">Pending Receipt</div><div class="detail-value font-bold text-sky"><?= qty($remaining) ?></div></div>
    </div>
    
    <form method="POST">
      <div class="form-group">
        <label>Quantity Receiving Now</label>
        <input type="number" name="qty_received" id="qtyRcvInput" step="1" max="<?= $remaining ?>" value="<?= $remaining ?>" required oninput="generateSerialInputs()">
        <div class="form-hint">Must not exceed pending quantity (<?= qty($remaining) ?>).</div>
      </div>
      
      <div id="serialInputsContainer" style="margin-top:20px; border-top:1px solid var(--border); padding-top:15px;">
        <!-- Javascript will populate this -->
      </div>

      <div style="margin-top:20px;">
        <button type="submit" class="btn btn-primary">Confirm Receipt</button>
      </div>
    </form>
  </div>
</div>

<script>
function generateSerialInputs() {
    const qty = parseInt(document.getElementById('qtyRcvInput').value) || 0;
    const container = document.getElementById('serialInputsContainer');
    
    // Save current values if possible to prevent wiping on every keystroke
    const currentSerials = Array.from(document.querySelectorAll('input[name="serial[]"]')).map(el => el.value);
    const currentMakes = Array.from(document.querySelectorAll('input[name="make[]"]')).map(el => el.value);
    const currentDescs = Array.from(document.querySelectorAll('input[name="desc[]"]')).map(el => el.value);
    
    container.innerHTML = '';
    
    if (qty > 0) {
        let html = '<p class="font-bold mb-3">Item Details (Optional Serial Tracking)</p>';
        for(let i=0; i<qty; i++) {
            let sn = currentSerials[i] || '';
            let mk = currentMakes[i] || '';
            let ds = currentDescs[i] || '';
            html += `
            <div style="display:flex; gap:10px; margin-bottom:10px; padding:10px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:4px;">
                <div style="flex:1;">
                    <label style="font-size:12px;">Serial Number ${i+1}</label>
                    <input type="text" name="serial[]" placeholder="Serial Number" value="${sn}">
                </div>
                <div style="flex:1;">
                    <label style="font-size:12px;">Make</label>
                    <input type="text" name="make[]" placeholder="Make / Brand" value="${mk}">
                </div>
                <div style="flex:1;">
                    <label style="font-size:12px;">Description</label>
                    <input type="text" name="desc[]" placeholder="Variant / Details" value="${ds}">
                </div>
            </div>`;
        }
        container.innerHTML = html;
    }
}
document.addEventListener('DOMContentLoaded', generateSerialInputs);
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

