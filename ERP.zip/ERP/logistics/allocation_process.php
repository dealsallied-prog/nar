<?php
/**
 * Allocate Parts with Serial Numbers (Logistics)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['LOGISTICS', 'ADMIN']);

$woId = (int)($_GET['wo_id'] ?? 0);
if (!$woId) {
    redirect('allocations.php');
}

$wo = dbOne("SELECT * FROM work_orders WHERE id=?", [$woId]);
if (!$wo) die("Work order not found");

$reqs = dbAll("SELECT pr.*, p.name as part_name, p.sku, wa.technician_id
               FROM work_order_part_requirements pr 
               JOIN parts p ON pr.part_id = p.id
               JOIN work_order_assignments wa ON pr.work_order_id = wa.work_order_id
               WHERE pr.work_order_id=? AND pr.quantity_reserved > 0 AND pr.status != 'ALLOCATED'", [$woId]);

if (empty($reqs)) {
    setFlash('info', 'No pending parts to allocate for this Work Order.');
    redirect('allocations.php');
}

$techId = $reqs[0]['technician_id'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['allocate'])) {
    $pdo = db();
    $pdo->beginTransaction();
    
    try {
        foreach ($reqs as $r) {
            $qty = $r['quantity_reserved'];
            
            // Create allocation record
            dbExec("INSERT INTO part_allocations (work_order_id, technician_id, part_id, requirement_id, quantity, status, requested_by_id, allocated_at) 
                    VALUES (?,?,?,?,?,'ALLOCATED',?,NOW())",
                [$woId, $techId, $r['part_id'], $r['id'], $qty, $user['id']]);
                
            $allocId = $pdo->lastInsertId();
            
            // Link selected serial numbers to this allocation
            $selectedSerials = $_POST['serials'][$r['part_id']] ?? [];
            if (!empty($selectedSerials)) {
                // Number of serials shouldn't exceed qty, but we won't strictly validate right now
                foreach ($selectedSerials as $sId) {
                    dbExec("UPDATE part_serials SET status='ALLOCATED', technician_id=?, allocation_id=? WHERE id=? AND status='IN_STOCK'", [$techId, $allocId, $sId]);
                }
            }
            
            // Move from reserved to issued
            dbExec("UPDATE parts SET reserved_qty = reserved_qty - ? WHERE id=?", [$qty, $r['part_id']]);
            $currStock = dbOne("SELECT stock_qty FROM parts WHERE id=?", [$r['part_id']])['stock_qty'];
            dbExec("INSERT INTO stock_ledger (part_id, change_type, quantity, balance_after, work_order_id, created_by_id, note) VALUES (?, 'ISSUE', ?, ?, ?, ?, ?)",
                [$r['part_id'], $qty, $currStock, $woId, $user['id'], "Issued to Technician"]);
                
            // Update requirement status
            dbExec("UPDATE work_order_part_requirements SET status='ALLOCATED' WHERE id=?", [$r['id']]);
        }
        
        dbExec("UPDATE work_orders SET status='PARTS_ALLOCATED' WHERE id=?", [$woId]);
        addLog($woId, $user['id'], 'Allocated Parts to Technician', 'ENGINEER_VISIT_SCHEDULED', 'PARTS_ALLOCATED');
        notify("Parts allocated for {$wo['work_order_no']}. You can proceed.", $techId, null, $woId);
        
        $pdo->commit();
        setFlash('success', 'Parts successfully allocated to technician.');
        redirect('allocations.php');
    } catch (Exception $e) {
        $pdo->rollBack();
        setFlash('error', "Error: " . $e->getMessage());
    }
}

$pageTitle = 'Process Allocation';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Allocate Parts</h1>
    <p><?= e($wo['work_order_no']) ?></p>
  </div>
  <div class="page-actions"><a href="allocations.php" class="btn btn-ghost">← Back</a></div>
</div>

<form method="POST">
  <?php foreach($reqs as $r): ?>
  <div class="card" style="margin-bottom:20px;">
    <div class="card-header"><div class="card-title"><?= e($r['part_name']) ?> (<?= e($r['sku']) ?>)</div></div>
    <div class="card-body">
       <p><strong>Required Qty:</strong> <?= qty($r['quantity_reserved']) ?></p>
       
       <?php 
         $availableSerials = dbAll("SELECT id, serial_number, make, description FROM part_serials WHERE part_id=? AND status='IN_STOCK' AND work_order_id=?", [$r['part_id'], $woId]);
       ?>
       
       <?php if(count($availableSerials) > 0): ?>
          <div style="margin-top:15px;">
             <label style="font-weight:600; display:block; margin-bottom:5px;">Select Serial Numbers to Allocate:</label>
             <div style="max-height:150px; overflow-y:auto; border:1px solid var(--border); border-radius:4px; padding:10px; background:#f8fafc;">
               <?php foreach($availableSerials as $sn): ?>
                 <div style="margin-bottom:8px;">
                   <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                     <input type="checkbox" name="serials[<?= $r['part_id'] ?>][]" value="<?= $sn['id'] ?>">
                     <span><?= e($sn['serial_number']) ?> <small class="text-muted">(<?= e($sn['make']) ?> - <?= e($sn['description']) ?>)</small></span>
                   </label>
                 </div>
               <?php endforeach; ?>
             </div>
             <p class="form-hint" style="margin-top:5px;">Please select exactly <?= qty($r['quantity_reserved']) ?> serial numbers if this is a serialized part.</p>
          </div>
       <?php else: ?>
          <div class="form-hint" style="margin-top:15px;">No serial numbers available/required for this part.</div>
       <?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?>
  
  <button type="submit" name="allocate" class="btn btn-primary" onclick="return confirm('Confirm allocation to technician?')">Confirm Allocation</button>
</form>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
