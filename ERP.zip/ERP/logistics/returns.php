<?php
/**
 * Part Returns (Logistics)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['LOGISTICS', 'ADMIN']);

if (isset($_POST['receive_return'])) {
    $allocId = (int)$_POST['alloc_id'];
    $alloc = dbOne("SELECT * FROM part_allocations WHERE id=? AND status='RETURN_PENDING'", [$allocId]);
    
    if ($alloc) {
        $qty = $alloc['qty_returned'];
        $pdo = db();
        $pdo->beginTransaction();
        
        // Update allocation
        $pdo->prepare("UPDATE part_allocations SET status='RETURNED', returned_at=NOW() WHERE id=?")->execute([$allocId]);
        
        // Restock Serials if any
        $pdo->prepare("UPDATE part_serials SET status='IN_STOCK', allocation_id=NULL, work_order_id=NULL, technician_id=NULL WHERE allocation_id=? AND status='RETURN_PENDING'")->execute([$allocId]);
        
        // Restock bulk ledger
        $pdo->prepare("UPDATE parts SET stock_qty = stock_qty + ? WHERE id=?")->execute([$qty, $alloc['part_id']]);
        
        // Ledger
        $currStock = dbOne("SELECT stock_qty FROM parts WHERE id=?", [$alloc['part_id']])['stock_qty'];
        $pdo->prepare("INSERT INTO stock_ledger (part_id, change_type, quantity, balance_after, work_order_id, created_by_id, note) VALUES (?, 'RETURN_IN', ?, ?, ?, ?, ?)")
            ->execute([$alloc['part_id'], $qty, $currStock, $alloc['work_order_id'], $user['id'], 'Returned from tech (unused)']);
            
        $pdo->commit();
        setFlash('success', "Part received and returned to stock.");
    }
    redirect('returns.php');
}

$pageTitle = 'Returns Pending';
$sql = "SELECT a.*, p.name as part_name, p.sku, w.work_order_no, u.name as tech_name 
        FROM part_allocations a 
        JOIN parts p ON a.part_id = p.id 
        JOIN work_orders w ON a.work_order_id = w.id 
        JOIN users u ON a.technician_id = u.id 
        WHERE a.status IN ('RETURN_PENDING', 'RETURNED') 
        ORDER BY a.id DESC";
$returns = dbAll($sql);

require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><div><h1>Returns Processing</h1><p>Receive unused parts returned by technicians.</p></div></div>
<div class="card"><div class="table-wrap"><table class="data-table">
  <thead><tr><th>Work Order</th><th>Technician</th><th>Part</th><th>Qty Returned</th><th>Status</th><th>Action</th></tr></thead>
  <tbody>
    <?php if(!$returns): ?><tr><td colspan="6" class="empty-state">No returns pending.</td></tr><?php endif; ?>
    <?php foreach($returns as $r): ?>
    <tr>
      <td><a href="../service/workorder_view.php?id=<?= $r['work_order_id'] ?>" class="font-mono"><strong><?= e($r['work_order_no']) ?></strong></a></td>
      <td><?= e($r['tech_name']) ?></td>
      <td>
        <div style="font-weight:600"><?= e($r['part_name']) ?></div><div class="text-sm text-muted"><?= e($r['sku']) ?></div>
        <?php
          $retSerials = dbAll("SELECT serial_number, make, description FROM part_serials WHERE allocation_id=? AND status IN ('RETURN_PENDING', 'IN_STOCK')", [$r['id']]);
          if(count($retSerials) > 0):
        ?>
          <div style="margin-top:5px; font-size:12px; background:#f1f5f9; padding:5px; border-radius:4px;">
            <strong>Serials:</strong><br>
            <?php foreach($retSerials as $s): ?>
              - <?= e($s['serial_number']) ?> <span class="text-muted">(<?= e($s['make']) ?>)</span><br>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </td>
      <td class="font-bold text-rose"><?= qty($r['qty_returned']) ?></td>
      <td><span class="<?= badgeClass($r['status']) ?>"><?= e(allocStatusLabel($r['status'])) ?></span></td>
      <td>
        <?php if($r['status'] === 'RETURN_PENDING'): ?>
          <form method="POST" style="display:inline-block">
            <input type="hidden" name="alloc_id" value="<?= $r['id'] ?>">
            <button type="submit" name="receive_return" class="btn btn-sm btn-primary">Mark Received</button>
          </form>
        <?php else: ?>
          <span class="text-muted text-sm"><?= dtShort($r['returned_at']) ?></span>
        <?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table></div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
