<?php
/**
 * Stock Reservations (Logistics)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['LOGISTICS', 'ADMIN']);

$pageTitle = 'Stock Reservations';
$sql = "SELECT pr.*, p.name as part_name, p.sku, w.work_order_no 
        FROM work_order_part_requirements pr 
        JOIN parts p ON pr.part_id = p.id 
        JOIN work_orders w ON pr.work_order_id = w.id 
        WHERE pr.quantity_reserved > 0 
        ORDER BY pr.id DESC";
$res = dbAll($sql);

require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header"><div><h1>Stock Reservations</h1><p>Currently reserved stock against Work Orders.</p></div></div>
<div class="card"><div class="table-wrap"><table class="data-table">
  <thead><tr><th>Work Order</th><th>Part</th><th>Qty Reserved</th><th>Status</th></tr></thead>
  <tbody>
    <?php if(!$res): ?><tr><td colspan="4" class="empty-state">No reserved stock.</td></tr><?php endif; ?>
    <?php foreach($res as $r): ?>
    <tr>
      <td><a href="../service/workorder_view.php?id=<?= $r['work_order_id'] ?>" class="font-mono"><strong><?= e($r['work_order_no']) ?></strong></a></td>
      <td><div style="font-weight:600"><?= e($r['part_name']) ?></div><div class="text-sm text-muted"><?= e($r['sku']) ?></div></td>
      <td class="font-bold text-sky"><?= qty($r['quantity_reserved']) ?></td>
      <td><span class="<?= badgeClass($r['status']) ?>"><?= e($r['status']) ?></span></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table></div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
