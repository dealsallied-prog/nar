<?php
/**
 * Sales / Leads list
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SALES']);

$pageTitle = 'Leads & Work Orders';
$statusFilter = $_GET['status'] ?? 'ALL';

$sql = "SELECT w.*, c.name AS customer_name, c.email, c.phone 
        FROM work_orders w 
        JOIN customers c ON w.customer_id = c.id 
        WHERE 1=1";
$params = [];

if ($statusFilter !== 'ALL') {
    $sql .= " AND w.status = ?";
    $params[] = $statusFilter;
}

$sql .= " ORDER BY w.id DESC";
$leads = dbAll($sql, $params);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Leads & Work Orders</h1>
    <p>Manage all sales inquiries and pipeline.</p>
  </div>
  <div class="page-actions">
    <a href="leads_new.php" class="btn btn-primary">➕ New Lead</a>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title">All Records</div>
    <div>
      <form method="GET" class="flex-gap">
        <select name="status" onchange="this.form.submit()" class="form-control" style="width: 200px; padding: 6px; border-radius: 4px;">
          <option value="ALL" <?= $statusFilter === 'ALL' ? 'selected' : '' ?>>All Statuses</option>
          <?php foreach(WO_STATUS_LABEL as $val => $label): ?>
            <option value="<?= $val ?>" <?= $statusFilter === $val ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </form>
    </div>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Work Order #</th>
          <th>Date</th>
          <th>Customer</th>
          <th>Source</th>
          <th>Expected Budget</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($leads)): ?>
        <tr><td colspan="7" class="empty-state">No leads found.</td></tr>
        <?php else: foreach ($leads as $l): ?>
        <tr>
          <td class="font-mono"><strong><?= e($l['work_order_no']) ?></strong></td>
          <td><?= dtShort($l['created_at']) ?></td>
          <td>
            <div style="font-weight: 600; color: var(--navy2)"><?= e($l['customer_name']) ?></div>
            <div style="font-size: 11px; color: var(--slate5)"><?= e($l['phone']) ?></div>
          </td>
          <td><?= e($l['source'] ?: '—') ?></td>
          <td><?= $l['expected_budget'] > 0 ? money($l['expected_budget']) : '—' ?></td>
          <td>
             <span class="<?= badgeClass($l['status']) ?>"><?= e(woStatusLabel($l['status'])) ?></span>
             <?php if ($l['dept_status']): ?>
                <div style="font-size:10px; color:var(--slate5); margin-top:2px;"><?= e($l['dept_status']) ?></div>
             <?php endif; ?>
          </td>
          <td>
            <a href="leads_view.php?id=<?= $l['id'] ?>" class="btn btn-sm btn-outline-sky">View</a>
          </td>
        </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
