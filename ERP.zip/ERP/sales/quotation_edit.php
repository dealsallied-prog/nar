<?php
/**
 * Edit / View Quotation
 * Includes Line Items + Revisions + Approval
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SALES']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($_POST) && $_SERVER['CONTENT_LENGTH'] > 0) {
    die("Error: The uploaded file is too large. Please upload a file smaller than " . ini_get('post_max_size'));
}

$id = (int)($_GET['id'] ?? 0);
$q = dbOne("SELECT q.*, w.work_order_no, w.status AS wo_status, w.customer_id, c.name AS customer_name, c.phone, c.email 
            FROM quotations q 
            JOIN work_orders w ON q.work_order_id=w.id 
            JOIN customers c ON w.customer_id=c.id 
            WHERE q.id=?", [$id]);
if (!$q) die("Quotation not found.");

$woId = $q['work_order_id'];
$isReadonly = in_array($q['status'], ['APPROVED', 'SUPERSEDED']);

// Add Item
if (isset($_POST['add_item']) && !$isReadonly) {
    $type  = $_POST['item_type'] ?? 'PARTS';
    $desc  = trim($_POST['description']);
    $partId= ($type === 'PARTS' && !empty($_POST['part_id'])) ? (int)$_POST['part_id'] : null;
    $qty   = (float)($_POST['quantity'] ?? 1);
    $price = (float)($_POST['unit_price'] ?? 0);
    $total = $qty * $price;
    
    if (!$desc && $partId) {
        $p = dbOne("SELECT name FROM parts WHERE id=?", [$partId]);
        if ($p) $desc = $p['name'];
    }
    
    dbExec("INSERT INTO quotation_items (quotation_id, item_type, part_id, description, quantity, unit_price, total) VALUES (?,?,?,?,?,?,?)",
        [$id, $type, $partId, $desc, $qty, $price, $total]);
    updateTotals($id);
    setFlash('success', 'Item added.');
    redirect("quotation_edit.php?id=$id");
}

// Remove Item
if (isset($_GET['remove_item']) && !$isReadonly) {
    dbExec("DELETE FROM quotation_items WHERE id=? AND quotation_id=?", [$_GET['remove_item'], $id]);
    updateTotals($id);
    setFlash('success', 'Item removed.');
    redirect("quotation_edit.php?id=$id");
}

// Update Item
if (isset($_POST['update_item']) && !$isReadonly) {
    $itemId = (int)$_POST['item_id'];
    $type  = $_POST['item_type'] ?? 'PARTS';
    $desc  = trim($_POST['description']);
    $qty   = (float)($_POST['quantity'] ?? 1);
    $price = (float)($_POST['unit_price'] ?? 0);
    $total = $qty * $price;
    
    dbExec("UPDATE quotation_items SET item_type=?, description=?, quantity=?, unit_price=?, total=? WHERE id=? AND quotation_id=?",
        [$type, $desc, $qty, $price, $total, $itemId, $id]);
    updateTotals($id);
    setFlash('success', 'Item updated.');
    redirect("quotation_edit.php?id=$id");
}

// Update settings (tax, discount, terms)
if (isset($_POST['update_settings']) && !$isReadonly) {
    $tax = (float)($_POST['tax_percent'] ?? 0);
    $dsc = (float)($_POST['discount'] ?? 0);
    $val = (int)($_POST['validity_days'] ?? 30);
    $trm = trim($_POST['terms'] ?? '');
    dbExec("UPDATE quotations SET tax_percent=?, discount=?, validity_days=?, terms=? WHERE id=?", [$tax, $dsc, $val, $trm, $id]);
    updateTotals($id);
    
    if (isset($_POST['ajax'])) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'success']);
        exit;
    }
    
    setFlash('success', 'Quotation settings updated.');
    redirect("quotation_edit.php?id=$id");
}

// Send to Customer
if (isset($_POST['send_quote']) && !$isReadonly) {
    $notes = null;
    if (!empty($_FILES['sent_pdf']['name']) && $_FILES['sent_pdf']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['sent_pdf']['name'], PATHINFO_EXTENSION));
        $newName = uniqid('sent_') . '.' . $ext;
        if (move_uploaded_file($_FILES['sent_pdf']['tmp_name'], __DIR__ . '/../uploads/quotations/' . $newName)) {
            $notes = $newName;
        }
    }
    
    dbExec("UPDATE quotations SET status='SENT', sent_at=NOW(), notes=? WHERE id=?", [$notes, $id]);
    dbExec("UPDATE work_orders SET status='QUOTATION_SENT' WHERE id=?", [$woId]);
    addLog($woId, $user['id'], 'Sent Quotation', $q['wo_status'], 'QUOTATION_SENT', "V{$q['version']} sent to customer.");
    setFlash('success', 'Quotation marked as Sent.');
    redirect("quotation_edit.php?id=$id");
}

// Customer Approves
if (isset($_POST['approve_quote']) && !$isReadonly) {
    $proofText = trim($_POST['approval_proof'] ?? '');
    $proofFile = null;
    if (!empty($_FILES['proof_file']['name']) && $_FILES['proof_file']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['proof_file']['name'], PATHINFO_EXTENSION));
        $newName = uniqid('proof_') . '.' . $ext;
        if (move_uploaded_file($_FILES['proof_file']['tmp_name'], __DIR__ . '/../uploads/approvals/' . $newName)) {
            $proofFile = $newName;
        }
    }
    $proofData = json_encode(['text' => $proofText, 'file' => $proofFile]);

    // Supersede any other active quotes for this WO
    dbExec("UPDATE quotations SET status='SUPERSEDED' WHERE work_order_id=? AND id!=? AND status NOT IN ('REJECTED','SUPERSEDED')", [$woId, $id]);
    
    dbExec("UPDATE quotations SET status='APPROVED', approved_at=NOW(), approval_proof=? WHERE id=?", [$proofData, $id]);
    
    // Check if we are in the revision loop
    if ($q['wo_status'] === 'REVISION_IN_PROGRESS') {
        dbExec("UPDATE work_orders SET status='FINAL_QUOTE_APPROVED' WHERE id=?", [$woId]);
        addLog($woId, $user['id'], 'Final Revised Quotation Approved', $q['wo_status'], 'FINAL_QUOTE_APPROVED', "V{$q['version']} Approved");
        notify("Revised quotation V{$q['version']} approved by customer. Ready for parts ordering.", null, 'SERVICE_CONTROLLER', $woId);
    } else {
        dbExec("UPDATE work_orders SET status='QUOTATION_APPROVED' WHERE id=?", [$woId]);
        addLog($woId, $user['id'], 'Quotation Approved', $q['wo_status'], 'QUOTATION_APPROVED', "V{$q['version']} Approved");
    }
    
    setFlash('success', 'Quotation Approved! You can now Handover to Service.');
    redirect("leads_view.php?id=$woId");
}

// Create Revision (Copy into new Draft)
if (isset($_POST['create_revision'])) {
    $reason = trim($_POST['revision_reason']);
    $pdo = db();
    $nextV = $q['version'] + 1;
    $newQNo = "QT-{$woId}-V{$nextV}";
    
    // Copy main
    $newQId = dbExec("INSERT INTO quotations (work_order_id, version, quotation_no, status, subtotal, tax_percent, tax_amount, discount, total, validity_days, terms, revision_reason, created_by_id) 
            SELECT work_order_id, ?, ?, 'DRAFT', subtotal, tax_percent, tax_amount, discount, total, validity_days, terms, ?, ? 
            FROM quotations WHERE id=?", [$nextV, $newQNo, $reason, $user['id'], $id]);

    
    // Copy items
    dbExec("INSERT INTO quotation_items (quotation_id, item_type, part_id, description, quantity, unit_price, total) 
            SELECT ?, item_type, part_id, description, quantity, unit_price, total FROM quotation_items WHERE quotation_id=?", [$newQId, $id]);
            
    // Supersede old
    dbExec("UPDATE quotations SET status='SUPERSEDED' WHERE id=?", [$id]);
    addLog($woId, $user['id'], "Created Quote Revision V{$nextV}", null, null, "Reason: $reason");
    
    setFlash('success', "Revision V{$nextV} created.");
    redirect("quotation_edit.php?id=$newQId");
}

function updateTotals($qid) {
    $q = dbOne("SELECT * FROM quotations WHERE id=?", [$qid]);
    $sub = dbOne("SELECT SUM(total) as s FROM quotation_items WHERE quotation_id=?", [$qid])['s'] ?? 0;
    $taxAmt = $sub * ($q['tax_percent'] / 100);
    $tot = $sub + $taxAmt - $q['discount'];
    dbExec("UPDATE quotations SET subtotal=?, tax_amount=?, total=? WHERE id=?", [$sub, $taxAmt, $tot, $qid]);
}

$items = dbAll("SELECT * FROM quotation_items WHERE quotation_id=? ORDER BY id ASC", [$id]);
$parts = dbAll("SELECT * FROM parts ORDER BY name ASC");

$pageTitle = "Quotation V{$q['version']} - " . $q['work_order_no'];
require_once __DIR__ . '/../includes/header.php';
?>

<div class="breadcrumb">
  <a href="leads.php">Leads</a> <span>›</span>
  <a href="leads_view.php?id=<?= $woId ?>"><?= e($q['work_order_no']) ?></a> <span>›</span>
  Quotation V<?= $q['version'] ?>
</div>

<div class="page-header">
  <div>
    <h1>Quotation <?= e($q['quotation_no']) ?></h1>
    <p><?= e($q['customer_name']) ?> — <span class="<?= badgeClass($q['status']) ?>"><?= e(quotationStatusLabel($q['status'])) ?></span></p>
  </div>
  <div class="page-actions">
    <a href="quotation_print.php?id=<?= $id ?>" target="_blank" class="btn btn-outline-sky">🖨️ Print / View PDF</a>
    <?php if ($q['status'] === 'DRAFT'): ?>
       <button class="btn btn-primary" onclick="openModal('sendModal')">📤 Send to Customer</button>
    <?php elseif ($q['status'] === 'SENT'): ?>
       <button class="btn btn-success" onclick="openModal('approveModal')">✅ Customer Approved</button>
       <button class="btn btn-warning" onclick="openModal('reviseModal')">🔄 Create Revision</button>
    <?php elseif ($q['status'] === 'APPROVED'): ?>
       <!-- Already approved -->
       <button class="btn btn-warning" onclick="openModal('reviseModal')">🔄 Create Revision</button>
    <?php else: ?>
       <!-- SUPERSEDED -->
       <span class="text-muted">This version is superseded.</span>
    <?php endif; ?>
  </div>
</div>

<?php if($q['revision_reason']): ?>
<div class="alert alert-info">
  <strong>Revision Reason:</strong> <?= nl2br(e($q['revision_reason'])) ?>
</div>
<?php endif; ?>

<div class="detail-grid" style="margin-bottom: 24px;">
  <!-- Line Items -->
  <div class="card" style="grid-column: 1 / -1;">
    <div class="card-header"><div class="card-title">Line Items</div></div>
    <div class="table-wrap">
      <form method="POST">
      <table class="qi-table">
        <thead>
          <tr>
            <th width="80">Type</th>
            <th>Description / Part</th>
            <th width="80">Qty</th>
            <th width="120">Unit Price</th>
            <th width="120">Total</th>
            <?php if(!$isReadonly): ?><th width="40"></th><?php endif; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach($items as $it): 
            $isEditing = (isset($_GET['edit_item']) && $_GET['edit_item'] == $it['id']) && !$isReadonly;
          ?>
          <?php if ($isEditing): ?>
          <tr style="background:#f8fafc">
            <input type="hidden" name="item_id" value="<?= $it['id'] ?>">
            <td>
              <select name="item_type" required>
                <option value="PARTS" <?= $it['item_type']=='PARTS'?'selected':'' ?>>Part</option>
                <option value="LABOUR" <?= $it['item_type']=='LABOUR'?'selected':'' ?>>Labour</option>
                <option value="OTHER" <?= $it['item_type']=='OTHER'?'selected':'' ?>>Other</option>
              </select>
            </td>
            <td><input type="text" name="description" value="<?= e($it['description']) ?>" required style="width:100%"></td>
            <td><input type="number" name="quantity" step="0.01" value="<?= (float)$it['quantity'] ?>" required style="width:100%"></td>
            <td><input type="number" name="unit_price" step="0.01" value="<?= (float)$it['unit_price'] ?>" required style="width:100%"></td>
            <td style="font-weight:600"><?= money($it['total']) ?></td>
            <td style="text-align:right; display:flex; gap:4px; justify-content:flex-end;">
              <button type="submit" name="update_item" class="btn btn-xs btn-primary">Save</button>
              <a href="?id=<?= $id ?>" class="btn btn-xs btn-ghost">Cancel</a>
              <a href="?id=<?= $id ?>&remove_item=<?= $it['id'] ?>" class="btn btn-xs btn-danger">Delete</a>
            </td>
          </tr>
          <?php else: ?>
          <tr>
            <td><span class="type-badge type-<?= $it['item_type'] ?>"><?= e($it['item_type']) ?></span></td>
            <td><?= e($it['description']) ?></td>
            <td><?= qty($it['quantity']) ?></td>
            <td><?= money($it['unit_price']) ?></td>
            <td style="font-weight:600"><?= money($it['total']) ?></td>
            <?php if(!$isReadonly): ?>
            <td style="text-align:right; display:flex; gap:4px; justify-content:flex-end;">
              <a href="?id=<?= $id ?>&edit_item=<?= $it['id'] ?>" class="btn btn-xs btn-outline-sky">Edit</a>
              <a href="?id=<?= $id ?>&remove_item=<?= $it['id'] ?>" class="btn btn-xs btn-danger">Delete</a>
            </td>
            <?php endif; ?>
          </tr>
          <?php endif; ?>
          <?php endforeach; ?>
          <?php if(!$isReadonly && !isset($_GET['edit_item'])): ?>
          <!-- Add Item Row -->
          <tr style="background:#f8fafc">
            <td>
              <select name="item_type" required>
                <option value="PARTS">Part</option>
                <option value="LABOUR">Labour</option>
                <option value="OTHER">Other</option>
              </select>
            </td>
            <td>
              <select name="part_id" onchange="if(this.value){ const opt = this.options[this.selectedIndex]; document.getElementById('new_desc').value = opt.text; document.getElementById('new_price').value = opt.dataset.price; }">
                <option value="">-- Select from Inventory --</option>
                <?php foreach($parts as $p): ?>
                  <option value="<?= $p['id'] ?>" data-price="<?= $p['unit_price'] ?>"><?= e($p['name']) ?> (<?= e($p['sku']) ?>)</option>
                <?php endforeach; ?>
              </select>
              <input type="text" name="description" id="new_desc" placeholder="Or type custom description..." style="margin-top:4px;">
            </td>
            <td><input type="number" name="quantity" step="0.01" value="1" required></td>
            <td><input type="number" name="unit_price" id="new_price" step="0.01" value="0.00" required></td>
            <td colspan="2"><button type="submit" name="add_item" class="btn btn-xs btn-primary">Add</button></td>
          </tr>
          <?php endif; ?>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="4" style="text-align:right; font-weight:400; color:var(--slate5);">Subtotal:</td>
            <td colspan="2"><?= money($q['subtotal']) ?></td>
          </tr>
          <tr>
            <td colspan="4" style="text-align:right; font-weight:400; color:var(--slate5);">Tax (<?= (float)$q['tax_percent'] ?>%):</td>
            <td colspan="2">+ <?= money($q['tax_amount']) ?></td>
          </tr>
          <tr>
            <td colspan="4" style="text-align:right; font-weight:400; color:var(--slate5);">Discount:</td>
            <td colspan="2">- <?= money($q['discount']) ?></td>
          </tr>
          <tr>
            <td colspan="4" style="text-align:right; font-size:14px; color:var(--navy2);">Grand Total:</td>
            <td colspan="2" style="font-size:16px; font-weight:700; color:var(--sky);"><?= money($q['total']) ?></td>
          </tr>
        </tfoot>
      </table>
      </form>
    </div>
  </div>

  <!-- Settings -->
  <div class="card">
    <div class="card-header"><div class="card-title">Commercial Terms</div></div>
    <div class="card-body">
      <form method="POST" id="commercialTermsForm">
        <div class="form-grid">
          <div class="form-group">
            <label>Tax %</label>
            <input type="number" name="tax_percent" step="0.01" value="<?= (float)$q['tax_percent'] ?>" <?= $isReadonly?'disabled':'' ?>>
          </div>
          <div class="form-group">
            <label>Discount Amount (₹)</label>
            <input type="number" name="discount" step="0.01" value="<?= (float)$q['discount'] ?>" <?= $isReadonly?'disabled':'' ?>>
          </div>
          <div class="form-group">
            <label>Validity (Days)</label>
            <input type="number" name="validity_days" value="<?= (int)$q['validity_days'] ?>" <?= $isReadonly?'disabled':'' ?>>
          </div>
          <div class="form-group full">
            <label>Terms & Conditions</label>
            <textarea name="terms" rows="3" <?= $isReadonly?'disabled':'' ?>><?= e($q['terms']) ?></textarea>
          </div>
          <?php if(!$isReadonly): ?>
          <div class="form-group full" style="display:flex; justify-content:space-between; align-items:center;">
            <span id="autoSaveStatus" class="text-sm text-muted"></span>
            <button type="submit" name="update_settings" class="btn btn-sm btn-ghost">Update Terms & Totals (Manual Save)</button>
          </div>
          <?php endif; ?>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modals -->
<div id="sendModal" class="modal-overlay">
  <div class="modal-box" style="max-width: 500px;">
    <h3 class="modal-title">Send Quotation</h3>
    <p class="text-sm text-muted" style="margin-bottom: 20px;">Choose a method to send the quotation to the customer.</p>
    
    <?php
    $domain = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    $quoteLink = "http://$domain" . BASE_URL . "/sales/quotation_print.php?id=$id";
    
    // WhatsApp URL
    $waPhone = preg_replace('/[^0-9]/', '', $q['phone'] ?? '');
    $waText = urlencode("Thanks for contacting Nayendra Automation and Controls!\n\nWe are sharing our quotation ({$q['quotation_no']}) for your project.\nTotal Amount: ₹ " . number_format((float)$q['total'], 2) . "\n\nYou can view/print the PDF here:\n$quoteLink\n\nPlease review and let us know if you have any questions.");
    $waUrl = "https://wa.me/{$waPhone}?text={$waText}";

    // Email URL
    $emEmail = $q['email'] ?? '';
    $emSubject = urlencode("Quotation {$q['quotation_no']} - Nayendra Automation and Controls");
    $emBody = urlencode("Dear {$q['customer_name']},\n\nThank you for contacting Nayendra Automation and Controls.\nPlease find attached the quotation ({$q['quotation_no']}) for your project, or view it online here:\n$quoteLink\n\nTotal Amount: ₹ " . number_format((float)$q['total'], 2) . "\n\nLooking forward to your confirmation.\n\nRegards,\nNayendra Automation and Controls");
    $emUrl = "mailto:{$emEmail}?subject={$emSubject}&body={$emBody}";
    ?>

    <div style="display:flex; flex-direction:column; gap:12px; margin-bottom: 24px;">
      <a href="<?= $waUrl ?>" target="_blank" class="btn btn-success" style="display:flex; justify-content:center; align-items:center; font-size:16px;">
        <span style="font-size:20px; margin-right:8px;">💬</span> Send via WhatsApp
      </a>
      <a href="<?= $emUrl ?>" target="_blank" class="btn btn-primary" style="display:flex; justify-content:center; align-items:center; font-size:16px;">
        <span style="font-size:20px; margin-right:8px;">📧</span> Send via Email
      </a>
      <div class="text-sm text-muted text-center" style="margin-top:10px;">
        <em>Note: Opening the apps will not automatically attach the PDF file. You can attach it manually, or the customer can use the link provided in the message.</em>
      </div>
    </div>
    <form method="POST" enctype="multipart/form-data">
      <div class="form-group" style="margin-bottom: 24px;">
        <label style="font-weight:600; color:var(--text);">Attach Sent PDF for Records (Optional)</label>
        <input type="file" name="sent_pdf" accept="application/pdf" class="form-control">
        <div style="font-size:11px; color:var(--muted); margin-top:4px;">Upload the generated PDF here so the ERP keeps an exact copy of what you sent. Note: You must still manually drag and drop the PDF into your WhatsApp/Email window.</div>
      </div>
      
      <div style="border-top: 1px solid var(--border); padding-top: 16px;">
        <p class="text-sm" style="margin-bottom: 12px; font-weight:600;">Finished sharing?</p>
        <div style="display:flex; justify-content:flex-end; gap:10px;">
          <button type="button" class="btn btn-ghost" onclick="closeModal('sendModal')">Cancel</button>
          <button type="submit" name="send_quote" class="btn btn-primary">Mark as Sent</button>
        </div>
      </div>
    </form>
  </div>
</div>

<div id="approveModal" class="modal-overlay">
  <div class="modal-box">
    <h3 class="modal-title">Approve Quotation</h3>
    <p class="text-sm text-muted" style="margin-bottom:16px;">Marking this quotation as approved will lock it and allow Handover to Service.</p>
    <form method="POST" enctype="multipart/form-data">
      <div class="form-group" style="margin-bottom:14px;">
        <label>Upload Proof of Approval (PDF, Image, Audio)</label>
        <input type="file" name="proof_file" accept="image/*,application/pdf,audio/*" class="form-control">
      </div>
      <div class="form-group"><label>Approval Reference / Notes</label><textarea name="approval_proof" placeholder="E.g. Approved via WhatsApp on 25th Oct."></textarea></div>
      <div style="margin-top:20px; display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn btn-ghost" onclick="closeModal('approveModal')">Cancel</button>
        <button type="submit" name="approve_quote" class="btn btn-success">✅ Confirm Approval</button>
      </div>
    </form>
  </div>
</div>

<div id="reviseModal" class="modal-overlay">
  <div class="modal-box">
    <h3 class="modal-title">Create Revision</h3>
    <p class="text-sm text-muted" style="margin-bottom:14px;">This will clone the current quotation into a new Draft (V<?= $q['version']+1 ?>). The current one will be marked Superseded.</p>
    <form method="POST">
      <div class="form-group">
        <label>Reason for Revision</label>
        <textarea name="revision_reason" placeholder="e.g., Customer requested discount, added 2 extra cameras..."></textarea>
      </div>
      <div style="margin-top:20px; display:flex; justify-content:flex-end; gap:10px;">
        <button type="button" class="btn btn-ghost" onclick="closeModal('reviseModal')">Cancel</button>
        <button type="submit" name="create_revision" class="btn btn-warning">Create V<?= $q['version']+1 ?></button>
      </div>
    </form>
  </div>
</div>

<?php if(!$isReadonly): ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('commercialTermsForm');
    const status = document.getElementById('autoSaveStatus');
    
    // Initial state hash to avoid saving if nothing changed
    let initialData = new URLSearchParams(new FormData(form)).toString();

    setInterval(() => {
        const formData = new FormData(form);
        const currentData = new URLSearchParams(formData).toString();
        
        if (currentData !== initialData) {
            status.innerHTML = '<i>Autosaving...</i>';
            
            // Add required POST flags
            formData.append('update_settings', '1');
            formData.append('ajax', '1');
            
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            }).then(res => res.json()).then(data => {
                if(data.status === 'success') {
                    const now = new Date();
                    status.innerHTML = '<i>Draft saved at ' + now.toLocaleTimeString() + '</i>';
                    initialData = currentData;
                }
            }).catch(err => {
                status.innerHTML = '<i class="text-rose">Autosave failed</i>';
            });
        }
    }, 30000); // 30 seconds
});
</script>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
