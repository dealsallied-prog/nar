<?php
/**
 * Create first quotation for a Work Order
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SALES']);

$woId = (int)($_GET['wo_id'] ?? 0);
$wo = dbOne("SELECT work_order_no FROM work_orders WHERE id=?", [$woId]);
if (!$wo) die("WO not found");

// Check if any exists (Draft or otherwise)
$exists = dbOne("SELECT id, status FROM quotations WHERE work_order_id=? ORDER BY version DESC LIMIT 1", [$woId]);
if ($exists) {
    if ($exists['status'] === 'DRAFT') {
        setFlash('info', 'Resuming existing Draft quotation.');
    }
    redirect("quotation_edit.php?id=" . $exists['id']);
}

$qNo = "QT-{$woId}-V1";
dbExec("INSERT INTO quotations (work_order_id, version, quotation_no, status, created_by_id) VALUES (?, 1, ?, 'DRAFT', ?)",
    [$woId, $qNo, $user['id']]);

$qid = db()->lastInsertId();
setFlash('success', 'Quotation V1 Draft created.');
redirect("quotation_edit.php?id=$qid");
