<?php
/**
 * Pre-Sale Site Visits List
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SALES']);

$pageTitle = 'Pre-Sale Site Visits';

$sql = "SELECT v.*, w.work_order_no, w.status as wo_status, c.name as customer_name, c.address 
        FROM pre_sale_visits v 
        JOIN work_orders w ON v.work_order_id = w.id 
        JOIN customers c ON w.customer_id = c.id 
        WHERE v.visit_type = 'PRE_SALE' 
        ORDER BY v.scheduled_date DESC";
$visits = dbAll($sql);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Pre-Sale Site Visits</h1>
    <p>All scheduled and completed surveys.</p>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Date</th>
          <th>Work Order #</th>
          <th>Customer & Address</th>
          <th>Status</th>
          <th>Assigned To</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$visits): ?>
          <tr><td colspan="6" class="empty-state">No visits found.</td></tr>
        <?php else: foreach ($visits as $v): ?>
          <tr>
            <td><?= dtShort($v['scheduled_date']) ?></td>
            <td><a href="leads_view.php?id=<?= $v['work_order_id'] ?>" class="font-mono"><strong><?= e($v['work_order_no']) ?></strong></a></td>
            <td>
               <div style="font-weight:600"><?= e($v['customer_name']) ?></div>
               <div class="text-sm text-muted" style="max-width:200px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;"><?= e($v['address']) ?></div>
            </td>
            <td><span class="badge badge-<?= $v['status']=='COMPLETED'?'green':'blue' ?>"><?= e($v['status']) ?></span></td>
            <td><?= e(dbOne("SELECT name FROM users WHERE id=?",[$v['assigned_to_id']])['name'] ?? '—') ?></td>
            <td>
              <a href="leads_view.php?id=<?= $v['work_order_id'] ?>" class="btn btn-sm btn-ghost">View WO</a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
