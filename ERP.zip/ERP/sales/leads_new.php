<?php
/**
 * Create new lead -> generates Work Order
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SALES']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $custName = trim($_POST['customer_name'] ?? '');
    $companyName = trim($_POST['company_name'] ?? '');
    $gstNumber = trim($_POST['gst_number'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $address  = trim($_POST['address'] ?? '');
    $source   = trim($_POST['source'] ?? '');
    $budget   = (float)($_POST['expected_budget'] ?? 0);
    $req      = trim($_POST['requirement_description'] ?? '');

    if (!$custName) {
        setFlash('error', 'Customer name is required.');
    } else {
        try {
            $pdo = db();
            $pdo->beginTransaction();

            $pdo->prepare("INSERT INTO customers (name, company_name, gst_number, phone, email, address) VALUES (?,?,?,?,?,?)")
                ->execute([$custName, $companyName, $gstNumber, $phone, $email, $address]);
            $custId = $pdo->lastInsertId();

            $woNo = nextWorkOrderNo();

            $stmt = $pdo->prepare("INSERT INTO work_orders (work_order_no, customer_id, source, requirement_description, expected_budget, status, sales_owner_id, created_by_id) VALUES (?,?,?,?,?, 'LEAD_CREATED', ?,?)");
            $stmt->execute([$woNo, $custId, $source, $req, $budget, $user['id'], $user['id']]);
            $woId = $pdo->lastInsertId();

            addLog($woId, $user['id'], 'Lead Created', null, 'LEAD_CREATED', 'Generated WO No: ' . $woNo);

            $pdo->commit();
            setFlash('success', "Lead created successfully. Work Order: $woNo");
            redirect('leads_view.php?id=' . $woId);
        } catch (Exception $e) {
            if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
            setFlash('error', 'Database error: ' . $e->getMessage());
        }
    }
}

$pageTitle = 'New Lead';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Create New Lead</h1>
    <p>This will generate a new Work Order number.</p>
  </div>
  <div class="page-actions">
    <a href="leads.php" class="btn btn-ghost">← Back</a>
  </div>
</div>

<div class="card" style="max-width: 800px; margin: 0 auto;">
  <div class="card-header"><div class="card-title">Lead Information</div></div>
  <div class="card-body">
    <form method="POST">
      <div class="form-grid">
        <div class="form-group full">
          <label>Customer Name *</label>
          <input type="text" name="customer_name" required>
        </div>
        <div class="form-group full">
          <label>Company Name (for B2B)</label>
          <input type="text" name="company_name" id="company_name" oninput="toggleGST()">
        </div>
        <div class="form-group full">
          <label>GST Number</label>
          <input type="text" name="gst_number" id="gst_number" disabled>
        </div>
        <div class="form-group">
          <label>Phone Number</label>
          <input type="text" name="phone">
        </div>
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" name="email">
        </div>
        <div class="form-group full">
          <label>Site Address</label>
          <textarea name="address" rows="2"></textarea>
        </div>
        <div class="divider full"></div>
        <div class="form-group">
          <label>Source</label>
          <select name="source">
            <option value="">Select source...</option>
            <option value="Website">Website</option>
            <option value="Referral">Referral</option>
            <option value="Walk-in">Walk-in</option>
            <option value="Social Media">Social Media</option>
          </select>
        </div>
        <div class="form-group">
          <label>Expected Budget</label>
          <input type="number" name="expected_budget" step="0.01" min="0">
        </div>
        <div class="form-group full">
          <label>Requirement Description</label>
          <textarea name="requirement_description" rows="4" placeholder="Describe the customer's needs..."></textarea>
        </div>
        <div class="form-group full">
          <button type="submit" class="btn btn-primary" style="margin-top: 10px;">💾 Save & Generate Work Order</button>
        </div>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<script>
function toggleGST() {
    const companyInput = document.getElementById('company_name');
    const gstInput = document.getElementById('gst_number');
    if (companyInput.value.trim() !== '') {
        gstInput.disabled = false;
    } else {
        gstInput.disabled = true;
        gstInput.value = '';
    }
}
</script>
