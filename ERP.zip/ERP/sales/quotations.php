<?php
define('BASE_URL', '/ERP');
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';

$user = requireUser(['ADMIN','SALES']);
$pageTitle = 'Quotations';

$quotes = dbAll(
    "SELECT q.*, wo.work_order_no, c.name AS cust_name
     FROM quotations q
     LEFT JOIN work_orders wo ON wo.id=q.work_order_id
     LEFT JOIN customers c ON c.id=wo.customer_id
     ORDER BY q.created_at DESC"
);

include __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Quotations</h1>
    <p>All quotations created for work orders.</p>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Quotation No</th>
          <th>Work Order</th>
          <th>Customer</th>
          <th>Version</th>
          <th>Total</th>
          <th>Status</th>
          <th>Created</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($quotes)): ?>
          <tr><td colspan="8" class="empty-state">No quotations yet. Create one from a lead.</td></tr>
        <?php else: ?>
          <?php foreach ($quotes as $q): ?>
            <tr>
              <td><?= e($q['quotation_no']) ?></td>
              <td><a href="<?= BASE_URL ?>/sales/leads_view.php?id=<?= $q['work_order_id'] ?>"><?= e($q['work_order_no']) ?></a></td>
              <td><?= e($q['cust_name']) ?></td>
              <td>v<?= $q['version'] ?></td>
              <td><?= money($q['total']) ?></td>
              <td><span class="<?= badgeClass($q['status']) ?>"><?= quotationStatusLabel($q['status']) ?></span></td>
              <td class="text-muted text-sm"><?= dtShort($q['created_at']) ?></td>
              <td><a href="<?= BASE_URL ?>/sales/quotation_edit.php?id=<?= $q['id'] ?>" class="btn btn-ghost btn-xs">Edit/View</a></td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
