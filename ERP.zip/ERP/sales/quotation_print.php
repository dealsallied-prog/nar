<?php
/**
 * Print / PDF View for Quotation
 * Formatted for standard A4 printing.
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SALES', 'ADMIN', 'SERVICE_CONTROLLER']);

$id = (int)($_GET['id'] ?? 0);
$q = dbOne("SELECT q.*, w.work_order_no, w.customer_id, w.requirement_description, c.name AS customer_name, c.phone, c.address, c.email 
            FROM quotations q 
            JOIN work_orders w ON q.work_order_id=w.id 
            JOIN customers c ON w.customer_id=c.id 
            WHERE q.id=?", [$id]);
if (!$q) die("Quotation not found.");

$items = dbAll("SELECT qi.*, p.sku FROM quotation_items qi LEFT JOIN parts p ON qi.part_id = p.id WHERE qi.quotation_id=? ORDER BY qi.id ASC", [$id]);

// Group items by type for sections
$groupedItems = [];
foreach ($items as $it) {
    $cat = $it['item_type'] === 'PARTS' ? 'MATERIALS / SYSTEMS' : ($it['item_type'] === 'LABOUR' ? 'INSTALLATION & LABOUR' : 'OTHER CHARGES');
    $groupedItems[$cat][] = $it;
}

// Format numbers
function fmtAmt($num) {
    return number_format((float)$num, 2, '.', ',');
}

// Convert number to words (simple Indian numbering system for rupees)
function numberToWords($number) {
    $no = floor($number);
    $point = round($number - $no, 2) * 100;
    $hundred = null;
    $digits_1 = strlen($no);
    $i = 0;
    $str = array();
    $words = array('0' => '', '1' => 'One', '2' => 'Two',
    '3' => 'Three', '4' => 'Four', '5' => 'Five', '6' => 'Six',
    '7' => 'Seven', '8' => 'Eight', '9' => 'Nine',
    '10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve',
    '13' => 'Thirteen', '14' => 'Fourteen',
    '15' => 'Fifteen', '16' => 'Sixteen', '17' => 'Seventeen',
    '18' => 'Eighteen', '19' =>'Nineteen', '20' => 'Twenty',
    '30' => 'Thirty', '40' => 'Forty', '50' => 'Fifty',
    '60' => 'Sixty', '70' => 'Seventy',
    '80' => 'Eighty', '90' => 'Ninety');
    $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
    while ($i < $digits_1) {
        $divider = ($i == 2) ? 10 : 100;
        $number = floor($no % $divider);
        $no = floor($no / $divider);
        $i += ($divider == 10) ? 1 : 2;
        if ($number) {
            $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
            $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
            $str [] = ($number < 21) ? $words[$number] . " " . $digits[$counter] . $plural . " " . $hundred
                : $words[floor($number / 10) * 10] . " " . $words[$number % 10] . " " . $digits[$counter] . $plural . " " . $hundred;
        } else $str[] = null;
    }
    $str = array_reverse($str);
    $result = implode('', $str);
    $points = ($point) ? " and " . ($words[floor($point / 10) * 10] ?? '') . " " . ($words[floor($point % 10)] ?? '') . " Paise" : "";
    return $result ? "Rupees " . $result . "Only" : "";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= e($q['quotation_no']) ?> - <?= e($q['customer_name']) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root {
    --text: #1e293b;
    --muted: #475569;
    --border: #e2e8f0;
    --primary: #c29b27; /* Golden/Bronze from reference */
  }
  body {
    font-family: 'Inter', sans-serif;
    color: var(--text);
    margin: 0;
    padding: 0;
    background: #52525b; /* Dark bg outside A4 */
    font-size: 10px;
    line-height: 1.5;
  }
  .a4-page {
    width: 210mm;
    min-height: 297mm;
    background: #ffffff;
    margin: 20mm auto;
    padding: 15mm;
    box-sizing: border-box;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  }
  .header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    border-bottom: 2px solid var(--primary);
    padding-bottom: 15px;
    margin-bottom: 20px;
  }
  .company-info h1 {
    margin: 0 0 5px 0;
    font-size: 20px;
    color: #1e293b;
    font-weight: 700;
  }
  .company-info p {
    margin: 0;
    font-size: 10px;
    color: var(--muted);
  }
  .doc-title h2 {
    margin: 0;
    font-size: 28px;
    color: var(--primary);
    text-align: right;
    font-weight: 700;
    letter-spacing: 1px;
  }
  .doc-title p {
    margin: 4px 0 0 0;
    text-align: right;
    font-weight: 600;
    font-size: 11px;
    color: var(--muted);
  }

  .meta-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 15px;
    margin-bottom: 25px;
  }
  .meta-box {
    display: grid;
    grid-template-columns: 100px 1fr;
    row-gap: 8px;
  }
  .meta-label {
    font-weight: 600;
    color: var(--muted);
    text-transform: uppercase;
    font-size: 9px;
  }
  .meta-value {
    font-weight: 500;
    color: var(--text);
  }

  .items-table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 25px;
  }
  .items-table th {
    text-align: left;
    padding: 8px 5px;
    font-size: 9px;
    text-transform: uppercase;
    color: var(--primary);
    font-weight: 600;
    border-bottom: 1px solid var(--border);
  }
  .items-table td {
    padding: 8px 5px;
    border-bottom: 1px solid var(--border);
    vertical-align: top;
  }
  .cat-row td {
    background: #f8fafc;
    font-weight: 700;
    color: #0f172a;
    font-size: 10px;
    padding: 10px 5px;
  }
  
  .totals-section {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 30px;
  }
  .amt-words {
    width: 60%;
  }
  .amt-words p { margin: 0; }
  .totals-box {
    width: 35%;
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 15px;
  }
  .tot-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 8px;
    font-size: 10px;
    color: var(--text);
  }
  .tot-row.grand {
    margin-top: 10px;
    padding-top: 10px;
    border-top: 1px solid var(--border);
    font-size: 14px;
    font-weight: 700;
  }

  .terms {
    margin-bottom: 25px;
  }
  .terms h3 {
    font-size: 11px;
    margin: 0 0 10px 0;
    font-weight: 700;
  }
  .terms p, .terms ol {
    margin: 0;
    padding-left: 15px;
    color: var(--muted);
  }
  .terms li {
    margin-bottom: 4px;
  }
  .terms strong { color: var(--text); }

  .bank-box {
    border: 1px solid var(--border);
    border-radius: 6px;
    padding: 15px;
    display: flex;
    justify-content: space-between;
  }
  .bank-details {
    line-height: 1.6;
    color: var(--text);
  }
  .bank-details span { color: var(--muted); width: 130px; display: inline-block; }
  
  /* Print Media */
  @media print {
    body { background: #fff; }
    .a4-page { margin: 0; padding: 0; box-shadow: none; border: none; }
    .no-print { display: none; }
  }
</style>
</head>
<body>

<div class="no-print" style="text-align:center; padding: 20px; background:#1e293b; color:#fff;">
  <button onclick="window.print()" style="padding:10px 20px; background:#0ea5e9; color:#fff; border:none; border-radius:6px; cursor:pointer; font-size:14px; font-weight:600;">🖨️ Print to PDF</button>
  <p style="margin-top:10px; font-size:12px; color:#94a3b8;">Set margins to "None" and ensure Background Graphics are enabled in print settings.</p>
</div>

<div class="a4-page">
  <div class="header">
    <div class="company-info">
      <h1>Nayendra Automation and Controls</h1>
      <p>www.nayendra.com &nbsp;|&nbsp; Mob: 98950 44433 &nbsp;|&nbsp; Land Line: (0471) 4010040</p>
      <p style="margin-top:4px;">CIN: U51909KL2009PTC023906<br>MOB: 9995737103 &nbsp;|&nbsp; PAN: AACCN9668C<br>GST: 32AACCN9668C1ZG &nbsp;|&nbsp; MSME: UDYAM-KL-12-0049060</p>
    </div>
    <div class="doc-title">
      <h2>PROPOSAL</h2>
      <p>WO: <?= e($q['work_order_no']) ?></p>
      <p>QUOTATION</p>
    </div>
  </div>

  <div class="meta-grid">
    <div class="meta-box">
      <div class="meta-label">Project</div><div class="meta-value"><?= e($q['customer_name']) ?></div>
      <div class="meta-label">Mobile</div><div class="meta-value"><?= e($q['phone']) ?></div>
      <div class="meta-label">Billing Add</div><div class="meta-value"><?= e($q['address']) ?></div>
      <div class="meta-label">Site Add</div><div class="meta-value"><?= e($q['address']) ?></div>
    </div>
    <div class="meta-box">
      <div class="meta-label">Prop. Ref</div><div class="meta-value"><?= e($q['quotation_no']) ?></div>
      <div class="meta-label">Date</div><div class="meta-value"><?= dtShort($q['created_at']) ?></div>
      <div class="meta-label">Valid Until</div><div class="meta-value"><?= dtShort(date('Y-m-d', strtotime($q['created_at'] . ' + ' . $q['validity_days'] . ' days'))) ?></div>
      <div class="meta-label">GST No</div><div class="meta-value">—</div>
    </div>
  </div>

  <table class="items-table">
    <thead>
      <tr>
        <th width="30">#</th>
        <th width="120">Item Code</th>
        <th>Item Description</th>
        <th width="80" style="text-align:right;">Price</th>
        <th width="50" style="text-align:center;">Qty</th>
        <th width="90" style="text-align:right;">Amount</th>
      </tr>
    </thead>
    <tbody>
      <?php 
      $idx = 1;
      foreach ($groupedItems as $catName => $catItems): 
      ?>
      <tr class="cat-row">
        <td colspan="6"><?= e($catName) ?></td>
      </tr>
        <?php foreach ($catItems as $it): ?>
        <tr>
          <td><?= str_pad($idx++, 2, '0', STR_PAD_LEFT) ?></td>
          <td><?= e($it['sku'] ?: '—') ?></td>
          <td><?= e($it['description']) ?></td>
          <td style="text-align:right;"><?= fmtAmt($it['unit_price']) ?></td>
          <td style="text-align:center;"><?= qty($it['quantity']) ?></td>
          <td style="text-align:right; font-weight:600;"><?= fmtAmt($it['total']) ?></td>
        </tr>
        <?php endforeach; ?>
      <?php endforeach; ?>
    </tbody>
  </table>

  <div class="totals-section">
    <div class="amt-words">
      <p style="font-weight:600; margin-bottom:5px;">Amount in words:</p>
      <p><?= numberToWords($q['total']) ?></p>
    </div>
    <div class="totals-box">
      <div class="tot-row">
        <span>Materials Subtotal</span>
        <span><?= fmtAmt($q['subtotal']) ?></span>
      </div>
      <?php if ($q['discount'] > 0): ?>
      <div class="tot-row">
        <span>Discount</span>
        <span>- <?= fmtAmt($q['discount']) ?></span>
      </div>
      <?php endif; ?>
      <div class="tot-row">
        <span>GST @ <?= (float)$q['tax_percent'] ?>%</span>
        <span><?= fmtAmt($q['tax_amount']) ?></span>
      </div>
      <div class="tot-row grand">
        <span>GRAND TOTAL</span>
        <span><?= fmtAmt($q['total']) ?></span>
      </div>
    </div>
  </div>

  <div class="terms">
    <h3>GENERAL TERMS</h3>
    <ol>
      <li><strong>PRICING:</strong> The above prices are in Indian Rupees and inclusive of all taxes, delivery & installation.</li>
      <li><strong>DELIVERY:</strong> Delivery and installation within 1 week after the receipt of a written order confirmation & advance payment.</li>
      <li><strong>PAYMENT TERMS:</strong> 60% in advance, 30% against material delivery and balance on completion of the job.</li>
      <li><strong>PRICE PROTECTION:</strong> Under the above terms, once the advance payment is made, the proposal value quoted will be protected.</li>
      <li><strong>POWER SUPPLY:</strong> 230VAC stable power with proper grounding has to be provided at site by the client.</li>
      <li><strong>EXCLUSIONS TO THIS OFFER:</strong>
        <br># GATE FABRICATION AND PAINTING OF FIXTURES IS NOT COVERED
        <br># POWER AND DATA CABLING IS NOT INCLUDED
      </li>
      <li><strong>ADDITIONAL JOB:</strong> Any additional work beyond the scope of the proposal shall be billed extra based on confirmation.</li>
      <li><strong>WARRANTY:</strong> 2 year for system against all manufacturing defects excluding damages due to natural calamities or physical damages.</li>
      <li><strong>VALIDITY OF THE OFFER:</strong> Validity of this offer is <?= (int)$q['validity_days'] ?> days from the offer date.</li>
      <li><strong>PAYMENTS:</strong> All payments to be made in favor of "NAYENDRA AUTOMATION AND CONTROLS INDIA (P) LTD".</li>
    </ol>
  </div>

  <div class="bank-box">
    <div class="bank-details">
      <span>BANK:</span> <strong>STATE BANK OF INDIA (SBI)</strong><br>
      <span>BRANCH:</span> KUMARAPURAM, THIRUVANANTHAPURAM<br>
      <span>ACCOUNT NAME:</span> NAYENDRA AUTOMATION AND CONTROLS INDIA PRIVATE LTD<br>
      <span>ACCOUNT NUMBER:</span> 67288918366<br>
      <span>ACCOUNT TYPE:</span> CURRENT ACCOUNT<br>
      <span>IFSC CODE:</span> SBIN0018145<br>
      <span style="color:#ef4444; font-weight:600;">UPI CODE:</span> <strong style="color:#ef4444;">67288918366@SBI</strong>
    </div>
    <div class="qr-code">
      <!-- Placeholder QR Code for display purposes based on reference -->
      <img src="https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=upi://pay?pa=67288918366@sbi&pn=Nayendra&cu=INR" alt="UPI QR" width="90" height="90">
    </div>
  </div>

  <div style="margin-top:30px; display:flex; justify-content:space-between; border-top:1px solid var(--border); padding-top:15px; margin-bottom:40px;">
    <span style="font-weight:600;">Client Acceptance</span>
    <span style="font-weight:600;">For Nayendra Automation and Controls</span>
  </div>

  <!-- Partner Logos Footer -->
  <div class="brand-logos" style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #e2e8f0; padding-top:20px; flex-wrap:wrap; gap:10px;">
    
    <!-- BRANE -->
    <div style="display:flex; align-items:center; gap:5px;">
      <div style="width:24px; height:24px; border-radius:50%; border:2px solid #0284c7; display:flex; justify-content:center; align-items:center;">
        <div style="width:14px; height:14px; border-radius:50%; border:2px solid #0284c7;"></div>
      </div>
      <div>
        <div style="font-size:16px; font-weight:800; color:#0284c7; letter-spacing:1px; line-height:1;">BRANE</div>
        <div style="font-size:6px; color:#0284c7;">Experience Effortless Control</div>
      </div>
    </div>

    <!-- Smart Node -->
    <div style="display:flex; align-items:center; gap:5px;">
      <div style="color:#10b981; font-size:20px;">✿</div>
      <div>
        <div style="font-size:14px; font-weight:700; color:#1e293b; line-height:1;">Smart Node</div>
        <div style="font-size:6px; color:#64748b;">Discover the Joy of Smart Living</div>
      </div>
    </div>

    <!-- AUTOZON -->
    <div style="text-align:center;">
      <div style="font-size:14px; font-weight:800; color:#0369a1; letter-spacing:0.5px; line-height:1;">AUTOZON<sup style="font-size:6px;">®</sup></div>
      <div style="font-size:6px; color:#0369a1; letter-spacing:0.5px;">ENTRANCE AUTOMATION</div>
    </div>

    <!-- onetouch -->
    <div style="display:flex; align-items:center; gap:5px;">
      <div>
        <div style="font-size:16px; font-weight:400; color:#ea580c; line-height:1; letter-spacing:-0.5px;">onetouch</div>
        <div style="font-size:6px; color:#1e293b;">communication &amp; security</div>
      </div>
      <div style="color:#ea580c; font-size:16px;">☁</div>
    </div>

    <!-- HIKVISION -->
    <div style="font-size:18px; font-weight:800; color:#dc2626; letter-spacing:1px; font-style:italic;">
      HIKVISION<sup style="font-size:8px; color:#94a3b8; font-style:normal;">®</sup>
    </div>

    <!-- Texecom -->
    <div style="font-size:15px; font-weight:800; color:#000; letter-spacing:-0.5px;">
      Texecom
    </div>

  </div>
</div>

</body>
</html>
