<?php
/**
 * Revision Requests Queue (Sales)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SALES']);

$pageTitle = 'Revision Requests';

// WOs where status is REVISION_IN_PROGRESS
$sql = "SELECT w.*, c.name AS customer_name 
        FROM work_orders w JOIN customers c ON w.customer_id = c.id 
        WHERE w.status = 'REVISION_IN_PROGRESS' 
        ORDER BY w.updated_at DESC";
$reqs = dbAll($sql);

require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>Revision Requests</h1>
    <p>Work orders returned by Service requiring quote updates.</p>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Work Order #</th>
          <th>Customer</th>
          <th>Requested On</th>
          <th>Service Controller Notes</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$reqs): ?>
          <tr><td colspan="5" class="empty-state">No pending revision requests.</td></tr>
        <?php else: foreach ($reqs as $r): ?>
          <tr>
            <td class="font-mono"><strong><?= e($r['work_order_no']) ?></strong></td>
            <td style="font-weight:600"><?= e($r['customer_name']) ?></td>
            <td><?= dtShort($r['updated_at']) ?></td>
            <td><div style="max-height:40px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:300px;"><?= e($r['revision_change_list'] ?: '—') ?></div></td>
            <td>
              <a href="leads_view.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-outline-sky">Review & Revise</a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
