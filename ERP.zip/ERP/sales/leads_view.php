<?php
/**
 * View Lead & Work Order (Sales)
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['SALES']);

$id = (int)($_GET['id'] ?? 0);
$wo = dbOne("SELECT w.*, c.name AS customer_name, c.company_name, c.gst_number, c.phone, c.email, c.address 
             FROM work_orders w JOIN customers c ON w.customer_id = c.id 
             WHERE w.id=?", [$id]);
if (!$wo) die("Work order not found.");

// Schedule pre-sale visit
if (isset($_POST['schedule_visit'])) {
    $date = trim($_POST['visit_date']);
    $notes = trim($_POST['visit_notes']);
    $assigneeId = (int)($_POST['assigned_to'] ?? $user['id']);
    
    dbExec("INSERT INTO pre_sale_visits (work_order_id, assigned_to_id, scheduled_date, notes, created_by_id) VALUES (?,?,?,?,?)",
        [$id, $assigneeId, $date ?: null, $notes, $user['id']]);
    
    dbExec("UPDATE work_orders SET status='PRE_SALE_VISIT_SCHEDULED' WHERE id=?", [$id]);
    addLog($id, $user['id'], 'Scheduled Pre-Sale Visit', $wo['status'], 'PRE_SALE_VISIT_SCHEDULED', "Date: $date. Notes: $notes");
    setFlash('success', 'Pre-sale visit scheduled.');
    redirect("leads_view.php?id=$id");
}

// Complete pre-sale visit
if (isset($_POST['complete_visit'])) {
    $vid = (int)$_POST['visit_id'];
    $meas = trim($_POST['measurements']);
    
    $photos = [];
    $uploadDir = __DIR__ . '/../uploads/visits/';
    if (!empty($_FILES['media']['name'][0])) {
        foreach ($_FILES['media']['name'] as $i => $name) {
            if ($_FILES['media']['error'][$i] === UPLOAD_ERR_OK) {
                $tmpName = $_FILES['media']['tmp_name'][$i];
                $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                $newName = uniqid('vis_') . '.' . $ext;
                if (move_uploaded_file($tmpName, $uploadDir . $newName)) {
                    $photos[] = [
                        'file' => $newName,
                        'caption' => trim($_POST['captions'][$i] ?? ''),
                        'type' => (strpos($_FILES['media']['type'][$i], 'video') !== false || in_array($ext, ['mp4','webm','mov'])) ? 'video' : 'image'
                    ];
                }
            }
        }
    }
    
    $photosJson = !empty($photos) ? json_encode($photos) : null;
    
    dbExec("UPDATE pre_sale_visits SET status='COMPLETED', measurements=?, photos=?, completed_at=NOW() WHERE id=?", [$meas, $photosJson, $vid]);
    dbExec("UPDATE work_orders SET status='PRE_SALE_VISIT_DONE' WHERE id=?", [$id]);
    addLog($id, $user['id'], 'Completed Pre-Sale Visit', $wo['status'], 'PRE_SALE_VISIT_DONE');
    setFlash('success', 'Visit marked as completed with media.');
    redirect("leads_view.php?id=$id");
}

// Handover to Service
if (isset($_POST['handover'])) {
    $note = trim($_POST['handover_note']);
    dbExec("UPDATE work_orders SET status='HANDED_TO_SERVICE', handover_note=? WHERE id=?", [$note, $id]);
    addLog($id, $user['id'], 'Handed Over to Service', $wo['status'], 'HANDED_TO_SERVICE', $note);
    notify("New Work Order {$wo['work_order_no']} ready for acceptance.", null, 'SERVICE_CONTROLLER', $id);
    setFlash('success', 'Handed over to Service successfully.');
    redirect("leads_view.php?id=$id");
}

$visits = dbAll("SELECT v.*, u.name as assigned_name FROM pre_sale_visits v LEFT JOIN users u ON v.assigned_to_id=u.id WHERE v.work_order_id=? ORDER BY v.id DESC", [$id]);
$quotes = dbAll("SELECT q.*, u.name as created_by FROM quotations q LEFT JOIN users u ON q.created_by_id=u.id WHERE q.work_order_id=? ORDER BY q.version DESC", [$id]);
$logs   = dbAll("SELECT l.*, u.name as actor FROM work_order_logs l LEFT JOIN users u ON l.actor_id=u.id WHERE l.work_order_id=? ORDER BY l.id DESC", [$id]);

$assignableUsers = dbAll("SELECT id, name, role FROM users WHERE active=1 ORDER BY role, name");

$hasApprovedQuote = count(array_filter($quotes, fn($q) => $q['status'] === 'APPROVED')) > 0;
$canHandover = $hasApprovedQuote && !in_array($wo['status'], ['HANDED_TO_SERVICE', 'SERVICE_ACCEPTED', 'TECH_VISIT_SCHEDULED', 'TECH_VISIT_DONE', 'FINAL_QUOTE_APPROVED', 'CLOSED']);

$pageTitle = $wo['work_order_no'];
require_once __DIR__ . '/../includes/header.php';
?>
<div class="page-header">
  <div>
    <h1><?= e($wo['work_order_no']) ?></h1>
    <p><?= e($wo['customer_name']) ?> — <?= e($wo['requirement_description']) ?></p>
  </div>
  <div class="page-actions">
    <?php if ($canHandover): ?>
       <button class="btn btn-primary" onclick="openModal('handoverModal')">Handover to Service</button>
    <?php endif; ?>
    <?php if (!in_array($wo['status'], ['CLOSED'])): ?>
       <button class="btn btn-outline-sky" onclick="openModal('visitModal')">📅 Schedule Visit</button>
       <a href="quotations_new.php?wo_id=<?= $id ?>" class="btn btn-primary">📝 Create Quotation</a>
    <?php endif; ?>
  </div>
</div>

<div class="section status-timeline card">
  <div class="card-body" style="padding: 14px 20px;">
    <div class="status-timeline">
      <?php foreach (MASTER_STATUS_ORDER as $st): 
          $isActive = ($wo['status'] === $st);
          $isDone = array_search($wo['status'], MASTER_STATUS_ORDER) > array_search($st, MASTER_STATUS_ORDER);
          $cls = $isActive ? 'active' : ($isDone ? 'done' : '');
      ?>
      <div class="timeline-step">
        <div class="timeline-dot <?= $cls ?>"><?= $isDone ? '✓' : '' ?></div>
        <div class="timeline-label <?= $cls ?>"><?= e(woStatusLabel($st)) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="tabs">
  <button class="tab-btn active" data-tab-group="wo" data-tab="info" onclick="switchTab('info','wo')">Info & Visits</button>
  <button class="tab-btn" data-tab-group="wo" data-tab="quotes" onclick="switchTab('quotes','wo')">Quotations (<?= count($quotes) ?>)</button>
  <button class="tab-btn" data-tab-group="wo" data-tab="logs" onclick="switchTab('logs','wo')">Audit Log</button>
</div>

<!-- INFO TAB -->
<div class="tab-panel active" data-tab-panel-group="wo" data-panel="info">
  <div class="detail-grid">
    <div class="card">
      <div class="card-header"><div class="card-title">Customer Details</div></div>
      <div class="card-body space-y">
        <div class="detail-row"><div class="detail-label">Name</div><div class="detail-value"><?= e($wo['customer_name']) ?></div></div>
        <?php if(!empty($wo['company_name'])): ?>
        <div class="detail-row"><div class="detail-label">Company</div><div class="detail-value"><?= e($wo['company_name']) ?></div></div>
        <?php if(!empty($wo['gst_number'])): ?>
        <div class="detail-row"><div class="detail-label">GST No.</div><div class="detail-value"><?= e($wo['gst_number']) ?></div></div>
        <?php endif; ?>
        <?php endif; ?>
        <div class="detail-row"><div class="detail-label">Phone</div><div class="detail-value"><?= e($wo['phone'] ?: '—') ?></div></div>
        <div class="detail-row"><div class="detail-label">Email</div><div class="detail-value"><?= e($wo['email'] ?: '—') ?></div></div>
        <div class="detail-row"><div class="detail-label">Address</div><div class="detail-value"><?= nl2br(e($wo['address'])) ?></div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-header"><div class="card-title">Lead Information</div></div>
      <div class="card-body space-y">
        <div class="detail-row"><div class="detail-label">Current Status</div><div class="detail-value"><span class="<?= badgeClass($wo['status']) ?>"><?= e(woStatusLabel($wo['status'])) ?></span></div></div>
        <div class="detail-row"><div class="detail-label">Source</div><div class="detail-value"><?= e($wo['source'] ?: '—') ?></div></div>
        <div class="detail-row"><div class="detail-label">Budget</div><div class="detail-value"><?= $wo['expected_budget'] > 0 ? money($wo['expected_budget']) : '—' ?></div></div>
        <div class="detail-row"><div class="detail-label">Requirement</div><div class="detail-value"><?= nl2br(e($wo['requirement_description'])) ?></div></div>
      </div>
    </div>
  </div>

  <div class="card" style="margin-top: 20px;">
    <div class="card-header"><div class="card-title">Pre-Sale Site Visits</div></div>
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>Date</th><th>Assigned To</th><th>Status & Actions</th><th>Instructions, Findings & Media</th></tr>
        </thead>
        <tbody>
          <?php if(!$visits): ?>
            <tr><td colspan="4" class="empty-state">No visits scheduled.</td></tr>
          <?php else: foreach($visits as $v): ?>
            <tr>
              <td><?= dtShort($v['scheduled_date']) ?></td>
              <td><?= e($v['assigned_name']) ?></td>
              <td>
                <span class="badge badge-<?= $v['status']=='COMPLETED'?'green':'blue' ?>"><?= e($v['status']) ?></span>
                <?php if($v['status']==='SCHEDULED'): ?>
                  <div style="margin-top: 8px;">
                    <button class="btn btn-xs btn-success" onclick="document.getElementById('c_vid').value='<?= $v['id'] ?>'; openModal('completeVisitModal')">Mark Done</button>
                  </div>
                <?php endif; ?>
              </td>
              <td>
                <?php if($v['notes']): ?>
                  <div style="font-size: 12px; color: var(--slate5); margin-bottom: 8px; border-left: 2px solid var(--sky); padding-left: 8px;"><strong>Instructions:</strong> <?= e($v['notes']) ?></div>
                <?php endif; ?>
                
                <?php if($v['measurements']): ?>
                  <div style="margin-bottom:12px; line-height:1.5; color:var(--text);"><?= nl2br(e($v['measurements'])) ?></div>
                <?php elseif($v['status']==='COMPLETED'): ?>
                  <div style="margin-bottom:12px; color:var(--muted);">No findings recorded.</div>
                <?php else: ?>
                  <div style="margin-bottom:12px; color:var(--muted);">—</div>
                <?php endif; ?>
                
                <?php if(!empty($v['photos'])): $media = json_decode($v['photos'], true) ?: []; ?>
                  <div style="display:flex; flex-wrap:wrap; gap:8px; border-top: 1px dashed var(--border); padding-top: 12px;">
                    <?php foreach($media as $m): $url = BASE_URL . '/uploads/visits/' . $m['file']; ?>
                      <a href="<?= $url ?>" target="_blank" style="display:inline-flex; align-items:center; gap:6px; padding:4px 12px; background:#f1f5f9; border:1px solid #cbd5e1; border-radius:20px; text-decoration:none; color:#334155; font-size:12px; font-weight:500; transition: background 0.2s;">
                        <span style="font-size:14px;"><?= $m['type'] === 'video' ? '🎥' : '🖼️' ?></span>
                        <span style="max-width:120px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="<?= e($m['caption']) ?>"><?= e($m['caption'] ?: 'Media') ?></span>
                      </a>
                    <?php endforeach; ?>
                  </div>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- QUOTES TAB -->
<div class="tab-panel" data-tab-panel-group="wo" data-panel="quotes">
  <div class="card">
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>Version</th><th>Date</th><th>Total Amount</th><th>Status</th><th>Reason/Notes</th><th>Created By</th><th>Action</th></tr>
        </thead>
        <tbody>
          <?php if(!$quotes): ?>
            <tr><td colspan="7" class="empty-state">No quotations created yet.</td></tr>
          <?php else: foreach($quotes as $q): ?>
            <tr>
              <td><span class="tag bg-slate2">V<?= $q['version'] ?></span></td>
              <td><?= dtShort($q['created_at']) ?></td>
              <td style="font-weight:600"><?= money($q['total']) ?></td>
              <td><span class="<?= badgeClass($q['status']) ?>"><?= e(quotationStatusLabel($q['status'])) ?></span></td>
              <td><?= e($q['revision_reason'] ?: $q['notes'] ?: '—') ?></td>
              <td><?= e($q['created_by']) ?></td>
              <td>
                <a href="quotation_edit.php?id=<?= $q['id'] ?>" class="btn btn-xs btn-outline-sky">View / Edit</a>
              </td>
            </tr>
          <?php endforeach; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- LOGS TAB -->
<div class="tab-panel" data-tab-panel-group="wo" data-panel="logs">
  <div class="card">
    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr><th>Time</th><th>User</th><th>Action</th><th>Status Change</th><th>Remarks</th></tr>
        </thead>
        <tbody>
          <?php if(!$logs): ?><tr><td colspan="5" class="empty-state">No logs.</td></tr><?php endif; ?>
          <?php foreach($logs as $l): ?>
          <tr>
            <td><?= dt($l['created_at']) ?></td>
            <td><?= e($l['actor']) ?></td>
            <td><strong><?= e($l['action']) ?></strong></td>
            <td>
              <?php if($l['from_status'] && $l['from_status'] !== $l['to_status']): ?>
                <span class="text-muted"><?= e(woStatusLabel($l['from_status'])) ?></span> → 
              <?php endif; ?>
              <?php if($l['to_status']): ?>
                <span class="text-sm font-semibold"><?= e(woStatusLabel($l['to_status'])) ?></span>
              <?php endif; ?>
            </td>
            <td><?= e($l['remarks']?:'—') ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- MODALS -->
<div id="visitModal" class="modal-overlay">
  <div class="modal-box">
    <h3 class="modal-title">Schedule Pre-Sale Visit</h3>
    <form method="POST">
      <div class="form-group">
        <label>Assign To</label>
        <select name="assigned_to" required>
          <?php foreach ($assignableUsers as $u): ?>
            <option value="<?= $u['id'] ?>" <?= $u['id'] == $user['id'] ? 'selected' : '' ?>>
              <?= e($u['name']) ?> (<?= roleLabel($u['role']) ?>)
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group" style="margin-top:14px;"><label>Date & Time</label><input type="datetime-local" name="visit_date"></div>
      <div class="form-group" style="margin-top:14px;"><label>Notes for Surveyor</label><textarea name="visit_notes"></textarea></div>
      <div style="margin-top:20px; display:flex; gap:10px; justify-content:flex-end;">
        <button type="button" class="btn btn-ghost" onclick="closeModal('visitModal')">Cancel</button>
        <button type="submit" name="schedule_visit" class="btn btn-primary">Schedule</button>
      </div>
    </form>
  </div>
</div>

<div id="completeVisitModal" class="modal-overlay">
  <div class="modal-box" style="max-width: 500px;">
    <h3 class="modal-title">Complete Visit</h3>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="visit_id" id="c_vid">
      <div class="form-group"><label>Findings & Measurements</label><textarea name="measurements" rows="3" required placeholder="Describe site conditions, measurements..."></textarea></div>
      
      <div class="form-group" style="margin-top:14px;">
        <label>Attach Photos & Videos</label>
        <div id="mediaList" style="display:flex; flex-direction:column; gap:8px;">
          <div style="display:flex; gap:8px; align-items:center; background:#f8fafc; padding:8px; border-radius:4px; border:1px solid #e2e8f0;">
            <input type="file" name="media[]" accept="image/*,video/*" style="flex:1; width:100px;">
            <input type="text" name="captions[]" placeholder="Caption (e.g. Living Rm)" style="flex:1;" class="form-control">
          </div>
        </div>
        <button type="button" class="btn btn-xs btn-outline-sky" style="margin-top:8px;" onclick="addMediaRow()">+ Add Another File</button>
      </div>

      <div style="margin-top:20px; display:flex; gap:10px; justify-content:flex-end;">
        <button type="button" class="btn btn-ghost" onclick="closeModal('completeVisitModal')">Cancel</button>
        <button type="submit" name="complete_visit" class="btn btn-success">Mark Completed</button>
      </div>
    </form>
  </div>
</div>
<script>
function addMediaRow() {
    const list = document.getElementById('mediaList');
    const div = document.createElement('div');
    div.style.cssText = 'display:flex; gap:8px; align-items:center; background:#f8fafc; padding:8px; border-radius:4px; border:1px solid #e2e8f0;';
    div.innerHTML = `
        <input type="file" name="media[]" accept="image/*,video/*" style="flex:1; width:100px;">
        <input type="text" name="captions[]" placeholder="Caption" style="flex:1;" class="form-control">
        <button type="button" class="btn btn-xs btn-danger" onclick="this.parentElement.remove()">×</button>
    `;
    list.appendChild(div);
}
</script>

<div id="handoverModal" class="modal-overlay">
  <div class="modal-box">
    <h3 class="modal-title">Handover to Service</h3>
    <p class="text-sm text-muted" style="margin-bottom:16px;">This will transfer the Work Order to the Service department queue.</p>
    <form method="POST">
      <div class="form-group"><label>Handover Notes / Instructions (Optional)</label><textarea name="handover_note"></textarea></div>
      <div style="margin-top:20px; display:flex; gap:10px; justify-content:flex-end;">
        <button type="button" class="btn btn-ghost" onclick="closeModal('handoverModal')">Cancel</button>
        <button type="submit" name="handover" class="btn btn-primary">Confirm Handover</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
