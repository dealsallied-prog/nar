<?php
if (!defined('BASE_URL')) {
    define('BASE_URL', '/ERP');
}
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/helpers.php';

sessionStart();
$user = getCurrentUser();
if ($user) {
    header('Location: ' . BASE_URL . '/dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usernameOrEmail = trim($_POST['usernameOrEmail'] ?? '');
    $password = $_POST['password'] ?? '';
    if (login($usernameOrEmail, $password)) {
        header('Location: ' . BASE_URL . '/dashboard.php');
        exit;
    }
    $error = 'Invalid email/username or password. Please try again.';
}

$demoAccounts = [
    ['Admin',                    'admin@nayendra.com'],
    ['Sales Executive',          'sales@nayendra.com'],
    ['Service Work Controller',  'controller@nayendra.com'],
    ['Technician 1',             'tech1@nayendra.com'],
    ['Technician 2',             'tech2@nayendra.com'],
    ['Logistics',                'logistics@nayendra.com'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Sign In — NAYENDRA : SMART ERP</title>
  <meta name="description" content="Sign in to NAYENDRA : SMART ERP — manage sales, service, inventory and logistics." />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/app.css" />
</head>
<body>
<div class="login-page">
  <div class="login-box">
    <!-- Left Panel -->
    <div class="login-left">
      <div class="login-logo-wrap">
        <div class="login-logo">
          <img src="<?= BASE_URL ?>/assets/img/logo.png" alt="NAYENDRA Logo">
        </div>
        <div class="login-brand-text">
          <span class="login-brand-name">NAYENDRA</span>
          <span class="login-brand-sub">SMART ERP</span>
        </div>
      </div>
      <h1>End-to-end<br><span>Smart Operations</span></h1>
      <p>
        Sales leads · Quotations · Service work orders ·
        Technician dispatching · Inventory &amp; Logistics — all in one place.
      </p>
      <ul class="login-features">
        <li>Unlimited quotation revisions with full version history</li>
        <li>Single Work Order number follows the job end-to-end</li>
        <li>Automatic stock reservation &amp; purchase ordering</li>
        <li>Technician-level part allocation &amp; consumption tracking</li>
      </ul>
      <div class="login-left-bar"></div>
    </div>
    <!-- Right Panel -->
    <div class="login-right">
      <h2>Welcome back 👋</h2>
      <p>Sign in to your NAYENDRA ERP account.</p>
      <?php if ($error): ?>
        <div class="alert alert-error" style="margin-top:16px"><?= e($error) ?></div>
      <?php endif; ?>
      <form method="POST" class="login-form" id="loginForm">
        <div class="form-group">
          <label for="usernameOrEmail">Email Address or Username</label>
          <input id="usernameOrEmail" name="usernameOrEmail" type="text" required
                 value="<?= e($_POST['usernameOrEmail'] ?? 'admin@nayendra.com') ?>"
                 placeholder="Email or Username" />
        </div>
        <div class="form-group">
          <label for="password">Password</label>
          <input id="password" name="password" type="password" required
                 value="<?= e($_POST['password'] ?? 'password123') ?>"
                 placeholder="••••••••" />
        </div>
        <button type="submit" class="btn-login">
          Sign in &nbsp;→
        </button>
      </form>
      <div class="demo-accounts">
        <p>Demo accounts (password: <strong>password123</strong>)</p>
        <ul>
          <?php foreach ($demoAccounts as [$role, $email]): ?>
            <li>
              <span><?= e($role) ?></span>
              <span><?= e($email) ?></span>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </div>
</div>
</body>
</html>
