<?php
/**
 * User Management
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['ADMIN']);

// Handle Create User
if (isset($_POST['create_user'])) {
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $role     = trim($_POST['role'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$name || !$email || !$role || !$password) {
        setFlash('error', 'Please fill all required fields.');
    } else {
        // Check email uniqueness
        $exists = dbOne("SELECT id FROM users WHERE email=?", [$email]);
        if ($exists) {
            setFlash('error', 'Email is already in use.');
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            dbExec("INSERT INTO users (name, email, phone, role, password_hash) VALUES (?,?,?,?,?)", 
                [$name, $email, $phone, $role, $hash]);
            setFlash('success', 'User created successfully.');
        }
    }
    redirect('users.php');
}

// Handle Edit User
if (isset($_POST['edit_user'])) {
    $id       = (int)$_POST['user_id'];
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $role     = trim($_POST['role'] ?? '');
    $active   = (int)($_POST['active'] ?? 0);
    $password = $_POST['password'] ?? '';

    if ($id === $user['id'] && $active === 0) {
        setFlash('error', 'You cannot deactivate your own account.');
    } elseif ($id === $user['id'] && $role !== 'ADMIN') {
        setFlash('error', 'You cannot remove your own admin privileges.');
    } elseif (!$name || !$email || !$role) {
        setFlash('error', 'Name, Email, and Role are required.');
    } else {
        $exists = dbOne("SELECT id FROM users WHERE email=? AND id!=?", [$email, $id]);
        if ($exists) {
            setFlash('error', 'Email is already in use by another user.');
        } else {
            if ($password) {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                dbExec("UPDATE users SET name=?, email=?, phone=?, role=?, active=?, password_hash=? WHERE id=?", 
                    [$name, $email, $phone, $role, $active, $hash, $id]);
            } else {
                dbExec("UPDATE users SET name=?, email=?, phone=?, role=?, active=? WHERE id=?", 
                    [$name, $email, $phone, $role, $active, $id]);
            }
            setFlash('success', 'User updated successfully.');
        }
    }
    redirect('users.php');
}

$users = dbAll("SELECT id, name, email, phone, role, active, created_at FROM users ORDER BY name ASC");

$pageTitle = 'User Management';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>User Management</h1>
    <p>Manage users, assign section-wise roles, and update credentials.</p>
  </div>
  <div class="page-actions">
    <button class="btn btn-primary" onclick="openModal('createUserModal')">+ Create New User</button>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Role / Access Level</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td><strong><?= e($u['name']) ?></strong></td>
            <td><?= e($u['email']) ?></td>
            <td><?= e($u['phone'] ?: '—') ?></td>
            <td><?= roleLabel($u['role']) ?></td>
            <td>
              <?php if ($u['active']): ?>
                <span class="badge badge-green">Active</span>
              <?php else: ?>
                <span class="badge badge-red">Inactive</span>
              <?php endif; ?>
            </td>
            <td>
              <button class="btn btn-xs btn-outline-sky" onclick='editUser(<?= json_encode($u) ?>)'>Edit / Password</button>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Create User Modal -->
<div id="createUserModal" class="modal-overlay">
  <div class="modal-box">
    <h3 class="modal-title">Create New User</h3>
    <form method="POST">
      <div class="form-grid">
        <div class="form-group full">
          <label>Full Name *</label>
          <input type="text" name="name" required>
        </div>
        <div class="form-group">
          <label>Email Address *</label>
          <input type="email" name="email" required autocomplete="new-password">
        </div>
        <div class="form-group">
          <label>Phone Number</label>
          <input type="text" name="phone">
        </div>
        <div class="form-group">
          <label>Role (Section Access) *</label>
          <select name="role" required>
            <option value="">Select Role...</option>
            <option value="ADMIN">Admin (Full Access)</option>
            <option value="SALES">Sales</option>
            <option value="SERVICE_CONTROLLER">Service Controller</option>
            <option value="TECHNICIAN">Technician</option>
            <option value="LOGISTICS">Logistics</option>
          </select>
        </div>
        <div class="form-group">
          <label>Password *</label>
          <input type="password" name="password" required autocomplete="new-password">
        </div>
      </div>
      <div style="margin-top:20px; display:flex; gap:10px; justify-content:flex-end;">
        <button type="button" class="btn btn-ghost" onclick="closeModal('createUserModal')">Cancel</button>
        <button type="submit" name="create_user" class="btn btn-primary">Create User</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit User Modal -->
<div id="editUserModal" class="modal-overlay">
  <div class="modal-box">
    <h3 class="modal-title">Edit User</h3>
    <form method="POST">
      <input type="hidden" name="user_id" id="edit_user_id">
      <div class="form-grid">
        <div class="form-group full">
          <label>Full Name *</label>
          <input type="text" name="name" id="edit_name" required>
        </div>
        <div class="form-group">
          <label>Email Address *</label>
          <input type="email" name="email" id="edit_email" required autocomplete="new-password">
        </div>
        <div class="form-group">
          <label>Phone Number</label>
          <input type="text" name="phone" id="edit_phone">
        </div>
        <div class="form-group">
          <label>Role (Section Access) *</label>
          <select name="role" id="edit_role" required>
            <option value="ADMIN">Admin (Full Access)</option>
            <option value="SALES">Sales</option>
            <option value="SERVICE_CONTROLLER">Service Controller</option>
            <option value="TECHNICIAN">Technician</option>
            <option value="LOGISTICS">Logistics</option>
          </select>
        </div>
        <div class="form-group">
          <label>Status *</label>
          <select name="active" id="edit_active" required>
            <option value="1">Active</option>
            <option value="0">Inactive</option>
          </select>
        </div>
        <div class="form-group full" style="border-top: 1px solid var(--border); padding-top: 12px; margin-top: 4px;">
          <label>Change Password <span style="font-weight:normal;color:var(--muted);">(Leave blank to keep current password)</span></label>
          <input type="password" name="password" autocomplete="new-password" placeholder="New Password">
        </div>
      </div>
      <div style="margin-top:20px; display:flex; gap:10px; justify-content:flex-end;">
        <button type="button" class="btn btn-ghost" onclick="closeModal('editUserModal')">Cancel</button>
        <button type="submit" name="edit_user" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script>
function editUser(u) {
    document.getElementById('edit_user_id').value = u.id;
    document.getElementById('edit_name').value = u.name;
    document.getElementById('edit_email').value = u.email;
    document.getElementById('edit_phone').value = u.phone || '';
    document.getElementById('edit_role').value = u.role;
    document.getElementById('edit_active').value = u.active;
    // reset password field
    document.querySelector('#editUserModal input[name="password"]').value = '';
    
    openModal('editUserModal');
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
