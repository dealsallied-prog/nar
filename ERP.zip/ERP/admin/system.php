<?php
/**
 * System Settings
 */
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/helpers.php';
$user = requireUser(['ADMIN']);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $companyName = trim($_POST['company_name'] ?? '');
    $address     = trim($_POST['address'] ?? '');
    $phone       = trim($_POST['phone'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $gstNumber   = trim($_POST['gst_number'] ?? '');
    $website     = trim($_POST['website'] ?? '');

    if (!$companyName) {
        setFlash('error', 'Company Name is required.');
    } else {
        dbExec("UPDATE company_settings SET company_name=?, address=?, phone=?, email=?, gst_number=?, website=? WHERE id=1",
            [$companyName, $address, $phone, $email, $gstNumber, $website]);
        setFlash('success', 'Company details updated successfully.');
        redirect('system.php');
    }
}

$settings = dbOne("SELECT * FROM company_settings WHERE id=1");
if (!$settings) {
    // Failsafe if deleted
    dbExec("INSERT INTO company_settings (id, company_name) VALUES (1, 'My Company Ltd')");
    $settings = dbOne("SELECT * FROM company_settings WHERE id=1");
}

$pageTitle = 'System Settings';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div>
    <h1>System Settings</h1>
    <p>Manage your company details and core configurations.</p>
  </div>
</div>

<div class="card" style="max-width: 800px;">
  <div class="card-header"><div class="card-title">Company Details</div></div>
  <div class="card-body">
    <form method="POST">
      <div class="form-grid">
        <div class="form-group full">
          <label>Company Name *</label>
          <input type="text" name="company_name" value="<?= e($settings['company_name']) ?>" required>
        </div>
        <div class="form-group">
          <label>Phone Number</label>
          <input type="text" name="phone" value="<?= e($settings['phone']) ?>">
        </div>
        <div class="form-group">
          <label>Email Address</label>
          <input type="email" name="email" value="<?= e($settings['email']) ?>">
        </div>
        <div class="form-group">
          <label>GST Number</label>
          <input type="text" name="gst_number" value="<?= e($settings['gst_number']) ?>">
        </div>
        <div class="form-group">
          <label>Website</label>
          <input type="text" name="website" value="<?= e($settings['website']) ?>">
        </div>
        <div class="form-group full">
          <label>Registered Address</label>
          <textarea name="address" rows="3"><?= e($settings['address']) ?></textarea>
        </div>
        <div class="form-group full">
          <button type="submit" class="btn btn-primary" style="margin-top: 10px;">💾 Save Changes</button>
        </div>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
